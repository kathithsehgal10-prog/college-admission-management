import React, { useState, useEffect } from 'react';
import {
  Users,
  Building2,
  GraduationCap,
  UserCheck,
  Clock,
  CheckCircle2,
  RefreshCw,
  Home,
  Bus,
  ArrowUpRight,
  TrendingUp,
  FileText
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  Legend
} from 'recharts';
import { dashboardService } from '../services/dashboardService';
import { StatCard } from '../components/common/StatCard';
import { PageHeader } from '../components/common/PageHeader';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useNavigate } from 'react-router-dom';

const STATUS_COLORS = {
  Approved: '#10b981', // emerald-500
  Pending: '#f59e0b',  // amber-500
  Rejected: '#ef4444'  // rose-500
};

export function Dashboard() {
  const [stats, setStats] = useState(null);
  const [charts, setCharts] = useState(null);
  const [activity, setActivity] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [statsRes, chartsRes, activityRes] = await Promise.all([
        dashboardService.getStats(),
        dashboardService.getCharts(),
        dashboardService.getRecentActivity()
      ]);
      setStats(statsRes.data);
      setCharts(chartsRes.data);
      setActivity(activityRes.data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Could not load dashboard statistics from MySQL database. Verify backend connection in server/.env.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Administrative Dashboard"
        description="Real-time academic admissions, departmental statistics, and residential capacity metrics"
        breadcrumbs={['Admissions Portal', 'Dashboard']}
        actions={
          <button
            onClick={fetchDashboardData}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh Data
          </button>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchDashboardData} />}

      {/* KPI Statistic Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          title="Total Students"
          value={stats?.totalStudents}
          icon={Users}
          color="blue"
          loading={loading}
          subtitle="Registered applicants"
        />
        <StatCard
          title="Departments"
          value={stats?.totalDepartments}
          icon={Building2}
          color="indigo"
          loading={loading}
          subtitle="Academic faculties"
        />
        <StatCard
          title="Courses"
          value={stats?.totalCourses}
          icon={GraduationCap}
          color="purple"
          loading={loading}
          subtitle="Active degree programs"
        />
        <StatCard
          title="Faculty Tutors"
          value={stats?.totalTutors}
          icon={UserCheck}
          color="amber"
          loading={loading}
          subtitle="Academic advisors"
        />
        <StatCard
          title="Pending Apps"
          value={stats?.pendingApplications}
          icon={Clock}
          color="amber"
          loading={loading}
          subtitle="Awaiting review"
        />
        <StatCard
          title="Approved Apps"
          value={stats?.approvedApplications}
          icon={CheckCircle2}
          color="emerald"
          loading={loading}
          subtitle="Admitted students"
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department-wise Students Bar Chart */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-800">Students per Department</h3>
              <p className="text-xs text-slate-500">Relational distribution across faculties</p>
            </div>
            <span className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>

          <div className="h-64 w-full">
            {loading ? (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm animate-pulse">
                Loading department chart...
              </div>
            ) : charts?.departmentDistribution && charts.departmentDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.departmentDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    interval={0}
                    angle={-20}
                    textAnchor="end"
                  />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px', border: 'none' }}
                  />
                  <Bar dataKey="studentCount" name="Students" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                No department records found.
              </div>
            )}
          </div>
        </div>

        {/* Application Status Distribution Donut Chart */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-800">Application Status Distribution</h3>
              <p className="text-xs text-slate-500">Breakdown of submitted admissions</p>
            </div>
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            {loading ? (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm animate-pulse">
                Loading status breakdown...
              </div>
            ) : charts?.applicationStatus && charts.applicationStatus.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={charts.applicationStatus}
                    dataKey="count"
                    nameKey="status"
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={4}
                  >
                    {charts.applicationStatus.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={STATUS_COLORS[entry.status] || '#94a3b8'}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', color: '#fff', fontSize: '12px', border: 'none' }}
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-xs">
                No application status data found.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Facilities & Residential Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hostel Capacity Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <Home className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-800">Campus Hostel Occupancy</h4>
                <p className="text-xs text-slate-500">Live residential seat assignments</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/hostels')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 mt-4">
            <div className="flex justify-between text-xs font-medium text-slate-600">
              <span>Occupied: {stats?.hostel?.occupied || 0} beds</span>
              <span>Total: {stats?.hostel?.capacity || 0} beds</span>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                style={{
                  width: `${
                    stats?.hostel?.capacity > 0
                      ? Math.min(100, Math.round((stats.hostel.occupied / stats.hostel.capacity) * 100))
                      : 0
                  }%`
                }}
              />
            </div>
            <p className="text-[11px] text-slate-400">
              {stats?.hostel?.capacity > 0
                ? `${stats.hostel.capacity - stats.hostel.occupied} vacant beds remaining across all hostels.`
                : 'No hostel records registered yet.'}
            </p>
          </div>
        </div>

        {/* Bus Transportation Capacity Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                <Bus className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-800">Transportation Fleet Occupancy</h4>
                <p className="text-xs text-slate-500">Active student bus seat allocations</p>
              </div>
            </div>
            <button
              onClick={() => navigate('/buses')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 mt-4">
            <div className="flex justify-between text-xs font-medium text-slate-600">
              <span>Assigned: {stats?.transportation?.occupied || 0} seats</span>
              <span>Total Fleet: {stats?.transportation?.capacity || 0} seats</span>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-500"
                style={{
                  width: `${
                    stats?.transportation?.capacity > 0
                      ? Math.min(100, Math.round((stats.transportation.occupied / stats.transportation.capacity) * 100))
                      : 0
                  }%`
                }}
              />
            </div>
            <p className="text-[11px] text-slate-400">
              {stats?.transportation?.capacity > 0
                ? `${stats.transportation.capacity - stats.transportation.occupied} seats available across routes.`
                : 'No buses configured yet.'}
            </p>
          </div>
        </div>
      </div>

      {/* Recent Activity Dual Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Student Registrations */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">Recent Student Registrations</h3>
              <p className="text-xs text-slate-500">Latest applicants added to the database</p>
            </div>
            <button
              onClick={() => navigate('/students')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              All Students <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {activity?.recentStudents && activity.recentStudents.length > 0 ? (
              activity.recentStudents.map(student => (
                <div key={student.student_id} className="py-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 font-bold flex items-center justify-center shrink-0">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-800">{student.name}</p>
                      <p className="text-[11px] text-slate-400">{student.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-medium text-slate-700">{student.marks}% marks</span>
                    <p className="text-[10px] text-slate-400">{student.department_name || 'Unassigned'}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400 py-4 text-center">No students registered yet.</p>
            )}
          </div>
        </div>

        {/* Recent Applications */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">Recent Admission Applications</h3>
              <p className="text-xs text-slate-500">Course enrollment requests submitted</p>
            </div>
            <button
              onClick={() => navigate('/applications')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              All Applications <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {activity?.recentApplications && activity.recentApplications.length > 0 ? (
              activity.recentApplications.map(app => (
                <div key={app.application_id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-slate-800">{app.student_name}</p>
                    <p className="text-[11px] text-slate-500 truncate max-w-xs">{app.course_name}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge status={app.status} />
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400 py-4 text-center">No applications submitted yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
