import React, { useState, useEffect } from 'react';
import {
  Plus,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  RefreshCw,
  Home,
  Bus,
  GraduationCap,
  Calendar,
  Award
} from 'lucide-react';
import { studentService } from '../services/studentService';
import { departmentService } from '../services/departmentService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { Pagination } from '../components/common/Pagination';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function Students() {
  const [students, setStudents] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & Pagination
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedGender, setSelectedGender] = useState('');
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, totalPages: 1 });

  // Modals state
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailedStudent, setDetailedStudent] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const initialFormState = {
    name: '',
    gender: 'Male',
    age: '',
    address: '',
    phone: '',
    email: '',
    rank: '',
    marks: '',
    tenth_marks: '',
    twelfth_marks: '',
    department_id: ''
  };
  const [formData, setFormData] = useState(initialFormState);
  const [formErrors, setFormErrors] = useState({});

  const { success, error: toastError } = useToast();

  const fetchDepartments = async () => {
    try {
      const res = await departmentService.getAll();
      setDepartments(res.data || []);
    } catch (_) {
      // Handled quietly
    }
  };

  const fetchStudents = async (page = 1) => {
    setLoading(true);
    setError(null);
    try {
      const res = await studentService.getAll({
        page,
        limit: 10,
        search,
        department_id: selectedDept || undefined,
        gender: selectedGender || undefined
      });
      setStudents(res.data || []);
      setPagination(res.pagination || { page: 1, limit: 10, total: 0, totalPages: 1 });
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load students from database. Please check MySQL connection.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  useEffect(() => {
    fetchStudents(1);
  }, [search, selectedDept, selectedGender]);

  const handleOpenAdd = () => {
    setEditingStudent(null);
    setFormData(initialFormState);
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenEdit = student => {
    setEditingStudent(student);
    setFormData({
      name: student.name || '',
      gender: student.gender || 'Male',
      age: student.age || '',
      address: student.address || '',
      phone: student.phone || '',
      email: student.email || '',
      rank: student.rank || '',
      marks: student.marks || '',
      tenth_marks: student.tenth_marks || '',
      twelfth_marks: student.twelfth_marks || '',
      department_id: student.department_id || ''
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenDetail = async student => {
    try {
      const res = await studentService.getById(student.student_id);
      setDetailedStudent(res.data);
      setDetailModalOpen(true);
    } catch (err) {
      toastError(err.response?.data?.message || 'Could not load student profile.');
    }
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setFormErrors({});
    setSubmitting(true);

    const payload = {
      ...formData,
      age: Number(formData.age),
      marks: parseFloat(formData.marks),
      tenth_marks: parseFloat(formData.tenth_marks),
      twelfth_marks: parseFloat(formData.twelfth_marks),
      rank: formData.rank ? parseInt(formData.rank, 10) : null,
      department_id: formData.department_id ? parseInt(formData.department_id, 10) : null
    };

    try {
      if (editingStudent) {
        await studentService.update(editingStudent.student_id, payload);
        success(`Student "${formData.name}" updated successfully.`);
      } else {
        await studentService.create(payload);
        success(`Student "${formData.name}" registered successfully.`);
      }
      setFormModalOpen(false);
      fetchStudents(pagination.page);
    } catch (err) {
      if (err.response?.data?.errors) {
        const errorsObj = {};
        err.response.data.errors.forEach(issue => {
          errorsObj[issue.field] = issue.message;
        });
        setFormErrors(errorsObj);
      } else {
        toastError(err.response?.data?.message || 'Error saving student record.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!studentToDelete) return;
    setSubmitting(true);
    try {
      await studentService.delete(studentToDelete.student_id);
      success(`Student "${studentToDelete.name}" deleted successfully.`);
      setDeleteConfirmOpen(false);
      setStudentToDelete(null);
      fetchStudents(pagination.page);
    } catch (err) {
      toastError(err.response?.data?.message || 'Error deleting student.');
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'ID',
      accessor: 'student_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Student Name',
      key: 'name',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800 hover:text-blue-600 transition">
            {row.name}
          </span>
          <p className="text-xs text-slate-400">{row.email}</p>
        </div>
      )
    },
    {
      header: 'Gender',
      key: 'gender',
      render: row => <Badge status={row.gender} />
    },
    {
      header: 'Age',
      accessor: 'age',
      className: 'text-slate-600'
    },
    {
      header: 'Phone',
      accessor: 'phone',
      className: 'font-mono text-xs text-slate-600'
    },
    {
      header: 'Department',
      key: 'department',
      render: row => (
        <span className="text-xs font-medium text-slate-700">
          {row.department_name || (
            <span className="italic text-slate-400">Unassigned</span>
          )}
        </span>
      )
    },
    {
      header: 'Rank',
      key: 'rank',
      render: row =>
        row.rank ? (
          <span className="inline-flex items-center gap-1 font-semibold text-xs text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
            #{row.rank}
          </span>
        ) : (
          <span className="text-slate-400 text-xs">-</span>
        )
    },
    {
      header: 'Entrance %',
      key: 'marks',
      render: row => (
        <span className="font-semibold text-xs text-emerald-700">
          {row.marks}%
        </span>
      )
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5" onClick={e => e.stopPropagation()}>
          <button
            onClick={() => handleOpenDetail(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Edit Student"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setStudentToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Student"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Student Management"
        description="Comprehensive directory of registered applicants, entrance scores, and enrolled faculties"
        breadcrumbs={['Admissions Portal', 'Students']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchStudents(pagination.page)}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Register Student
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={() => fetchStudents(pagination.page)} />}

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by name, email, phone, or ID..."
          className="flex-1 w-full"
        />

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          {/* Department Filter */}
          <select
            value={selectedDept}
            onChange={e => setSelectedDept(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="">All Departments</option>
            {departments.map(d => (
              <option key={d.department_id} value={d.department_id}>
                {d.department_name}
              </option>
            ))}
          </select>

          {/* Gender Filter */}
          <select
            value={selectedGender}
            onChange={e => setSelectedGender(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="">All Genders</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        columns={columns}
        data={students}
        loading={loading}
        emptyTitle="No students found"
        emptyDescription="Try clearing filters or add a new student record to MySQL."
        emptyActionLabel="Register Student"
        onEmptyAction={handleOpenAdd}
      />

      {/* Pagination */}
      <Pagination pagination={pagination} onPageChange={fetchStudents} />

      {/* Add / Edit Student Modal */}
      <Modal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        title={editingStudent ? `Edit Student: ${editingStudent.name}` : 'Register New Student'}
        maxWidth="max-w-3xl"
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                placeholder="e.g. Aarav Mehta"
              />
              {formErrors.name && <p className="text-xs text-rose-600 mt-1">{formErrors.name}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                placeholder="student@example.com"
              />
              {formErrors.email && <p className="text-xs text-rose-600 mt-1">{formErrors.email}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Phone Number *
              </label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                placeholder="+91 98765 43210"
              />
              {formErrors.phone && <p className="text-xs text-rose-600 mt-1">{formErrors.phone}</p>}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Gender *
                </label>
                <select
                  value={formData.gender}
                  onChange={e => setFormData({ ...formData, gender: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Age *
                </label>
                <input
                  type="number"
                  min="15"
                  max="60"
                  required
                  value={formData.age}
                  onChange={e => setFormData({ ...formData, age: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                  placeholder="18"
                />
                {formErrors.age && <p className="text-xs text-rose-600 mt-1">{formErrors.age}</p>}
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Residential Address *
              </label>
              <textarea
                required
                rows={2}
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="House No., Street, City, State, PIN"
              />
              {formErrors.address && <p className="text-xs text-rose-600 mt-1">{formErrors.address}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Department Assignment (Optional)
              </label>
              <select
                value={formData.department_id}
                onChange={e => setFormData({ ...formData, department_id: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              >
                <option value="">Unassigned (During Application Phase)</option>
                {departments.map(d => (
                  <option key={d.department_id} value={d.department_id}>
                    {d.department_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Merit Rank (Optional)
              </label>
              <input
                type="number"
                min="1"
                value={formData.rank}
                onChange={e => setFormData({ ...formData, rank: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="e.g. 142"
              />
              {formErrors.rank && <p className="text-xs text-rose-600 mt-1">{formErrors.rank}</p>}
            </div>

            <div className="grid grid-cols-3 gap-2 md:col-span-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Entrance Marks (%) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="100"
                  required
                  value={formData.marks}
                  onChange={e => setFormData({ ...formData, marks: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                  placeholder="92.5"
                />
                {formErrors.marks && <p className="text-xs text-rose-600 mt-1">{formErrors.marks}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  10th Board Marks (%) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="100"
                  required
                  value={formData.tenth_marks}
                  onChange={e => setFormData({ ...formData, tenth_marks: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                  placeholder="95.0"
                />
                {formErrors.tenth_marks && (
                  <p className="text-xs text-rose-600 mt-1">{formErrors.tenth_marks}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  12th Board Marks (%) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="100"
                  required
                  value={formData.twelfth_marks}
                  onChange={e => setFormData({ ...formData, twelfth_marks: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                  placeholder="91.5"
                />
                {formErrors.twelfth_marks && (
                  <p className="text-xs text-rose-600 mt-1">{formErrors.twelfth_marks}</p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFormModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingStudent ? 'Update Student' : 'Register Student'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Student Details Modal */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Student Relational Profile"
        maxWidth="max-w-2xl"
      >
        {detailedStudent && (
          <div className="space-y-6">
            {/* Header summary */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-xl font-bold text-slate-900">{detailedStudent.name}</h3>
                <p className="text-sm text-slate-500 font-mono">Student ID: #{detailedStudent.student_id}</p>
              </div>
              <Badge status={detailedStudent.gender} />
            </div>

            {/* Academic & Contact details grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Email</span>
                <span className="font-medium text-slate-800 break-all">{detailedStudent.email}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Phone</span>
                <span className="font-mono font-medium text-slate-800">{detailedStudent.phone}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Age</span>
                <span className="font-medium text-slate-800">{detailedStudent.age} years</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Department</span>
                <span className="font-semibold text-blue-700">
                  {detailedStudent.department_name || 'Unassigned'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Merit Rank</span>
                <span className="font-bold text-blue-600">
                  {detailedStudent.rank ? `#${detailedStudent.rank}` : 'N/A'}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Entrance Marks</span>
                <span className="font-bold text-emerald-600 text-sm">{detailedStudent.marks}%</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">10th Board</span>
                <span className="font-medium text-slate-800">{detailedStudent.tenth_marks}%</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">12th Board</span>
                <span className="font-medium text-slate-800">{detailedStudent.twelfth_marks}%</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl col-span-2 sm:col-span-1">
                <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Address</span>
                <span className="text-slate-700 leading-tight block">{detailedStudent.address}</span>
              </div>
            </div>

            {/* Campus Facilities Assignments */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-slate-200/80 bg-white">
                <div className="flex items-center gap-2 mb-2">
                  <Home className="w-4 h-4 text-indigo-600" />
                  <h4 className="text-xs font-bold uppercase text-slate-700">Hostel Allocation</h4>
                </div>
                {detailedStudent.activeHostel ? (
                  <div className="text-xs text-slate-600">
                    <p className="font-semibold text-slate-800">{detailedStudent.activeHostel.hostel_name}</p>
                    <p>Room: {detailedStudent.activeHostel.room_number || 'Standard'}</p>
                    <p className="text-[11px] text-slate-400">Date: {detailedStudent.activeHostel.allocation_date}</p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No active hostel room allocated.</p>
                )}
              </div>

              <div className="p-4 rounded-xl border border-slate-200/80 bg-white">
                <div className="flex items-center gap-2 mb-2">
                  <Bus className="w-4 h-4 text-amber-600" />
                  <h4 className="text-xs font-bold uppercase text-slate-700">Bus Transportation</h4>
                </div>
                {detailedStudent.activeBus ? (
                  <div className="text-xs text-slate-600">
                    <p className="font-semibold text-slate-800">{detailedStudent.activeBus.bus_number}</p>
                    <p className="truncate">{detailedStudent.activeBus.route}</p>
                    <p className="text-[11px] text-slate-400">To: {detailedStudent.activeBus.destination}</p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No bus transportation route assigned.</p>
                )}
              </div>
            </div>

            {/* Applications history */}
            <div>
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2">Course Applications</h4>
              {detailedStudent.applications && detailedStudent.applications.length > 0 ? (
                <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
                  {detailedStudent.applications.map(app => (
                    <div key={app.application_id} className="p-3 flex items-center justify-between text-xs bg-white">
                      <div>
                        <p className="font-semibold text-slate-800">{app.course_name}</p>
                        <p className="text-[11px] text-slate-400">Applied on {app.application_date}</p>
                      </div>
                      <Badge status={app.status} />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">No course applications submitted yet.</p>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Confirm Student Deletion"
        message={`Are you sure you want to remove student "${studentToDelete?.name}"? Related applications, hostel, and bus assignments will be permanently removed.`}
        confirmText="Delete Student"
        loading={submitting}
      />
    </div>
  );
}
