import React, { useState, useEffect } from 'react';
import {
  CalendarRange,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Archive,
  Edit2,
  Trash2,
  FileText,
  AlertCircle
} from 'lucide-react';
import { cycleService } from '../services/cycleService';
import { PageHeader } from '../components/common/PageHeader';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { EmptyState } from '../components/common/EmptyState';
import { Badge } from '../components/common/Badge';
import { useToast } from '../contexts/ToastContext';

export function AdmissionCycles() {
  const [cycles, setCycles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCycle, setEditingCycle] = useState(null);
  const [formData, setFormData] = useState({
    cycle_name: '',
    start_date: '',
    end_date: '',
    status: 'ACTIVE',
    description: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  // Delete state
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const { success, error: toastError } = useToast();

  const fetchCycles = async () => {
    setLoading(true);
    try {
      const res = await cycleService.getAll({
        search: search.trim() || undefined,
        status: statusFilter || undefined
      });
      setCycles(res.data || []);
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to load admission cycles.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCycles();
  }, [search, statusFilter]);

  const handleOpenCreate = () => {
    setEditingCycle(null);
    setFormData({
      cycle_name: '',
      start_date: new Date().toISOString().split('T')[0],
      end_date: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'ACTIVE',
      description: ''
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const handleOpenEdit = cycle => {
    setEditingCycle(cycle);
    setFormData({
      cycle_name: cycle.cycle_name,
      start_date: cycle.start_date,
      end_date: cycle.end_date,
      status: cycle.status,
      description: cycle.description || ''
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.cycle_name.trim()) errors.cycle_name = 'Cycle name is required.';
    if (!formData.start_date) errors.start_date = 'Start date is required.';
    if (!formData.end_date) errors.end_date = 'End date is required.';
    if (formData.start_date && formData.end_date && new Date(formData.end_date) < new Date(formData.start_date)) {
      errors.end_date = 'End date must be on or after start date.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      if (editingCycle) {
        await cycleService.update(editingCycle.cycle_id, formData);
        success(`Admission cycle "${formData.cycle_name}" updated.`);
      } else {
        await cycleService.create(formData);
        success(`Admission cycle "${formData.cycle_name}" created.`);
      }
      setIsModalOpen(false);
      fetchCycles();
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to save admission cycle.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await cycleService.delete(deleteTarget.cycle_id);
      success(`Admission cycle "${deleteTarget.cycle_name}" deleted.`);
      setDeleteTarget(null);
      fetchCycles();
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to delete admission cycle.');
    } finally {
      setDeleting(false);
    }
  };

  const getStatusBadge = status => {
    switch (status) {
      case 'ACTIVE':
        return <Badge variant="success">Active Intake</Badge>;
      case 'UPCOMING':
        return <Badge variant="info">Upcoming</Badge>;
      case 'CLOSED':
        return <Badge variant="neutral">Closed Archive</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Admission Cycles"
        description="Configure academic intake sessions, application windows, and admission timeframes"
        breadcrumbs={['Admissions Portal', 'Admission Cycles']}
        actions={
          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-sm shadow-blue-500/20 transition"
          >
            <Plus className="w-4 h-4" />
            <span>New Admission Cycle</span>
          </button>
        }
      />

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search cycles by title or description..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Status:</span>
          {['', 'ACTIVE', 'UPCOMING', 'CLOSED'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                statusFilter === s
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {s || 'All Sessions'}
            </button>
          ))}
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12">
            <LoadingSpinner message="Loading admission cycles..." />
          </div>
        ) : cycles.length === 0 ? (
          <EmptyState
            icon={CalendarRange}
            title="No Admission Cycles Found"
            description="Create an admission cycle to begin accepting candidate applications for this academic session."
            actionLabel="Create Admission Cycle"
            onAction={handleOpenCreate}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Cycle ID</th>
                  <th className="py-3 px-4">Cycle Session Name</th>
                  <th className="py-3 px-4">Intake Window</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-center">Applications</th>
                  <th className="py-3 px-4 text-center">Approved</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {cycles.map(cycle => (
                  <tr key={cycle.cycle_id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3.5 px-4 font-mono font-semibold text-slate-500">
                      #{cycle.cycle_id}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      <div>{cycle.cycle_name}</div>
                      {cycle.description && (
                        <div className="text-[11px] text-slate-400 font-normal truncate max-w-xs mt-0.5">
                          {cycle.description}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-mono">
                      <span>{cycle.start_date}</span>
                      <span className="text-slate-400 mx-1.5">→</span>
                      <span>{cycle.end_date}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      {getStatusBadge(cycle.status)}
                    </td>
                    <td className="py-3.5 px-4 text-center font-semibold text-slate-800">
                      {cycle.total_applications || 0}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {cycle.approved_applications || 0}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => handleOpenEdit(cycle)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition"
                          title="Edit Cycle"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(cycle)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition"
                          title="Delete Cycle"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCycle ? 'Edit Admission Cycle' : 'Create Admission Cycle'}
        size="md"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Cycle Session Name *
            </label>
            <input
              type="text"
              value={formData.cycle_name}
              onChange={e => setFormData({ ...formData, cycle_name: e.target.value })}
              placeholder="e.g. Academic Year 2026-27 (Fall Regular Intake)"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
            />
            {formErrors.cycle_name && (
              <p className="text-[11px] text-rose-600 mt-1">{formErrors.cycle_name}</p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Start Date *
              </label>
              <input
                type="date"
                value={formData.start_date}
                onChange={e => setFormData({ ...formData, start_date: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
              />
              {formErrors.start_date && (
                <p className="text-[11px] text-rose-600 mt-1">{formErrors.start_date}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                End Date *
              </label>
              <input
                type="date"
                value={formData.end_date}
                onChange={e => setFormData({ ...formData, end_date: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
              />
              {formErrors.end_date && (
                <p className="text-[11px] text-rose-600 mt-1">{formErrors.end_date}</p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Admission Status
            </label>
            <select
              value={formData.status}
              onChange={e => setFormData({ ...formData, status: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
            >
              <option value="ACTIVE">ACTIVE (Accepting Applications)</option>
              <option value="UPCOMING">UPCOMING (Scheduled)</option>
              <option value="CLOSED">CLOSED (Admissions Concluded)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Description / Counseling Guidelines
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              placeholder="Provide intake guidance, eligibility notes, or counseling instructions..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition resize-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-xs transition disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingCycle ? 'Update Cycle' : 'Create Cycle'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        title="Delete Admission Cycle"
        message={`Are you sure you want to delete "${deleteTarget?.cycle_name}"? This operation cannot be undone.`}
        confirmLabel={deleting ? 'Deleting...' : 'Delete'}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
