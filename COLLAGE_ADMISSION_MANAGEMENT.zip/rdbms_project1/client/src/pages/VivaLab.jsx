import React, { useState, useEffect } from 'react';
import {
  Code2,
  Play,
  Database,
  Table as TableIcon,
  Layers,
  BookOpen,
  Sparkles,
  CheckCircle2,
  Clock,
  Download,
  Terminal,
  FileCode2,
  AlertCircle,
  Copy,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { vivaService } from '../services/vivaService';
import { PageHeader } from '../components/common/PageHeader';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';

export function VivaLab() {
  const [activeTab, setActiveTab] = useState('queries'); // 'queries' | 'schema' | 'procedures' | 'viva-qa'
  const [queries, setQueries] = useState([]);
  const [schemaData, setSchemaData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeQuery, setActiveQuery] = useState(null);
  const [customSql, setCustomSql] = useState('');
  const [running, setRunning] = useState(false);
  const [queryResult, setQueryResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [expandedQa, setExpandedQa] = useState({});

  const { success, error: toastError } = useToast();
  const { dbHealth } = useAuth();

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const [qRes, sRes] = await Promise.all([
          vivaService.getQueries(),
          vivaService.getSchema()
        ]);
        setQueries(qRes.data || []);
        setSchemaData(sRes.data || null);
        if (qRes.data && qRes.data.length > 0) {
          setActiveQuery(qRes.data[0]);
          setCustomSql(qRes.data[0].sql);
        }
      } catch (err) {
        toastError(err.response?.data?.message || 'Failed to load viva demonstration metadata.');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleSelectQuery = query => {
    setActiveQuery(query);
    setCustomSql(query.sql);
    setErrorMsg(null);
  };

  const handleRunQuery = async queryToRun => {
    const sqlToExecute = customSql.trim() || queryToRun?.sql;
    if (!sqlToExecute) {
      toastError('Please enter an SQL query to execute.');
      return;
    }

    setRunning(true);
    setErrorMsg(null);
    try {
      const res = await vivaService.executeQuery({ sql: sqlToExecute });
      setQueryResult(res.data);
      success(`Query executed successfully (${res.data.rowCount} rows in ${res.data.executionTimeMs} ms)`);
    } catch (err) {
      const msg = err.response?.data?.message || err.message || 'Execution failed.';
      setErrorMsg(msg);
      toastError(msg);
    } finally {
      setRunning(false);
    }
  };

  const handleDownloadCsv = () => {
    if (!queryResult || !queryResult.rows || queryResult.rows.length === 0) return;
    const cols = queryResult.columns;
    const header = cols.join(',');
    const lines = queryResult.rows.map(row =>
      cols
        .map(c => {
          const val = row[c] === null || row[c] === undefined ? '' : String(row[c]);
          return `"${val.replace(/"/g, '""')}"`;
        })
        .join(',')
    );
    const csvContent = [header, ...lines].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `viva_query_result_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    success('Query results exported to CSV.');
  };

  const toggleQa = idx => {
    setExpandedQa(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const categories = ['All', ...new Set(queries.map(q => q.category))];
  const filteredQueries =
    selectedCategory === 'All'
      ? queries
      : queries.filter(q => q.category === selectedCategory);

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="RDBMS Viva Lab & Schema Explorer"
          description="Interactive SQL Query Playground, Stored Procedures, Triggers & Viva Q&A"
          breadcrumbs={['Admissions Portal', 'Viva Lab']}
        />
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center">
          <LoadingSpinner message="Loading relational schema and viva queries catalog..." size="lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="RDBMS Viva Lab & Schema Explorer"
        description="Comprehensive Academic Demonstration Playground: 4-Table Joins, Subqueries, Stored Procedures, Triggers, Views & Viva Examination Q&A"
        breadcrumbs={['Admissions Portal', 'Viva Lab']}
        actions={
          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1.5 shadow-xs">
              <Database className="w-3.5 h-3.5 text-blue-600" />
              <span>{schemaData?.databaseEngine || 'MySQL (InnoDB)'}</span>
            </span>
          </div>
        }
      />

      {/* Navigation Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 gap-2 text-sm font-semibold text-slate-500">
        <button
          onClick={() => setActiveTab('queries')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 transition ${
            activeTab === 'queries'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent hover:text-slate-800'
          }`}
        >
          <Code2 className="w-4 h-4" />
          <span>Interactive SQL Playground</span>
          <span className="px-1.5 py-0.5 text-[11px] rounded-full bg-slate-100 text-slate-600">
            {queries.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('schema')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 transition ${
            activeTab === 'schema'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent hover:text-slate-800'
          }`}
        >
          <TableIcon className="w-4 h-4" />
          <span>Relational Schema & 3NF Specs</span>
          <span className="px-1.5 py-0.5 text-[11px] rounded-full bg-slate-100 text-slate-600">
            11 Tables
          </span>
        </button>

        <button
          onClick={() => setActiveTab('procedures')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 transition ${
            activeTab === 'procedures'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent hover:text-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Procedures, Triggers & Views</span>
        </button>

        <button
          onClick={() => setActiveTab('viva-qa')}
          className={`flex items-center gap-2 px-4 py-3 border-b-2 transition ${
            activeTab === 'viva-qa'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent hover:text-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>BTech Viva Cheat Sheet</span>
          <span className="px-1.5 py-0.5 text-[11px] rounded-full bg-emerald-100 text-emerald-700">
            12 Topics
          </span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: INTERACTIVE SQL QUERY PLAYGROUND */}
      {/* ========================================================================= */}
      {activeTab === 'queries' && (
        <div className="space-y-6">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-500 mr-2">Query Categories:</span>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-xl text-xs font-medium transition ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Query Select List */}
            <div className="lg:col-span-5 space-y-3">
              <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                  Curated Viva Demonstration Queries ({filteredQueries.length})
                </h3>
                <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                  {filteredQueries.map(q => (
                    <button
                      key={q.id}
                      onClick={() => handleSelectQuery(q)}
                      className={`w-full text-left p-3.5 rounded-xl border transition ${
                        activeQuery?.id === q.id
                          ? 'bg-blue-50/70 border-blue-400 text-blue-900 shadow-xs'
                          : 'bg-slate-50/50 border-slate-200/80 hover:bg-slate-100/70 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600">
                          {q.category}
                        </span>
                        {activeQuery?.id === q.id && (
                          <span className="flex h-2 w-2 rounded-full bg-blue-600" />
                        )}
                      </div>
                      <h4 className="text-sm font-bold leading-snug">{q.title}</h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                        {q.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: SQL Editor & Execution Results */}
            <div className="lg:col-span-7 space-y-4">
              {/* Editor Card */}
              <div className="bg-slate-900 rounded-2xl border border-slate-800 text-slate-200 p-5 shadow-lg">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    <span>SQL Query Editor</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleRunQuery(activeQuery)}
                      disabled={running}
                      className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition shadow-md shadow-emerald-600/20 disabled:opacity-50"
                    >
                      <Play className={`w-3.5 h-3.5 fill-white ${running ? 'animate-spin' : ''}`} />
                      <span>{running ? 'Executing...' : 'Run Query (F5)'}</span>
                    </button>
                  </div>
                </div>

                <div className="mt-3">
                  <textarea
                    value={customSql}
                    onChange={e => setCustomSql(e.target.value)}
                    rows={8}
                    className="w-full bg-slate-950 font-mono text-xs sm:text-sm text-emerald-300 p-3.5 rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 transition resize-y"
                    placeholder="Enter SQL SELECT statement..."
                    spellCheck="false"
                  />
                </div>

                {activeQuery && (
                  <div className="mt-3 text-xs text-slate-400 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
                    <span className="font-semibold text-slate-200">Demonstration Purpose: </span>
                    {activeQuery.description}
                  </div>
                )}
              </div>

              {/* Execution Error Banner */}
              {errorMsg && (
                <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">SQL Execution Error: </span>
                    <span>{errorMsg}</span>
                  </div>
                </div>
              )}

              {/* Query Result Card */}
              {queryResult && (
                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                  <div className="flex flex-wrap items-center justify-between p-4 border-b border-slate-100 gap-3">
                    <div className="flex items-center gap-3 text-xs">
                      <span className="inline-flex items-center gap-1 font-semibold text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Execution Success</span>
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-600 font-mono">
                        {queryResult.rowCount} rows
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="inline-flex items-center gap-1 text-slate-600 font-mono">
                        <Clock className="w-3.5 h-3.5 text-blue-600" />
                        <span>{queryResult.executionTimeMs} ms</span>
                      </span>
                    </div>

                    <button
                      onClick={handleDownloadCsv}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export CSV</span>
                    </button>
                  </div>

                  {/* Dynamic Results Table */}
                  <div className="overflow-x-auto max-h-[480px]">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="bg-slate-50 text-slate-600 sticky top-0 border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3 font-semibold text-slate-400 text-center w-10">#</th>
                          {queryResult.columns.map(col => (
                            <th key={col} className="py-2.5 px-3 font-semibold text-slate-700">
                              {col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700 font-mono">
                        {queryResult.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-blue-50/40 transition">
                            <td className="py-2 px-3 text-center text-slate-400 text-[11px] font-sans">
                              {rIdx + 1}
                            </td>
                            {queryResult.columns.map(col => (
                              <td key={col} className="py-2 px-3 text-slate-800 text-xs truncate max-w-xs">
                                {row[col] === null || row[col] === undefined ? (
                                  <span className="text-slate-400 italic">NULL</span>
                                ) : (
                                  String(row[col])
                                )}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: RELATIONAL SCHEMA & 3NF SPECIFICATIONS */}
      {/* ========================================================================= */}
      {activeTab === 'schema' && (
        <div className="space-y-6">
          <div className="bg-blue-50/70 border border-blue-200/80 rounded-2xl p-5 text-blue-900 text-xs sm:text-sm">
            <h3 className="font-bold text-base text-blue-950 mb-1 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              Relational Database Normalization Rationale (3NF / BCNF)
            </h3>
            <p className="text-blue-900/90 leading-relaxed mt-1">
              Every table in the College Admission Management System adheres to <strong>Third Normal Form (3NF)</strong> and <strong>Boyce-Codd Normal Form (BCNF)</strong>.
              All attributes depend solely on the primary key, eliminating partial and transitive functional dependencies. Computed counts (such as enrolled students or vacant beds) are never stored as redundant attributes—instead, they are derived via SQL aggregations and database views.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {schemaData?.tables?.map((tbl, idx) => (
              <div
                key={tbl.name}
                className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-blue-400 transition"
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm font-mono">{tbl.name}</h4>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {tbl.rowCount} rows
                  </span>
                </div>

                <p className="text-xs text-slate-500 mb-3">{tbl.description}</p>

                <div className="space-y-1.5 text-[11px] pt-3 border-t border-slate-100 font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-sans">Primary Key:</span>
                    <span className="text-blue-600 font-semibold">{tbl.primaryKey}</span>
                  </div>
                  {tbl.foreignKey && (
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-slate-400 font-sans">Foreign Key:</span>
                      <span className="text-slate-700 text-right truncate">{tbl.foreignKey}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Database Views Section */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-600" />
              Dynamic Relational Database Views
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Pre-compiled relational views that eliminate write anomalies by dynamically computing capacity and totals on demand:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="font-mono font-bold text-xs text-blue-600 block mb-1">
                  view_department_stats
                </span>
                <p className="text-xs text-slate-600">
                  Aggregates courses, mentors, and students per department.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="font-mono font-bold text-xs text-blue-600 block mb-1">
                  view_hostel_occupancy
                </span>
                <p className="text-xs text-slate-600">
                  Computes occupied beds and remaining vacant residential capacity.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="font-mono font-bold text-xs text-blue-600 block mb-1">
                  view_bus_occupancy
                </span>
                <p className="text-xs text-slate-600">
                  Calculates active transit pass holders vs maximum vehicle seating capacity.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: STORED PROCEDURES, FUNCTIONS & TRIGGERS */}
      {/* ========================================================================= */}
      {activeTab === 'procedures' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Stored Procedures Card */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <FileCode2 className="w-5 h-5 text-blue-600" />
                Stored Procedures (ACID Transactions)
              </h3>
              <p className="text-xs text-slate-500">
                Stored procedures execute multi-step logic inside the database server under ACID guarantees:
              </p>

              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-slate-900">
                      sp_approve_application(app_id, remarks, OUT status)
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                      Transaction + Row Lock
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Atomically verifies intake capacity, updates application status to Approved, assigns the student to the degree department, and writes to audit log.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-slate-900">
                      sp_allocate_hostel(student_id, hostel_id, room, OUT res)
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                      Capacity Verification
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Checks vacant beds via scalar function, validates existing active student passes, and issues residential allocation.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-slate-900">
                      sp_department_enrollment_report(dept_id)
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                      Multi-ResultSet
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Generates two joined result sets: departmental summary and candidate merit roster ordered by score.
                  </p>
                </div>
              </div>
            </div>

            {/* Triggers & Stored Functions Card */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-600" />
                Database Triggers & Stored Functions
              </h3>
              <p className="text-xs text-slate-500">
                Enforcing relational constraints and business calculations before committing data:
              </p>

              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-slate-900">
                      trg_check_hostel_capacity_before_insert
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                      BEFORE INSERT
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Calculates vacancy and aborts execution via <code className="font-mono">SIGNAL SQLSTATE '45000'</code> if the facility is full.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-slate-900">
                      trg_audit_application_status_change
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                      AFTER UPDATE
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Automatically logs previous and new admission statuses into the <code className="font-mono">audit_logs</code> table.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs text-slate-900">
                      fn_calculate_merit_score(marks, 10th, 12th)
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-100 text-purple-800">
                      Scalar Function
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Computes weighted merit: 50% Entrance + 25% 10th Board + 25% 12th Board.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: BTECH VIVA EXAMINATION CHEAT SHEET */}
      {/* ========================================================================= */}
      {activeTab === 'viva-qa' && (
        <div className="space-y-4 max-w-4xl">
          <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-5 text-emerald-950 text-xs sm:text-sm">
            <h3 className="font-bold text-base text-emerald-950 mb-1 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-700" />
              Frequently Asked B.Tech RDBMS Viva Questions
            </h3>
            <p className="text-emerald-900/90 leading-relaxed mt-1">
              Reviewed concepts commonly tested during Computer Science & Engineering database laboratory vivas. Click each question to expand the complete technical explanation and project reference.
            </p>
          </div>

          {[
            {
              q: '1. What are the ACID properties in RDBMS, and where are they demonstrated in this project?',
              a: 'ACID stands for Atomicity, Consistency, Isolation, and Durability. In this project, ACID is demonstrated in application status approval: when an application is Approved, we must both update the application status and assign the student to the degree department. Using `START TRANSACTION`, `SELECT ... FOR UPDATE` (row-level isolation), and `COMMIT` or `ROLLBACK`, we ensure both operations succeed together or none do, preventing partial updates.'
            },
            {
              q: '2. How does the database schema satisfy First Normal Form (1NF)?',
              a: 'A relation is in 1NF if every attribute contains only atomic (indivisible) values and each row is uniquely identifiable by a Primary Key. We eliminated repeating groups and multivalued attributes: for example, student contacts and addresses are single values, and hostel/bus allocations are modeled in separate relation tables rather than comma-separated lists.'
            },
            {
              q: '3. How does the database schema satisfy Second Normal Form (2NF)?',
              a: 'A relation is in 2NF if it is in 1NF and contains NO partial functional dependencies on candidate composite keys. In our many-to-many bridge tables (`applications`, `hostel_allocations`, `bus_allocations`), we utilize surrogate integer primary keys (`application_id`, `allocation_id`), ensuring all non-key attributes depend fully on the primary key.'
            },
            {
              q: '4. How does the database schema satisfy Third Normal Form (3NF)?',
              a: 'A relation is in 3NF if it is in 2NF and contains NO transitive functional dependencies (X -> Y and Y -> Z). For example, students belong to departments, but department descriptions and tutor qualifications are stored only in their respective parent tables (`departments`, `tutors`). Furthermore, computed counts (enrolled students, vacant beds) are never stored as columns, completely avoiding update anomalies.'
            },
            {
              q: '5. What is the difference between ON DELETE CASCADE, ON DELETE RESTRICT, and ON DELETE SET NULL?',
              a: 'CASCADE deletes the child records when the parent is deleted (e.g. deleting a student purges their applications and bus passes). RESTRICT prevents deletion of the parent if child records exist (e.g. you cannot delete a department if it contains courses or faculty tutors). SET NULL sets the child foreign key column to NULL (e.g. if a department is deleted, student `department_id` is set to NULL so the student dossier is preserved).'
            },
            {
              q: '6. What is the difference between a Stored Procedure and a Stored Function in MySQL?',
              a: 'A Stored Function must return a scalar value using the `RETURNS` clause and can be called directly inside SQL `SELECT`, `WHERE`, or `ORDER BY` statements (e.g. `fn_calculate_merit_score`). A Stored Procedure is invoked using `CALL`, does not return a single value directly, can return multiple result sets, and can execute full transaction commands (`START TRANSACTION`, `COMMIT`, `ROLLBACK`).'
            },
            {
              q: '7. What is the purpose of a Database View, and why use it over storing counts in tables?',
              a: 'A View is a virtual table defined by a pre-compiled SQL query (`CREATE VIEW`). It does not store physical data redundantly; instead, whenever the view is queried, MySQL executes the underlying query. This prevents insertion/deletion anomalies—when a new student joins, the department count in `view_department_stats` updates immediately without requiring manual sync triggers.'
            },
            {
              q: '8. How does `SELECT ... FOR UPDATE` provide concurrency control?',
              a: 'In MySQL InnoDB, `SELECT ... FOR UPDATE` acquires an exclusive row-level lock (X-lock) on the selected rows until the current transaction completes (`COMMIT` or `ROLLBACK`). This prevents concurrent transactions from modifying or allocating the same course seat or bed at the same time, preventing race conditions (over-allocation).'
            },
            {
              q: '9. What is a Database Trigger, and what are BEFORE vs AFTER triggers?',
              a: 'A Trigger is a named database object that automatically executes when an `INSERT`, `UPDATE`, or `DELETE` event occurs on a table. A `BEFORE` trigger executes prior to data insertion, allowing validation and constraint enforcement (e.g. `trg_check_hostel_capacity_before_insert` which raises an error if capacity is exceeded). An `AFTER` trigger executes after successful commit, ideal for auditing (`trg_audit_application_status_change`).'
            },
            {
              q: '10. What types of indexes are used in this project, and how do they improve performance?',
              a: 'MySQL InnoDB uses B+ Tree indexes. We created indexes on all foreign key columns (`idx_students_department`, `idx_applications_course`) to speed up relational `JOIN` operations, as well as on frequently searched and sorted columns (`idx_students_email`, `idx_students_marks`) to reduce full table scans from O(N) to O(log N).'
            },
            {
              q: '11. What is the difference between INNER JOIN, LEFT JOIN, and RIGHT JOIN?',
              a: 'INNER JOIN returns only rows that have matching values in both tables. LEFT JOIN returns all rows from the left table and matched rows from the right table (filling NULL for non-matching right columns). RIGHT JOIN returns all rows from the right table and matched rows from the left table.'
            },
            {
              q: '12. What is a Correlated Subquery and how is it evaluated?',
              a: 'A correlated subquery is a subquery that depends on values from the outer query. It is evaluated once for each row processed by the outer query. In our project, calculating vacant hostel beds uses a correlated subquery: for each hostel `h`, it executes `SELECT COUNT(*) FROM hostel_allocations WHERE hostel_id = h.hostel_id`.'
            }
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition"
            >
              <button
                onClick={() => toggleQa(idx)}
                className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-3 hover:bg-slate-50/80 transition"
              >
                <span className="font-bold text-slate-800 text-sm">{item.q}</span>
                <span className="shrink-0 p-1 text-slate-400">
                  {expandedQa[idx] ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </span>
              </button>
              {expandedQa[idx] && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/40">
                  <p>{item.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
