import React, { useState, useEffect } from 'react';
import {
  Plus,
  UserCheck,
  Building2,
  Mail,
  Phone,
  Edit2,
  Trash2,
  RefreshCw,
  Award
} from 'lucide-react';
import { tutorService } from '../services/tutorService';
import { departmentService } from '../services/departmentService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function Tutors() {
  const [tutors, setTutors] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('');

  // Modals
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingTutor, setEditingTutor] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [tutorToDelete, setTutorToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const initialForm = {
    tutor_name: '',
    email: '',
    phone: '',
    qualification: 'Ph.D / M.Tech',
    department_id: ''
  };
  const [formData, setFormData] = useState(initialForm);
  const [formErrors, setFormErrors] = useState({});

  const { success, error: toastError } = useToast();

  const fetchDepartments = async () => {
    try {
      const res = await departmentService.getAll();
      setDepartments(res.data || []);
    } catch (_) {}
  };

  const fetchTutors = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await tutorService.getAll({
        search,
        department_id: selectedDept || undefined
      });
      setTutors(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load faculty tutors from database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  useEffect(() => {
    fetchTutors();
  }, [search, selectedDept]);

  const handleOpenAdd = () => {
    setEditingTutor(null);
    setFormData({
      ...initialForm,
      department_id: departments[0]?.department_id || ''
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenEdit = tutor => {
    setEditingTutor(tutor);
    setFormData({
      tutor_name: tutor.tutor_name || '',
      email: tutor.email || '',
      phone: tutor.phone || '',
      qualification: tutor.qualification || 'M.Tech / Ph.D',
      department_id: tutor.department_id || ''
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setFormErrors({});
    setSubmitting(true);

    const payload = {
      ...formData,
      department_id: parseInt(formData.department_id, 10)
    };

    try {
      if (editingTutor) {
        await tutorService.update(editingTutor.tutor_id, payload);
        success(`Tutor "${formData.tutor_name}" updated.`);
      } else {
        await tutorService.create(payload);
        success(`Tutor "${formData.tutor_name}" created.`);
      }
      setFormModalOpen(false);
      fetchTutors();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errorsObj = {};
        err.response.data.errors.forEach(issue => {
          errorsObj[issue.field] = issue.message;
        });
        setFormErrors(errorsObj);
      } else {
        toastError(err.response?.data?.message || 'Error saving tutor record.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!tutorToDelete) return;
    setSubmitting(true);
    try {
      await tutorService.delete(tutorToDelete.tutor_id);
      success(`Tutor "${tutorToDelete.tutor_name}" deleted.`);
      setDeleteConfirmOpen(false);
      setTutorToDelete(null);
      fetchTutors();
    } catch (err) {
      toastError(err.response?.data?.message || 'Error deleting tutor.');
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'ID',
      accessor: 'tutor_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Faculty Tutor Name',
      key: 'name',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.tutor_name}</span>
          <p className="text-xs text-slate-400">{row.qualification}</p>
        </div>
      )
    },
    {
      header: 'Department',
      key: 'dept',
      render: row => (
        <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
          {row.department_name}
        </span>
      )
    },
    {
      header: 'Email',
      accessor: 'email',
      className: 'text-xs text-slate-600'
    },
    {
      header: 'Phone',
      accessor: 'phone',
      className: 'font-mono text-xs text-slate-600'
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Edit Tutor"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setTutorToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Tutor"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Faculty Tutor Management"
        description="Departmental faculty mentors assigned to counsel academic cohorts"
        breadcrumbs={['Admissions Portal', 'Tutors']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchTutors}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Add Tutor
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchTutors} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search tutors by name, email, or phone..."
          className="flex-1 w-full"
        />

        <select
          value={selectedDept}
          onChange={e => setSelectedDept(e.target.value)}
          className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 w-full sm:w-auto"
        >
          <option value="">All Departments</option>
          {departments.map(d => (
            <option key={d.department_id} value={d.department_id}>
              {d.department_name}
            </option>
          ))}
        </select>
      </div>

      <DataTable
        columns={columns}
        data={tutors}
        loading={loading}
        emptyTitle="No tutors found"
        emptyDescription="Add faculty mentors to advise admitted students."
        emptyActionLabel="Add Tutor"
        onEmptyAction={handleOpenAdd}
      />

      {/* Add / Edit Modal */}
      <Modal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        title={editingTutor ? `Edit Tutor: ${editingTutor.tutor_name}` : 'Register Faculty Tutor'}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Tutor Name *
            </label>
            <input
              type="text"
              required
              value={formData.tutor_name}
              onChange={e => setFormData({ ...formData, tutor_name: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
              placeholder="e.g. Dr. Rajesh Sharma"
            />
            {formErrors.tutor_name && (
              <p className="text-xs text-rose-600 mt-1">{formErrors.tutor_name}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="faculty@college.edu"
              />
              {formErrors.email && <p className="text-xs text-rose-600 mt-1">{formErrors.email}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Phone Number *
              </label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="+91 98765 43210"
              />
              {formErrors.phone && <p className="text-xs text-rose-600 mt-1">{formErrors.phone}</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Academic Department *
              </label>
              <select
                required
                value={formData.department_id}
                onChange={e => setFormData({ ...formData, department_id: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              >
                <option value="">Select Department</option>
                {departments.map(d => (
                  <option key={d.department_id} value={d.department_id}>
                    {d.department_name}
                  </option>
                ))}
              </select>
              {formErrors.department_id && (
                <p className="text-xs text-rose-600 mt-1">{formErrors.department_id}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Qualification
              </label>
              <input
                type="text"
                value={formData.qualification}
                onChange={e => setFormData({ ...formData, qualification: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="Ph.D in Computer Science (IIT)"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFormModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingTutor ? 'Update Tutor' : 'Register Tutor'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Remove Faculty Tutor"
        message={`Are you sure you want to delete tutor "${tutorToDelete?.tutor_name}"?`}
        confirmText="Delete Tutor"
        loading={submitting}
      />
    </div>
  );
}
