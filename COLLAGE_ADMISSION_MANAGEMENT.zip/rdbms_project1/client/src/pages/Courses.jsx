import React, { useState, useEffect } from 'react';
import {
  Plus,
  GraduationCap,
  Building2,
  FileText,
  CheckCircle2,
  Eye,
  Edit2,
  Trash2,
  RefreshCw
} from 'lucide-react';
import { courseService } from '../services/courseService';
import { departmentService } from '../services/departmentService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function Courses() {
  const [courses, setCourses] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState('');

  // Modals
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailedCourse, setDetailedCourse] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const initialForm = {
    course_name: '',
    course_code: '',
    duration_years: 4,
    department_id: '',
    intake_capacity: 60
  };
  const [formData, setFormData] = useState(initialForm);
  const [formErrors, setFormErrors] = useState({});

  const { success, error: toastError } = useToast();

  const fetchDepartments = async () => {
    try {
      const res = await departmentService.getAll();
      setDepartments(res.data || []);
    } catch (_) {}
  };

  const fetchCourses = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await courseService.getAll({
        search,
        department_id: selectedDept || undefined
      });
      setCourses(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load courses from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  useEffect(() => {
    fetchCourses();
  }, [search, selectedDept]);

  const handleOpenAdd = () => {
    setEditingCourse(null);
    setFormData({
      ...initialForm,
      department_id: departments[0]?.department_id || ''
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenEdit = course => {
    setEditingCourse(course);
    setFormData({
      course_name: course.course_name || '',
      course_code: course.course_code || '',
      duration_years: course.duration_years || 4,
      department_id: course.department_id || '',
      intake_capacity: course.intake_capacity || 60
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenDetail = async course => {
    try {
      const res = await courseService.getById(course.course_id);
      setDetailedCourse(res.data);
      setDetailModalOpen(true);
    } catch (err) {
      toastError(err.response?.data?.message || 'Could not load course applications.');
    }
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setFormErrors({});
    setSubmitting(true);

    const payload = {
      ...formData,
      duration_years: parseInt(formData.duration_years, 10),
      department_id: parseInt(formData.department_id, 10),
      intake_capacity: parseInt(formData.intake_capacity, 10)
    };

    try {
      if (editingCourse) {
        await courseService.update(editingCourse.course_id, payload);
        success(`Course "${formData.course_name}" updated successfully.`);
      } else {
        await courseService.create(payload);
        success(`Course "${formData.course_name}" added successfully.`);
      }
      setFormModalOpen(false);
      fetchCourses();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errorsObj = {};
        err.response.data.errors.forEach(issue => {
          errorsObj[issue.field] = issue.message;
        });
        setFormErrors(errorsObj);
      } else {
        toastError(err.response?.data?.message || 'Failed to save course record.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!courseToDelete) return;
    setSubmitting(true);
    try {
      await courseService.delete(courseToDelete.course_id);
      success(`Course "${courseToDelete.course_name}" deleted.`);
      setDeleteConfirmOpen(false);
      setCourseToDelete(null);
      fetchCourses();
    } catch (err) {
      toastError(
        err.response?.data?.message ||
        'Cannot delete course with existing admission applications.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'ID',
      accessor: 'course_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Course Program',
      key: 'name',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.course_name}</span>
          <p className="text-xs text-slate-400 font-mono">Code: {row.course_code || 'N/A'}</p>
        </div>
      )
    },
    {
      header: 'Department',
      key: 'dept',
      render: row => (
        <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
          {row.department_name}
        </span>
      )
    },
    {
      header: 'Duration',
      key: 'duration',
      render: row => <span className="text-xs text-slate-600">{row.duration_years} Years</span>
    },
    {
      header: 'Intake Capacity',
      accessor: 'intake_capacity',
      className: 'text-xs text-slate-600'
    },
    {
      header: 'Total Apps',
      key: 'apps',
      render: row => (
        <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-700">
          <FileText className="w-3.5 h-3.5 text-slate-400" />
          {row.total_applications}
        </span>
      )
    },
    {
      header: 'Approved',
      key: 'approved',
      render: row => (
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
          <CheckCircle2 className="w-3.5 h-3.5" />
          {row.approved_applications}
        </span>
      )
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={() => handleOpenDetail(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
            title="View Course Applicants"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Edit Course"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setCourseToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Course"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Course Management"
        description="Degree specializations, seat capacities, and admission enrollment statistics"
        breadcrumbs={['Admissions Portal', 'Courses']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchCourses}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Add Course
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchCourses} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by course name or code..."
          className="flex-1 w-full"
        />

        <select
          value={selectedDept}
          onChange={e => setSelectedDept(e.target.value)}
          className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 w-full sm:w-auto"
        >
          <option value="">All Departments</option>
          {departments.map(d => (
            <option key={d.department_id} value={d.department_id}>
              {d.department_name}
            </option>
          ))}
        </select>
      </div>

      <DataTable
        columns={columns}
        data={courses}
        loading={loading}
        emptyTitle="No courses found"
        emptyDescription="Add a new degree course under an academic department."
        emptyActionLabel="Add Course"
        onEmptyAction={handleOpenAdd}
      />

      {/* Add / Edit Modal */}
      <Modal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        title={editingCourse ? `Edit Course: ${editingCourse.course_name}` : 'Create Degree Course'}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Course Program Name *
            </label>
            <input
              type="text"
              required
              value={formData.course_name}
              onChange={e => setFormData({ ...formData, course_name: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
              placeholder="e.g. B.Tech in Artificial Intelligence & ML"
            />
            {formErrors.course_name && (
              <p className="text-xs text-rose-600 mt-1">{formErrors.course_name}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Course Code (Optional)
              </label>
              <input
                type="text"
                value={formData.course_code}
                onChange={e => setFormData({ ...formData, course_code: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none font-mono"
                placeholder="e.g. CSE-AI-02"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Duration (Years) *
              </label>
              <input
                type="number"
                min="1"
                max="6"
                required
                value={formData.duration_years}
                onChange={e => setFormData({ ...formData, duration_years: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Academic Department *
              </label>
              <select
                required
                value={formData.department_id}
                onChange={e => setFormData({ ...formData, department_id: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              >
                <option value="">Select Department</option>
                {departments.map(d => (
                  <option key={d.department_id} value={d.department_id}>
                    {d.department_name}
                  </option>
                ))}
              </select>
              {formErrors.department_id && (
                <p className="text-xs text-rose-600 mt-1">{formErrors.department_id}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Intake Capacity (Seats) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.intake_capacity}
                onChange={e => setFormData({ ...formData, intake_capacity: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="60"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFormModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingCourse ? 'Update Course' : 'Create Course'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Course Applications Modal */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Course Application Roster"
        maxWidth="max-w-2xl"
      >
        {detailedCourse && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">{detailedCourse.course_name}</h3>
              <p className="text-xs text-slate-500">
                Department: {detailedCourse.department_name} | Capacity: {detailedCourse.intake_capacity} seats
              </p>
            </div>

            <h4 className="text-xs font-bold uppercase text-slate-500">Registered Applicants</h4>
            {detailedCourse.applications && detailedCourse.applications.length > 0 ? (
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden max-h-72 overflow-y-auto">
                {detailedCourse.applications.map(app => (
                  <div key={app.application_id} className="p-3 flex items-center justify-between text-xs bg-white">
                    <div>
                      <span className="font-semibold text-slate-800">{app.student_name}</span>
                      <p className="text-[11px] text-slate-400">
                        Score: {app.marks}% | Applied: {app.application_date}
                      </p>
                    </div>
                    <Badge status={app.status} />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No applications filed for this course yet.</p>
            )}
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Delete Course Program"
        message={`Are you sure you want to delete course "${courseToDelete?.course_name}"? If students have applied for this course, deletion is restricted.`}
        confirmText="Delete Course"
        loading={submitting}
      />
    </div>
  );
}
