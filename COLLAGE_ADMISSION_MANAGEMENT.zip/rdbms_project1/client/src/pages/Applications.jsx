import React, { useState, useEffect } from 'react';
import {
  Plus,
  CheckCircle,
  XCircle,
  Eye,
  Trash2,
  RefreshCw,
  Clock,
  History,
  FileText,
  AlertTriangle,
  CalendarRange,
  ChevronRight,
  ShieldCheck,
  CreditCard
} from 'lucide-react';
import { applicationService } from '../services/applicationService';
import { studentService } from '../services/studentService';
import { courseService } from '../services/courseService';
import { departmentService } from '../services/departmentService';
import { cycleService } from '../services/cycleService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { Pagination } from '../components/common/Pagination';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

const CANONICAL_STATUSES = [
  'DRAFT',
  'SUBMITTED',
  'UNDER_REVIEW',
  'DOCUMENTS_REQUIRED',
  'APPROVED',
  'REJECTED',
  'WAITLISTED',
  'WITHDRAWN'
];

export function Applications() {
  const [applications, setApplications] = useState([]);
  const [courses, setCourses] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [students, setStudents] = useState([]);
  const [cycles, setCycles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & Pagination
  const [search, setSearch] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedCycle, setSelectedCycle] = useState('');
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, totalPages: 1 });

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [activeApp, setActiveApp] = useState(null);
  const [targetStatus, setTargetStatus] = useState('APPROVED');
  const [statusRemarks, setStatusRemarks] = useState('');

  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailedApp, setDetailedApp] = useState(null);
  const [appHistory, setAppHistory] = useState([]);

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [appToDelete, setAppToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form for new application
  const [newAppForm, setNewAppForm] = useState({
    student_id: '',
    course_id: '',
    cycle_id: '',
    application_date: new Date().toISOString().split('T')[0],
    remarks: ''
  });

  const { success, error: toastError } = useToast();

  const fetchAuxiliaryData = async () => {
    try {
      const [cRes, dRes, sRes, cyRes] = await Promise.all([
        courseService.getAll(),
        departmentService.getAll(),
        studentService.getAll({ limit: 100 }),
        cycleService.getAll()
      ]);
      setCourses(cRes.data || []);
      setDepartments(dRes.data || []);
      setStudents(sRes.data || []);
      setCycles(cyRes.data || []);
    } catch (_) {}
  };

  const fetchApplications = async (page = 1) => {
    setLoading(true);
    setError(null);
    try {
      const res = await applicationService.getAll({
        page,
        limit: 10,
        search,
        status: selectedStatus || undefined,
        course_id: selectedCourse || undefined,
        department_id: selectedDept || undefined,
        cycle_id: selectedCycle || undefined
      });
      setApplications(res.data || []);
      setPagination(res.pagination || { page: 1, limit: 10, total: 0, totalPages: 1 });
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load admission applications from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuxiliaryData();
  }, []);

  useEffect(() => {
    fetchApplications(1);
  }, [search, selectedStatus, selectedCourse, selectedDept, selectedCycle]);

  const handleOpenStatusModal = (app, status) => {
    setActiveApp(app);
    setTargetStatus(status);
    if (status === 'APPROVED') {
      setStatusRemarks('Academic credentials and merit verified for enrollment.');
    } else if (status === 'REJECTED') {
      setStatusRemarks('Does not meet minimum departmental cut-off criteria.');
    } else if (status === 'DOCUMENTS_REQUIRED') {
      setStatusRemarks('Awaiting original 12th standard mark-sheet and transfer certificate.');
    } else if (status === 'WAITLISTED') {
      setStatusRemarks('Placed on waiting list based on merit ranking.');
    } else {
      setStatusRemarks('');
    }
    setStatusModalOpen(true);
  };

  const handleStatusSubmit = async e => {
    e.preventDefault();
    if (!activeApp) return;
    setSubmitting(true);
    try {
      await applicationService.updateStatus(activeApp.application_id, targetStatus, statusRemarks, statusRemarks);
      success(`Application #${activeApp.application_id} updated to ${targetStatus}.`);
      setStatusModalOpen(false);
      setActiveApp(null);
      fetchApplications(pagination.page);
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to update application status.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateApplication = async e => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await applicationService.create({
        student_id: parseInt(newAppForm.student_id, 10),
        course_id: parseInt(newAppForm.course_id, 10),
        cycle_id: newAppForm.cycle_id ? parseInt(newAppForm.cycle_id, 10) : null,
        application_date: newAppForm.application_date,
        remarks: newAppForm.remarks
      });
      success('Admission application submitted successfully.');
      setCreateModalOpen(false);
      fetchApplications(pagination.page);
    } catch (err) {
      toastError(err.response?.data?.message || 'Error creating application.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!appToDelete) return;
    setSubmitting(true);
    try {
      await applicationService.delete(appToDelete.application_id);
      success(`Application #${appToDelete.application_id} removed.`);
      setDeleteConfirmOpen(false);
      setAppToDelete(null);
      fetchApplications(pagination.page);
    } catch (err) {
      toastError(err.response?.data?.message || 'Failed to delete application.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDetail = async app => {
    try {
      const res = await applicationService.getById(app.application_id);
      setDetailedApp(res.data);
      setAppHistory(res.data.history || []);
      setDetailModalOpen(true);
    } catch (err) {
      toastError(err.response?.data?.message || 'Could not load application details.');
    }
  };

  const columns = [
    {
      header: 'App Number',
      key: 'app_no',
      render: row => (
        <div>
          <span className="font-mono text-xs font-bold text-blue-700">
            {row.application_number || `APP-${row.application_id}`}
          </span>
          <p className="text-[11px] text-slate-400 font-mono">ID: #{row.application_id}</p>
        </div>
      )
    },
    {
      header: 'Applicant Student',
      key: 'student',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.student_name}</span>
          <p className="text-xs text-slate-400">{row.student_email}</p>
        </div>
      )
    },
    {
      header: 'Merit / Score',
      key: 'scores',
      render: row => (
        <div className="text-xs">
          <span className="font-semibold text-emerald-700">{row.student_marks}%</span>
          {row.student_rank && (
            <span className="ml-1 text-[11px] text-blue-600 bg-blue-50 px-1 rounded">
              Rank #{row.student_rank}
            </span>
          )}
        </div>
      )
    },
    {
      header: 'Course & Faculty',
      key: 'course',
      render: row => (
        <div>
          <span className="font-medium text-slate-800 text-xs">{row.course_name}</span>
          <p className="text-[11px] text-slate-400">{row.department_name}</p>
        </div>
      )
    },
    {
      header: 'Admission Cycle',
      key: 'cycle',
      render: row => (
        <span className="text-xs text-slate-600 font-medium">
          {row.cycle_name || 'General Admission'}
        </span>
      )
    },
    {
      header: 'Date',
      accessor: 'application_date',
      className: 'font-mono text-xs text-slate-600'
    },
    {
      header: 'Status',
      key: 'status',
      render: row => <Badge status={row.status} />
    },
    {
      header: 'Review & Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5" onClick={e => e.stopPropagation()}>
          <button
            onClick={() => handleOpenDetail(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
            title="View Full Dossier & History"
          >
            <Eye className="w-4 h-4" />
          </button>

          {row.status !== 'APPROVED' && row.status !== 'Approved' && (
            <button
              onClick={() => handleOpenStatusModal(row, 'APPROVED')}
              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 transition"
              title="Approve / Admit"
            >
              <CheckCircle className="w-4 h-4" />
            </button>
          )}

          {row.status !== 'REJECTED' && row.status !== 'Rejected' && (
            <button
              onClick={() => handleOpenStatusModal(row, 'REJECTED')}
              className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 transition"
              title="Reject Application"
            >
              <XCircle className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={() => handleOpenStatusModal(row, row.status)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Review Status / Transition"
          >
            <Clock className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              setAppToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Application"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Admission Applications"
        description="Review student enrollment dossiers, verify merit cutoffs, update admission statuses with ACID transactions, and track status history"
        breadcrumbs={['Admissions Portal', 'Applications']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchApplications(pagination.page)}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => setCreateModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              New Application
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={() => fetchApplications(pagination.page)} />}

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by student name, email, or application #..."
          className="flex-1 w-full"
        />

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Statuses</option>
            {CANONICAL_STATUSES.map(st => (
              <option key={st} value={st}>
                {st.replace('_', ' ')}
              </option>
            ))}
          </select>

          {/* Admission Cycle Filter */}
          <select
            value={selectedCycle}
            onChange={e => setSelectedCycle(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Cycles</option>
            {cycles.map(cy => (
              <option key={cy.cycle_id} value={cy.cycle_id}>
                {cy.cycle_name}
              </option>
            ))}
          </select>

          {/* Department Filter */}
          <select
            value={selectedDept}
            onChange={e => setSelectedDept(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Departments</option>
            {departments.map(d => (
              <option key={d.department_id} value={d.department_id}>
                {d.department_name}
              </option>
            ))}
          </select>

          {/* Course Filter */}
          <select
            value={selectedCourse}
            onChange={e => setSelectedCourse(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Courses</option>
            {courses.map(c => (
              <option key={c.course_id} value={c.course_id}>
                {c.course_name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={applications}
        loading={loading}
        emptyTitle="No applications found"
        emptyDescription="No applications match the current criteria."
        emptyActionLabel="Submit Application"
        onEmptyAction={() => setCreateModalOpen(true)}
      />

      <Pagination pagination={pagination} onPageChange={fetchApplications} />

      {/* Approve / Reject / Transition Decision Modal */}
      <Modal
        isOpen={statusModalOpen}
        onClose={() => setStatusModalOpen(false)}
        title="Review & Transition Application Status"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleStatusSubmit} className="space-y-4">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs space-y-1">
            <p className="font-semibold text-slate-800">
              Student: {activeApp?.student_name} (ID: #{activeApp?.student_id})
            </p>
            <p className="text-slate-600">Application #: {activeApp?.application_number || `#${activeApp?.application_id}`}</p>
            <p className="text-slate-600">Course: {activeApp?.course_name}</p>
            <p className="text-slate-600">Current Status: <span className="font-bold">{activeApp?.status}</span></p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select New Target Status *
            </label>
            <select
              value={targetStatus}
              onChange={e => setTargetStatus(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none font-medium"
            >
              {CANONICAL_STATUSES.map(st => (
                <option key={st} value={st}>
                  {st.replace('_', ' ')}
                </option>
              ))}
            </select>
          </div>

          {['APPROVED', 'Approved'].includes(targetStatus) && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100 text-xs text-emerald-800">
              <span className="font-semibold block mb-0.5">Automated RDBMS Transaction Note:</span>
              Approving this application will execute an atomic multi-table transaction that updates the status, logs an audit entry to <code className="font-mono bg-emerald-100/80 px-1 py-0.5 rounded">application_status_history</code>, and enrolls the student into the course department.
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Reviewer Notes / Justification Remarks
            </label>
            <textarea
              rows={3}
              value={statusRemarks}
              onChange={e => setStatusRemarks(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
              placeholder="State merit check, document compliance or reason..."
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setStatusModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Updating in MySQL...' : 'Commit Status Change'}
            </button>
          </div>
        </form>
      </Modal>

      {/* New Application Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        title="Submit New Admission Application"
      >
        <form onSubmit={handleCreateApplication} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select Student *
            </label>
            <select
              required
              value={newAppForm.student_id}
              onChange={e => setNewAppForm({ ...newAppForm, student_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Choose a registered student</option>
              {students.map(s => (
                <option key={s.student_id} value={s.student_id}>
                  #{s.student_id} - {s.name} ({s.email}) — Marks: {s.marks}%
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select Degree Course *
            </label>
            <select
              required
              value={newAppForm.course_id}
              onChange={e => setNewAppForm({ ...newAppForm, course_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Choose degree course program</option>
              {courses.map(c => (
                <option key={c.course_id} value={c.course_id}>
                  {c.course_name} ({c.department_name}) — Seats: {c.total_seats || 'N/A'}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Admission Intake Cycle
            </label>
            <select
              value={newAppForm.cycle_id}
              onChange={e => setNewAppForm({ ...newAppForm, cycle_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Select cycle (optional)</option>
              {cycles.map(cy => (
                <option key={cy.cycle_id} value={cy.cycle_id}>
                  {cy.cycle_name} ({cy.status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Application Date *
            </label>
            <input
              type="date"
              required
              value={newAppForm.application_date}
              onChange={e => setNewAppForm({ ...newAppForm, application_date: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Initial Remarks
            </label>
            <textarea
              rows={2}
              value={newAppForm.remarks}
              onChange={e => setNewAppForm({ ...newAppForm, remarks: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              placeholder="Optional counseling or quota remarks..."
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setCreateModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Submit Application'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Full Application Dossier & Status Audit History */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Application Review Dossier & Status History"
        maxWidth="max-w-3xl"
      >
        {detailedApp && (
          <div className="space-y-6">
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-slate-900">
                    {detailedApp.application_number || `Application #${detailedApp.application_id}`}
                  </h3>
                  <Badge status={detailedApp.status} />
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Submission Date: <span className="font-mono">{detailedApp.application_date}</span> • Cycle: <span className="font-semibold text-slate-700">{detailedApp.cycle_name || 'Standard'}</span>
                </p>
              </div>
            </div>

            {/* Applicant details */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-3 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Student Academic Record
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block">Student Name:</span>
                  <span className="font-semibold text-slate-800">{detailedApp.student_name}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Email Address:</span>
                  <span className="font-medium text-slate-700">{detailedApp.student_email}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Phone Contact:</span>
                  <span className="font-mono text-slate-700">{detailedApp.student_phone}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Entrance Marks:</span>
                  <span className="font-bold text-emerald-600">{detailedApp.student_marks}%</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Board Scores:</span>
                  <span className="font-medium text-slate-700">
                    10th: {detailedApp.tenth_marks || 'N/A'}% / 12th: {detailedApp.twelfth_marks || 'N/A'}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Merit Rank:</span>
                  <span className="font-semibold text-blue-600">
                    {detailedApp.student_rank ? `#${detailedApp.student_rank}` : 'Unranked'}
                  </span>
                </div>
              </div>
            </div>

            {/* Program selected */}
            <div className="p-4 rounded-xl bg-white border border-slate-200/80">
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2">Program Selection</h4>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <p className="font-semibold text-slate-800 text-sm">{detailedApp.course_name}</p>
                  <p className="text-xs text-slate-500">Department: {detailedApp.department_name}</p>
                </div>
                {detailedApp.remarks && (
                  <div className="text-xs bg-slate-50 p-2 rounded-lg border border-slate-200 max-w-sm">
                    <span className="text-slate-400 block font-semibold text-[10px] uppercase">Applicant Note:</span>
                    <span className="text-slate-700">{detailedApp.remarks}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Application Status History (Relational Audit Trail) */}
            <div>
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2 flex items-center gap-1.5">
                <History className="w-4 h-4 text-purple-600" />
                Relational Status History (Audit Trail)
              </h4>
              {appHistory.length === 0 ? (
                <div className="p-4 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-500">
                  No status transitions logged yet.
                </div>
              ) : (
                <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                      <tr>
                        <th className="px-3 py-2.5">Old Status</th>
                        <th className="px-3 py-2.5">New Status</th>
                        <th className="px-3 py-2.5">Auditor / User</th>
                        <th className="px-3 py-2.5">Date & Time</th>
                        <th className="px-3 py-2.5">Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {appHistory.map((item, idx) => (
                        <tr key={item.history_id || idx} className="hover:bg-slate-50/50">
                          <td className="px-3 py-2">
                            <span className="font-medium text-slate-500">
                              {item.old_status || 'Initial Submission'}
                            </span>
                          </td>
                          <td className="px-3 py-2 font-semibold">
                            <Badge status={item.new_status} />
                          </td>
                          <td className="px-3 py-2 font-mono text-[11px] text-slate-600">
                            {item.changed_by || 'system'}
                          </td>
                          <td className="px-3 py-2 font-mono text-[11px] text-slate-500">
                            {item.changed_at ? new Date(item.changed_at).toLocaleString() : 'N/A'}
                          </td>
                          <td className="px-3 py-2 text-slate-700">
                            {item.remarks || '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Fee Payment Ledger (Table 14 - Clearly Labeled Management Record) */}
            <div>
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                Admission Fee Payment Ledger
              </h4>
              {!detailedApp.payments || detailedApp.payments.length === 0 ? (
                <div className="p-3.5 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-500 bg-slate-50/50">
                  No payment settlement recorded yet for this admission application.
                </div>
              ) : (
                <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                      <tr>
                        <th className="px-3 py-2.5">Transaction Ref</th>
                        <th className="px-3 py-2.5">Amount</th>
                        <th className="px-3 py-2.5">Status</th>
                        <th className="px-3 py-2.5">Settlement Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {detailedApp.payments.map((p, idx) => (
                        <tr key={p.payment_id || idx} className="hover:bg-slate-50/50">
                          <td className="px-3 py-2 font-mono font-medium text-slate-800">
                            {p.transaction_reference}
                          </td>
                          <td className="px-3 py-2 font-bold text-emerald-600">
                            ₹{Number(p.amount).toLocaleString()} {p.currency || 'INR'}
                          </td>
                          <td className="px-3 py-2">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              {p.status}
                            </span>
                          </td>
                          <td className="px-3 py-2 font-mono text-[11px] text-slate-500">
                            {p.paid_at ? new Date(p.paid_at).toLocaleString() : 'N/A'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Delete Admission Application"
        message={`Are you sure you want to permanently delete application #${appToDelete?.application_id}?`}
        confirmText="Delete Application"
        loading={submitting}
      />
    </div>
  );
}
