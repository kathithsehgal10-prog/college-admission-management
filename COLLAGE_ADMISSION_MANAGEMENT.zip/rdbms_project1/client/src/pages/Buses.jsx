import React, { useState, useEffect } from 'react';
import {
  Plus,
  Bus,
  Users,
  Eye,
  Edit2,
  Trash2,
  RefreshCw,
  MapPin,
  CheckCircle2
} from 'lucide-react';
import { busService } from '../services/busService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function Buses() {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  // Modals
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingBus, setEditingBus] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailedBus, setDetailedBus] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [busToDelete, setBusToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const initialForm = {
    bus_number: '',
    route: '',
    destination: 'University Campus Gate 1',
    capacity: 50
  };
  const [formData, setFormData] = useState(initialForm);
  const [formErrors, setFormErrors] = useState({});

  const { success, error: toastError } = useToast();

  const fetchBuses = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await busService.getAll({ search });
      setBuses(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load bus transportation records from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBuses();
  }, [search]);

  const handleOpenAdd = () => {
    setEditingBus(null);
    setFormData(initialForm);
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenEdit = bus => {
    setEditingBus(bus);
    setFormData({
      bus_number: bus.bus_number || '',
      route: bus.route || '',
      destination: bus.destination || '',
      capacity: bus.total_capacity || 50
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenDetail = async bus => {
    try {
      const res = await busService.getById(bus.bus_id);
      setDetailedBus(res.data);
      setDetailModalOpen(true);
    } catch (err) {
      toastError(err.response?.data?.message || 'Could not load passenger list.');
    }
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setFormErrors({});
    setSubmitting(true);

    const payload = {
      ...formData,
      capacity: parseInt(formData.capacity, 10)
    };

    try {
      if (editingBus) {
        await busService.update(editingBus.bus_id, payload);
        success(`Bus "${formData.bus_number}" updated.`);
      } else {
        await busService.create(payload);
        success(`Bus "${formData.bus_number}" added.`);
      }
      setFormModalOpen(false);
      fetchBuses();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errorsObj = {};
        err.response.data.errors.forEach(issue => {
          errorsObj[issue.field] = issue.message;
        });
        setFormErrors(errorsObj);
      } else {
        toastError(err.response?.data?.message || 'Error saving bus record.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!busToDelete) return;
    setSubmitting(true);
    try {
      await busService.delete(busToDelete.bus_id);
      success(`Bus "${busToDelete.bus_number}" deleted.`);
      setDeleteConfirmOpen(false);
      setBusToDelete(null);
      fetchBuses();
    } catch (err) {
      toastError(
        err.response?.data?.message ||
        'Cannot delete bus with active or historical student assignments.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'ID',
      accessor: 'bus_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Bus Number',
      key: 'bus_num',
      render: row => (
        <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-800">
          {row.bus_number}
        </span>
      )
    },
    {
      header: 'Route Itinerary',
      key: 'route',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800 text-xs">{row.route}</span>
          <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
            <MapPin className="w-3 h-3 text-slate-400" />
            Destination: {row.destination}
          </p>
        </div>
      )
    },
    {
      header: 'Capacity',
      key: 'cap',
      render: row => (
        <span className="font-semibold text-xs text-slate-700">{row.total_capacity} seats</span>
      )
    },
    {
      header: 'Assigned Passengers',
      key: 'occ',
      render: row => {
        const pct = row.total_capacity > 0 ? Math.round((row.occupied_seats / row.total_capacity) * 100) : 0;
        return (
          <div className="w-36">
            <div className="flex justify-between text-xs text-slate-600 mb-1">
              <span className="font-medium">{row.occupied_seats} seats</span>
              <span className="text-slate-400 font-mono">{pct}%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  pct >= 100 ? 'bg-rose-500' : pct > 80 ? 'bg-amber-500' : 'bg-blue-600'
                }`}
                style={{ width: `${Math.min(100, pct)}%` }}
              />
            </div>
          </div>
        );
      }
    },
    {
      header: 'Seats Available',
      key: 'avail',
      render: row => (
        <span
          className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
            row.available_seats > 0
              ? 'text-emerald-700 bg-emerald-50'
              : 'text-rose-700 bg-rose-50'
          }`}
        >
          {row.available_seats > 0 ? `${row.available_seats} available` : 'Full'}
        </span>
      )
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={() => handleOpenDetail(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
            title="View Passenger Roster"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Edit Bus Route"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setBusToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Bus"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Bus Transportation Management"
        description="University transit fleet, routes, seat capacity limits, and passenger quotas"
        breadcrumbs={['Admissions Portal', 'Bus Transportation']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchBuses}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Add Bus Route
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchBuses} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by bus number, route, or destination..."
          className="w-full sm:max-w-md"
        />
      </div>

      <DataTable
        columns={columns}
        data={buses}
        loading={loading}
        emptyTitle="No buses found"
        emptyDescription="Register campus transit buses to assign transportation to students."
        emptyActionLabel="Add Bus Route"
        onEmptyAction={handleOpenAdd}
      />

      {/* Add / Edit Modal */}
      <Modal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        title={editingBus ? `Edit Bus: ${editingBus.bus_number}` : 'Register Bus Route'}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Bus Identifier / Number *
              </label>
              <input
                type="text"
                required
                value={formData.bus_number}
                onChange={e => setFormData({ ...formData, bus_number: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none font-mono"
                placeholder="e.g. BUS-01"
              />
              {formErrors.bus_number && (
                <p className="text-xs text-rose-600 mt-1">{formErrors.bus_number}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Passenger Seat Capacity *
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.capacity}
                onChange={e => setFormData({ ...formData, capacity: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="50"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Route Itinerary *
            </label>
            <input
              type="text"
              required
              value={formData.route}
              onChange={e => setFormData({ ...formData, route: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              placeholder="e.g. Route 1: Electronic City -> Silk Board -> HSR Layout"
            />
            {formErrors.route && <p className="text-xs text-rose-600 mt-1">{formErrors.route}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Campus Destination / Terminal *
            </label>
            <input
              type="text"
              required
              value={formData.destination}
              onChange={e => setFormData({ ...formData, destination: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              placeholder="e.g. University Campus Gate 1"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFormModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingBus ? 'Update Bus' : 'Register Bus'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Passengers Modal */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Bus Commuter Passenger Roster"
        maxWidth="max-w-2xl"
      >
        {detailedBus && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 flex justify-between items-start">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{detailedBus.bus_number}</h3>
                <p className="text-xs text-slate-600">{detailedBus.route}</p>
                <p className="text-[11px] text-slate-400">Terminal: {detailedBus.destination}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 text-center text-xs">
              <div className="p-2.5 bg-slate-50 rounded-lg">
                <span className="font-bold text-slate-800 text-sm block">{detailedBus.total_capacity}</span>
                <span className="text-slate-400">Seat Capacity</span>
              </div>
              <div className="p-2.5 bg-blue-50 rounded-lg">
                <span className="font-bold text-blue-700 text-sm block">{detailedBus.occupied_seats}</span>
                <span className="text-blue-600">Assigned</span>
              </div>
              <div className="p-2.5 bg-emerald-50 rounded-lg">
                <span className="font-bold text-emerald-700 text-sm block">{detailedBus.available_seats}</span>
                <span className="text-emerald-600">Vacant Seats</span>
              </div>
            </div>

            <h4 className="text-xs font-bold uppercase text-slate-500">Currently Assigned Commuters</h4>
            {detailedBus.passengers && detailedBus.passengers.length > 0 ? (
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden max-h-64 overflow-y-auto">
                {detailedBus.passengers.map(p => (
                  <div key={p.allocation_id} className="p-3 flex items-center justify-between text-xs bg-white">
                    <div>
                      <span className="font-semibold text-slate-800">{p.student_name}</span>
                      <p className="text-[11px] text-slate-400">Assigned: {p.allocation_date}</p>
                    </div>
                    <span className="font-mono text-slate-500">{p.phone}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No passengers currently assigned to this bus route.</p>
            )}
          </div>
        )}
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Delete Transit Bus"
        message={`Are you sure you want to remove bus "${busToDelete?.bus_number}"?`}
        confirmText="Delete Bus"
        loading={submitting}
      />
    </div>
  );
}
