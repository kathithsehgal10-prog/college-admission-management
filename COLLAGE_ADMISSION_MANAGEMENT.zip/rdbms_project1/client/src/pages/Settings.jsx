import React, { useState } from 'react';
import {
  User,
  Database,
  Shield,
  Server,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  LogOut,
  Terminal,
  Key
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { PageHeader } from '../components/common/PageHeader';
import { useToast } from '../contexts/ToastContext';
import { useNavigate } from 'react-router-dom';

export function Settings() {
  const { admin, logout, dbHealth, refreshHealth } = useAuth();
  const [rechecking, setRechecking] = useState(false);
  const { success, error: toastError } = useToast();
  const navigate = useNavigate();

  const handleRecheck = async () => {
    setRechecking(true);
    const result = await refreshHealth();
    setTimeout(() => {
      setRechecking(false);
      if (result.connected) {
        success('MySQL database connection is active and healthy.');
      } else {
        toastError(`Database check: ${result.message}`);
      }
    }, 400);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader
        title="Settings & System Diagnostics"
        description="Administrator account details, MySQL database connection status, and configuration"
        breadcrumbs={['Admissions Portal', 'Settings']}
      />

      {/* Admin Profile Details */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg shadow-sm shadow-blue-500/20">
            {admin?.admin_name ? admin.admin_name.charAt(0).toUpperCase() : 'A'}
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800">{admin?.admin_name || 'Administrator'}</h3>
            <p className="text-xs text-slate-500">{admin?.email}</p>
          </div>
          <span className="ml-auto px-2.5 py-1 text-xs font-semibold rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            {admin?.role || 'System Admin'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-xl">
            <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Admin ID</span>
            <span className="font-mono font-semibold text-slate-800">#{admin?.admin_id || 1}</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl">
            <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Authentication Scheme</span>
            <span className="font-medium text-slate-800">JSON Web Tokens (JWT) + Bcrypt</span>
          </div>
        </div>

        <div className="mt-5 pt-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={handleLogout}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out of Administration Portal
          </button>
        </div>
      </div>

      {/* Database Diagnostic Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-xl ${
                dbHealth?.connected
                  ? 'bg-emerald-50 text-emerald-600'
                  : 'bg-amber-50 text-amber-600'
              }`}
            >
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">MySQL Relational Engine Status</h3>
              <p className="text-xs text-slate-500">Connection pool diagnostic and configuration</p>
            </div>
          </div>

          <button
            onClick={handleRecheck}
            disabled={rechecking}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${rechecking ? 'animate-spin' : ''}`} />
            {rechecking ? 'Testing...' : 'Test Connection'}
          </button>
        </div>

        <div className="mt-5 space-y-4">
          <div
            className={`p-4 rounded-xl border text-xs flex items-start gap-3 ${
              dbHealth?.connected
                ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                : 'bg-amber-50/60 border-amber-200 text-amber-900'
            }`}
          >
            {dbHealth?.connected ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <p className="font-bold text-sm">
                {dbHealth?.connected ? 'MySQL Connected & Ready' : 'Database Disconnected / Pending Configuration'}
              </p>
              <p className="text-xs opacity-90">{dbHealth?.message}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl">
              <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Target Database</span>
              <span className="font-mono font-semibold text-slate-800">{dbHealth?.name || 'college_admission'}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl">
              <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Database Host</span>
              <span className="font-mono text-slate-800">{dbHealth?.host || 'localhost'}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl">
              <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Port</span>
              <span className="font-mono text-slate-800">{dbHealth?.port || 3306}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl">
              <span className="text-slate-400 block mb-0.5 uppercase font-semibold">Storage Engine</span>
              <span className="font-mono font-semibold text-blue-700">InnoDB / MySQL {dbHealth?.version || ''}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-2 mb-3">
          <Terminal className="w-5 h-5 text-blue-400" />
          <h3 className="text-sm font-bold text-slate-200">Demonstration verification</h3>
        </div>
        <p className="text-sm text-slate-300 mb-3">
          Confirm the database connection above, then run the project's database check before your demonstration.
        </p>
        <code className="block p-3 rounded-xl bg-slate-800 text-blue-300 text-sm">npm run db:check</code>
        <p className="text-xs text-slate-400 mt-3">
          This verifies the actual tables, views and SQL demonstrations. Database setup is documented in the project README.
        </p>
      </div>
    </div>
  );
}
