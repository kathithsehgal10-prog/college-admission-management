import React, { useState, useEffect } from 'react';
import {
  Plus,
  Home,
  Users,
  Eye,
  Edit2,
  Trash2,
  RefreshCw,
  BedDouble,
  CheckCircle2
} from 'lucide-react';
import { hostelService } from '../services/hostelService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function Hostels() {
  const [hostels, setHostels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  // Modals
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingHostel, setEditingHostel] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailedHostel, setDetailedHostel] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [hostelToDelete, setHostelToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const initialForm = {
    name: '',
    type: 'Co-ed',
    address: '',
    number_of_seats: 100
  };
  const [formData, setFormData] = useState(initialForm);
  const [formErrors, setFormErrors] = useState({});

  const { success, error: toastError } = useToast();

  const fetchHostels = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await hostelService.getAll({ search });
      setHostels(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load hostels from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHostels();
  }, [search]);

  const handleOpenAdd = () => {
    setEditingHostel(null);
    setFormData(initialForm);
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenEdit = hostel => {
    setEditingHostel(hostel);
    setFormData({
      name: hostel.name || '',
      type: hostel.type || 'Co-ed',
      address: hostel.address || '',
      number_of_seats: hostel.total_capacity || 100
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenDetail = async hostel => {
    try {
      const res = await hostelService.getById(hostel.hostel_id);
      setDetailedHostel(res.data);
      setDetailModalOpen(true);
    } catch (err) {
      toastError(err.response?.data?.message || 'Could not load hostel residents.');
    }
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setFormErrors({});
    setSubmitting(true);

    const payload = {
      ...formData,
      number_of_seats: parseInt(formData.number_of_seats, 10)
    };

    try {
      if (editingHostel) {
        await hostelService.update(editingHostel.hostel_id, payload);
        success(`Hostel "${formData.name}" updated successfully.`);
      } else {
        await hostelService.create(payload);
        success(`Hostel "${formData.name}" registered successfully.`);
      }
      setFormModalOpen(false);
      fetchHostels();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errorsObj = {};
        err.response.data.errors.forEach(issue => {
          errorsObj[issue.field] = issue.message;
        });
        setFormErrors(errorsObj);
      } else {
        toastError(err.response?.data?.message || 'Error saving hostel.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!hostelToDelete) return;
    setSubmitting(true);
    try {
      await hostelService.delete(hostelToDelete.hostel_id);
      success(`Hostel "${hostelToDelete.name}" deleted.`);
      setDeleteConfirmOpen(false);
      setHostelToDelete(null);
      fetchHostels();
    } catch (err) {
      toastError(
        err.response?.data?.message ||
        'Cannot delete hostel with existing resident allocations.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'ID',
      accessor: 'hostel_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Hostel Name',
      key: 'name',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.name}</span>
          <p className="text-xs text-slate-400 truncate max-w-sm">{row.address}</p>
        </div>
      )
    },
    {
      header: 'Type',
      key: 'type',
      render: row => <Badge status={row.type} />
    },
    {
      header: 'Capacity',
      key: 'cap',
      render: row => (
        <span className="font-semibold text-xs text-slate-700">
          {row.total_capacity} beds
        </span>
      )
    },
    {
      header: 'Allocated Occupancy',
      key: 'occ',
      render: row => {
        const pct = row.total_capacity > 0 ? Math.round((row.occupied_seats / row.total_capacity) * 100) : 0;
        return (
          <div className="w-36">
            <div className="flex justify-between text-xs text-slate-600 mb-1">
              <span className="font-medium">{row.occupied_seats} beds</span>
              <span className="text-slate-400 font-mono">{pct}%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  pct >= 100 ? 'bg-rose-500' : pct > 80 ? 'bg-amber-500' : 'bg-blue-600'
                }`}
                style={{ width: `${Math.min(100, pct)}%` }}
              />
            </div>
          </div>
        );
      }
    },
    {
      header: 'Available',
      key: 'avail',
      render: row => (
        <span
          className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
            row.available_seats > 0
              ? 'text-emerald-700 bg-emerald-50'
              : 'text-rose-700 bg-rose-50'
          }`}
        >
          {row.available_seats > 0 ? `${row.available_seats} vacant` : 'Full'}
        </span>
      )
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={() => handleOpenDetail(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
            title="View Residents"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Edit Hostel"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setHostelToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Hostel"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Hostel Management"
        description="Campus residential buildings, bed capacities, and real-time occupancy monitoring"
        breadcrumbs={['Admissions Portal', 'Hostels']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchHostels}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Add Hostel
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchHostels} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search hostels by name or address..."
          className="w-full sm:max-w-md"
        />
      </div>

      <DataTable
        columns={columns}
        data={hostels}
        loading={loading}
        emptyTitle="No hostels found"
        emptyDescription="Add residential hostels to start allocating beds to admitted students."
        emptyActionLabel="Add Hostel"
        onEmptyAction={handleOpenAdd}
      />

      {/* Add / Edit Modal */}
      <Modal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        title={editingHostel ? `Edit Hostel: ${editingHostel.name}` : 'Register New Hostel'}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Hostel Name *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              placeholder="e.g. Aryabhata Bhavan (Boys Hostel)"
            />
            {formErrors.name && <p className="text-xs text-rose-600 mt-1">{formErrors.name}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Hostel Type *
              </label>
              <select
                value={formData.type}
                onChange={e => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              >
                <option value="Boys">Boys</option>
                <option value="Girls">Girls</option>
                <option value="Co-ed">Co-ed</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Total Bed Capacity *
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.number_of_seats}
                onChange={e => setFormData({ ...formData, number_of_seats: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
                placeholder="100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Campus Address / Location *
            </label>
            <textarea
              rows={2}
              required
              value={formData.address}
              onChange={e => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              placeholder="e.g. North Campus, Block 1, University Grounds"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFormModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingHostel ? 'Update Hostel' : 'Register Hostel'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Residents Modal */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Hostel Resident Roster"
        maxWidth="max-w-2xl"
      >
        {detailedHostel && (
          <div className="space-y-4">
            <div className="pb-3 border-b border-slate-100 flex justify-between items-start">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{detailedHostel.name}</h3>
                <p className="text-xs text-slate-500">{detailedHostel.address}</p>
              </div>
              <Badge status={detailedHostel.type} />
            </div>

            <div className="grid grid-cols-3 gap-3 text-center text-xs">
              <div className="p-2.5 bg-slate-50 rounded-lg">
                <span className="font-bold text-slate-800 text-sm block">{detailedHostel.total_capacity}</span>
                <span className="text-slate-400">Total Capacity</span>
              </div>
              <div className="p-2.5 bg-blue-50 rounded-lg">
                <span className="font-bold text-blue-700 text-sm block">{detailedHostel.occupied_seats}</span>
                <span className="text-blue-600">Occupied</span>
              </div>
              <div className="p-2.5 bg-emerald-50 rounded-lg">
                <span className="font-bold text-emerald-700 text-sm block">{detailedHostel.available_seats}</span>
                <span className="text-emerald-600">Vacant Beds</span>
              </div>
            </div>

            <h4 className="text-xs font-bold uppercase text-slate-500">Currently Allocated Students</h4>
            {detailedHostel.residents && detailedHostel.residents.length > 0 ? (
              <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden max-h-64 overflow-y-auto">
                {detailedHostel.residents.map(r => (
                  <div key={r.allocation_id} className="p-3 flex items-center justify-between text-xs bg-white">
                    <div>
                      <span className="font-semibold text-slate-800">{r.student_name}</span>
                      <p className="text-[11px] text-slate-400">
                        Room: {r.room_number || 'General'} | Allocated: {r.allocation_date}
                      </p>
                    </div>
                    <span className="font-mono text-slate-500">{r.phone}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No students currently allocated to this hostel.</p>
            )}
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Delete Hostel Facility"
        message={`Are you sure you want to delete hostel "${hostelToDelete?.name}"?`}
        confirmText="Delete Hostel"
        loading={submitting}
      />
    </div>
  );
}
