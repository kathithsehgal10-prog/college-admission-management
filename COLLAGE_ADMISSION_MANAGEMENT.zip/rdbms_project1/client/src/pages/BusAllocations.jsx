import React, { useState, useEffect } from 'react';
import {
  Plus,
  Bus,
  Ticket,
  User,
  XCircle,
  Trash2,
  RefreshCw,
  Search,
  CheckCircle2
} from 'lucide-react';
import { busService } from '../services/busService';
import { studentService } from '../services/studentService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function BusAllocations() {
  const [allocations, setAllocations] = useState([]);
  const [buses, setBuses] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [selectedBus, setSelectedBus] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [allocToDelete, setAllocToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const [formData, setFormData] = useState({
    student_id: '',
    bus_id: '',
    allocation_date: new Date().toISOString().split('T')[0],
    status: 'Active'
  });

  const { success, error: toastError } = useToast();

  const fetchAuxiliary = async () => {
    try {
      const [bRes, sRes] = await Promise.all([
        busService.getAll(),
        studentService.getAll({ limit: 100 })
      ]);
      setBuses(bRes.data || []);
      setStudents(sRes.data || []);
    } catch (_) {}
  };

  const fetchAllocations = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await busService.getAllocations({
        search,
        bus_id: selectedBus || undefined,
        status: selectedStatus || undefined
      });
      setAllocations(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load bus allocations from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuxiliary();
  }, []);

  useEffect(() => {
    fetchAllocations();
  }, [search, selectedBus, selectedStatus]);

  const handleCreate = async e => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await busService.createAllocation({
        student_id: parseInt(formData.student_id, 10),
        bus_id: parseInt(formData.bus_id, 10),
        allocation_date: formData.allocation_date,
        status: 'Active'
      });
      success('Transportation seat allocated successfully.');
      setCreateModalOpen(false);
      fetchAllocations();
      fetchAuxiliary();
    } catch (err) {
      toastError(
        err.response?.data?.message ||
        'Failed to allocate bus seat. Ensure student is not already assigned and bus capacity is available.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelAssignment = async alloc => {
    try {
      await busService.updateAllocation(alloc.allocation_id, {
        status: 'Cancelled'
      });
      success(`Transportation assignment cancelled for student "${alloc.student_name}".`);
      fetchAllocations();
      fetchAuxiliary();
    } catch (err) {
      toastError(err.response?.data?.message || 'Error updating bus allocation.');
    }
  };

  const handleDelete = async () => {
    if (!allocToDelete) return;
    setSubmitting(true);
    try {
      await busService.deleteAllocation(allocToDelete.allocation_id);
      success('Bus transportation assignment record removed.');
      setDeleteConfirmOpen(false);
      setAllocToDelete(null);
      fetchAllocations();
      fetchAuxiliary();
    } catch (err) {
      toastError(err.response?.data?.message || 'Error removing bus assignment.');
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'Alloc ID',
      accessor: 'allocation_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Assigned Student',
      key: 'student',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.student_name}</span>
          <p className="text-xs text-slate-400 font-mono">ID: #{row.student_id} | {row.student_phone}</p>
        </div>
      )
    },
    {
      header: 'Bus Number',
      key: 'bus',
      render: row => (
        <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-800">
          {row.bus_number}
        </span>
      )
    },
    {
      header: 'Route & Terminal',
      key: 'route',
      render: row => (
        <div>
          <span className="font-medium text-slate-800 text-xs">{row.route}</span>
          <p className="text-[11px] text-slate-400">To: {row.destination}</p>
        </div>
      )
    },
    {
      header: 'Date',
      accessor: 'allocation_date',
      className: 'font-mono text-xs text-slate-600'
    },
    {
      header: 'Status',
      key: 'status',
      render: row => <Badge status={row.status} />
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          {row.status === 'Active' && (
            <button
              onClick={() => handleCancelAssignment(row)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg transition"
              title="Cancel Route Assignment"
            >
              <XCircle className="w-3.5 h-3.5" />
              Cancel Pass
            </button>
          )}
          <button
            onClick={() => {
              setAllocToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Record"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Bus Transportation Allocations"
        description="Assign student transit passes, track fleet passenger quotas, and manage bus seats"
        breadcrumbs={['Admissions Portal', 'Bus Allocations']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchAllocations}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => {
                setFormData({
                  student_id: students[0]?.student_id || '',
                  bus_id: buses[0]?.bus_id || '',
                  allocation_date: new Date().toISOString().split('T')[0],
                  status: 'Active'
                });
                setCreateModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Assign Bus Pass
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchAllocations} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by student name, bus number, or route..."
          className="flex-1 w-full"
        />

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <select
            value={selectedBus}
            onChange={e => setSelectedBus(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Buses</option>
            {buses.map(b => (
              <option key={b.bus_id} value={b.bus_id}>
                {b.bus_number} ({b.available_seats} vacant)
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={allocations}
        loading={loading}
        emptyTitle="No bus transportation allocations found"
        emptyDescription="Assign transit passes to enrolled students."
        emptyActionLabel="Assign Bus Pass"
        onEmptyAction={() => setCreateModalOpen(true)}
      />

      {/* Assign Bus Pass Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        title="Assign Transit Bus Pass"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select Student *
            </label>
            <select
              required
              value={formData.student_id}
              onChange={e => setFormData({ ...formData, student_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Choose registered student</option>
              {students.map(s => (
                <option key={s.student_id} value={s.student_id}>
                  #{s.student_id} - {s.name} ({s.phone})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select Bus Route *
            </label>
            <select
              required
              value={formData.bus_id}
              onChange={e => setFormData({ ...formData, bus_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Choose bus itinerary</option>
              {buses.map(b => (
                <option key={b.bus_id} value={b.bus_id} disabled={b.available_seats <= 0}>
                  {b.bus_number} — {b.available_seats > 0 ? `${b.available_seats} seats free` : 'FULL'} ({b.route})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Pass Issue Date *
            </label>
            <input
              type="date"
              required
              value={formData.allocation_date}
              onChange={e => setFormData({ ...formData, allocation_date: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setCreateModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Assigning...' : 'Confirm Assignment'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Remove Bus Transportation Record"
        message={`Are you sure you want to delete the bus assignment record for student "${allocToDelete?.student_name}"?`}
        confirmText="Remove Record"
        loading={submitting}
      />
    </div>
  );
}
