import React, { useState, useEffect } from 'react';
import {
  Plus,
  BedDouble,
  Home,
  User,
  LogOut,
  Trash2,
  RefreshCw,
  Search,
  CheckCircle2
} from 'lucide-react';
import { hostelService } from '../services/hostelService';
import { studentService } from '../services/studentService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { Badge } from '../components/common/Badge';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function HostelAllocations() {
  const [allocations, setAllocations] = useState([]);
  const [hostels, setHostels] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [search, setSearch] = useState('');
  const [selectedHostel, setSelectedHostel] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [allocToDelete, setAllocToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const [formData, setFormData] = useState({
    student_id: '',
    hostel_id: '',
    room_number: '',
    allocation_date: new Date().toISOString().split('T')[0],
    status: 'Active'
  });

  const { success, error: toastError } = useToast();

  const fetchAuxiliary = async () => {
    try {
      const [hRes, sRes] = await Promise.all([
        hostelService.getAll(),
        studentService.getAll({ limit: 100 })
      ]);
      setHostels(hRes.data || []);
      setStudents(sRes.data || []);
    } catch (_) {}
  };

  const fetchAllocations = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await hostelService.getAllocations({
        search,
        hostel_id: selectedHostel || undefined,
        status: selectedStatus || undefined
      });
      setAllocations(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load hostel allocations from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuxiliary();
  }, []);

  useEffect(() => {
    fetchAllocations();
  }, [search, selectedHostel, selectedStatus]);

  const handleCreate = async e => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await hostelService.createAllocation({
        student_id: parseInt(formData.student_id, 10),
        hostel_id: parseInt(formData.hostel_id, 10),
        room_number: formData.room_number || null,
        allocation_date: formData.allocation_date,
        status: 'Active'
      });
      success('Hostel bed allocated successfully.');
      setCreateModalOpen(false);
      fetchAllocations();
      fetchAuxiliary(); // Refresh available seats
    } catch (err) {
      toastError(
        err.response?.data?.message ||
        'Failed to allocate hostel bed. Ensure student does not have another active room and hostel is not full.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleVacate = async alloc => {
    try {
      await hostelService.updateAllocation(alloc.allocation_id, {
        status: 'Vacated'
      });
      success(`Room vacated for student "${alloc.student_name}".`);
      fetchAllocations();
      fetchAuxiliary();
    } catch (err) {
      toastError(err.response?.data?.message || 'Error updating allocation status.');
    }
  };

  const handleDelete = async () => {
    if (!allocToDelete) return;
    setSubmitting(true);
    try {
      await hostelService.deleteAllocation(allocToDelete.allocation_id);
      success('Hostel allocation record removed.');
      setDeleteConfirmOpen(false);
      setAllocToDelete(null);
      fetchAllocations();
      fetchAuxiliary();
    } catch (err) {
      toastError(err.response?.data?.message || 'Error deleting allocation.');
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'Alloc ID',
      accessor: 'allocation_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Resident Student',
      key: 'student',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.student_name}</span>
          <p className="text-xs text-slate-400 font-mono">ID: #{row.student_id} | {row.student_gender}</p>
        </div>
      )
    },
    {
      header: 'Hostel Facility',
      key: 'hostel',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.hostel_name}</span>
          <p className="text-xs text-slate-400">{row.hostel_type}</p>
        </div>
      )
    },
    {
      header: 'Room',
      key: 'room',
      render: row => (
        <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
          {row.room_number || 'General'}
        </span>
      )
    },
    {
      header: 'Allocation Date',
      accessor: 'allocation_date',
      className: 'font-mono text-xs text-slate-600'
    },
    {
      header: 'Status',
      key: 'status',
      render: row => <Badge status={row.status} />
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          {row.status === 'Active' && (
            <button
              onClick={() => handleVacate(row)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg transition"
              title="Vacate Bed"
            >
              <LogOut className="w-3.5 h-3.5" />
              Vacate
            </button>
          )}
          <button
            onClick={() => {
              setAllocToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Record"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Hostel Allocations"
        description="Assign residential beds, track active occupancy, and manage room vacancies"
        breadcrumbs={['Admissions Portal', 'Hostel Allocations']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchAllocations}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => {
                setFormData({
                  student_id: students[0]?.student_id || '',
                  hostel_id: hostels[0]?.hostel_id || '',
                  room_number: '',
                  allocation_date: new Date().toISOString().split('T')[0],
                  status: 'Active'
                });
                setCreateModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Allocate Bed
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchAllocations} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by student name or room number..."
          className="flex-1 w-full"
        />

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <select
            value={selectedHostel}
            onChange={e => setSelectedHostel(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Hostels</option>
            {hostels.map(h => (
              <option key={h.hostel_id} value={h.hostel_id}>
                {h.name} ({h.available_seats} vacant)
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="py-2 px-3 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Vacated">Vacated</option>
          </select>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={allocations}
        loading={loading}
        emptyTitle="No hostel allocations found"
        emptyDescription="Allocate a hostel room to an enrolled student."
        emptyActionLabel="Allocate Bed"
        onEmptyAction={() => setCreateModalOpen(true)}
      />

      {/* Allocate Bed Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        title="Allocate Hostel Bed"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select Student *
            </label>
            <select
              required
              value={formData.student_id}
              onChange={e => setFormData({ ...formData, student_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Choose student applicant</option>
              {students.map(s => (
                <option key={s.student_id} value={s.student_id}>
                  #{s.student_id} - {s.name} ({s.gender})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Select Hostel Facility *
            </label>
            <select
              required
              value={formData.hostel_id}
              onChange={e => setFormData({ ...formData, hostel_id: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
            >
              <option value="">Choose hostel building</option>
              {hostels.map(h => (
                <option
                  key={h.hostel_id}
                  value={h.hostel_id}
                  disabled={h.available_seats <= 0}
                >
                  {h.name} — {h.available_seats > 0 ? `${h.available_seats} vacant` : 'FULL'}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Room Number
              </label>
              <input
                type="text"
                value={formData.room_number}
                onChange={e => setFormData({ ...formData, room_number: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none font-mono"
                placeholder="e.g. A-204"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Allocation Date *
              </label>
              <input
                type="date"
                required
                value={formData.allocation_date}
                onChange={e => setFormData({ ...formData, allocation_date: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setCreateModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Allocating...' : 'Confirm Allocation'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Remove Hostel Allocation"
        message={`Are you sure you want to remove the hostel allocation record for student "${allocToDelete?.student_name}"?`}
        confirmText="Remove Record"
        loading={submitting}
      />
    </div>
  );
}
