import React, { useState, useEffect } from 'react';
import {
  Download,
  FileSpreadsheet,
  BarChart3,
  Building2,
  Users,
  GraduationCap,
  Home,
  Bus,
  RefreshCw,
  Award
} from 'lucide-react';
import { reportService } from '../services/reportService';
import { PageHeader } from '../components/common/PageHeader';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { useToast } from '../contexts/ToastContext';

export function Reports() {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [downloading, setDownloading] = useState(null);

  const { success, error: toastError } = useToast();

  const fetchReports = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await reportService.getSummary();
      setReport(res.data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load aggregation reports from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleDownload = async type => {
    setDownloading(type);
    try {
      await reportService.downloadCsv(type);
      success(`Report "${type}" exported successfully.`);
    } catch (err) {
      toastError(err.response?.data?.message || `Failed to export ${type} report.`);
    } finally {
      setDownloading(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Relational Aggregation Reports"
          description="Analytical views and data export utilities"
          breadcrumbs={['Admissions Portal', 'Reports']}
        />
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center">
          <LoadingSpinner message="Calculating database aggregations..." size="lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Relational Aggregation Reports"
        description="Comprehensive analytical queries, faculty metrics, merit averages, and CSV exports"
        breadcrumbs={['Admissions Portal', 'Reports']}
        actions={
          <button
            onClick={fetchReports}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Recalculate
          </button>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchReports} />}

      {/* CSV Quick Export Actions */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
            Export Datasets (CSV)
          </h3>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Generate clean, formatted CSV spreadsheets directly from live database tables.
        </p>

        <div className="flex flex-wrap gap-2.5">
          {[
            { id: 'students', label: 'All Students List' },
            { id: 'applications', label: 'Admissions Applications' },
            { id: 'courses', label: 'Courses & Acceptance' },
            { id: 'hostel-allocations', label: 'Hostel Allocations' },
            { id: 'bus-allocations', label: 'Bus Allocations' },
            { id: 'payments', label: 'Fee Payments Ledger' }
          ].map(item => (
            <button
              key={item.id}
              onClick={() => handleDownload(item.id)}
              disabled={downloading === item.id}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition shadow-xs disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              {downloading === item.id ? 'Exporting...' : item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Merit & Score Statistics Summary */}
      {report?.meritSummary && (
        <div className="bg-gradient-to-r from-blue-900 to-slate-900 p-6 rounded-2xl text-white shadow-xl">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-blue-200">
              Admission Academic Merit Benchmarks
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-2xl font-bold">{report.meritSummary.total_students_scored || 0}</span>
              <span className="text-[11px] text-slate-400 block mt-1">Total Scored Applicants</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-2xl font-bold text-emerald-400">
                {report.meritSummary.overall_avg_marks || 0}%
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">Average Entrance Score</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-2xl font-bold text-amber-400">
                {report.meritSummary.highest_marks || 0}%
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">Highest Entrance Score</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-2xl font-bold text-rose-300">
                {report.meritSummary.lowest_marks || 0}%
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">Lowest Entrance Score</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-2xl font-bold">
                {report.meritSummary.avg_tenth_marks || 0}%
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">Average 10th Board</span>
            </div>
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              <span className="text-2xl font-bold">
                {report.meritSummary.avg_twelfth_marks || 0}%
              </span>
              <span className="text-[11px] text-slate-400 block mt-1">Average 12th Board</span>
            </div>
          </div>
        </div>
      )}

      {/* Grid of Report Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Distribution Report */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2 mb-4">
            <Building2 className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-800">Faculty Enrollment & Faculty Benchmarks</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="py-2.5 px-3">Department</th>
                  <th className="py-2.5 px-3 text-center">Courses</th>
                  <th className="py-2.5 px-3 text-center">Tutors</th>
                  <th className="py-2.5 px-3 text-center">Enrolled</th>
                  <th className="py-2.5 px-3 text-right">Avg Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report?.departmentStats?.map(d => (
                  <tr key={d.department_id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-semibold text-slate-800">{d.department_name}</td>
                    <td className="py-2 px-3 text-center text-slate-600">{d.total_courses}</td>
                    <td className="py-2 px-3 text-center text-slate-600">{d.total_tutors}</td>
                    <td className="py-2 px-3 text-center font-bold text-blue-600">{d.enrolled_students}</td>
                    <td className="py-2 px-3 text-right font-medium text-emerald-600">{d.avg_marks || 'N/A'}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Course-wise Acceptance Report */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2 mb-4">
            <GraduationCap className="w-5 h-5 text-purple-600" />
            <h3 className="text-sm font-bold text-slate-800">Course Application Acceptance Rates</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="py-2.5 px-3">Course Program</th>
                  <th className="py-2.5 px-3 text-center">Applicants</th>
                  <th className="py-2.5 px-3 text-center">Approved</th>
                  <th className="py-2.5 px-3 text-right">Acceptance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report?.courseStats?.map(c => (
                  <tr key={c.course_id} className="hover:bg-slate-50">
                    <td className="py-2 px-3">
                      <span className="font-semibold text-slate-800">{c.course_name}</span>
                      <p className="text-[10px] text-slate-400">{c.department_name}</p>
                    </td>
                    <td className="py-2 px-3 text-center text-slate-700 font-medium">{c.total_applicants}</td>
                    <td className="py-2 px-3 text-center text-emerald-600 font-bold">{c.approved_count}</td>
                    <td className="py-2 px-3 text-right font-mono font-semibold text-slate-700">
                      {c.acceptance_rate_pct ? `${c.acceptance_rate_pct}%` : '0%'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Facilities Utilization Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hostel Occupancy */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2 mb-4">
            <Home className="w-5 h-5 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-800">Hostel Occupancy & Vacancy Breakdown</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="py-2.5 px-3">Hostel</th>
                  <th className="py-2.5 px-3 text-center">Type</th>
                  <th className="py-2.5 px-3 text-center">Capacity</th>
                  <th className="py-2.5 px-3 text-center">Occupied</th>
                  <th className="py-2.5 px-3 text-right">Occupancy %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report?.hostelStats?.map(h => (
                  <tr key={h.hostel_id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-semibold text-slate-800">{h.hostel_name}</td>
                    <td className="py-2 px-3 text-center text-slate-600">{h.type}</td>
                    <td className="py-2 px-3 text-center text-slate-600">{h.total_capacity}</td>
                    <td className="py-2 px-3 text-center font-bold text-indigo-600">{h.occupied_seats}</td>
                    <td className="py-2 px-3 text-right font-mono font-semibold text-slate-700">
                      {h.occupancy_rate_pct || 0}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bus Occupancy */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center gap-2 mb-4">
            <Bus className="w-5 h-5 text-amber-600" />
            <h3 className="text-sm font-bold text-slate-800">Bus Transportation Quota Utilization</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="py-2.5 px-3">Bus Number</th>
                  <th className="py-2.5 px-3">Route</th>
                  <th className="py-2.5 px-3 text-center">Capacity</th>
                  <th className="py-2.5 px-3 text-center">Assigned</th>
                  <th className="py-2.5 px-3 text-right">Quota %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report?.busStats?.map(b => (
                  <tr key={b.bus_id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-slate-800">{b.bus_number}</td>
                    <td className="py-2 px-3 text-slate-600 truncate max-w-xs">{b.route}</td>
                    <td className="py-2 px-3 text-center text-slate-600">{b.total_capacity}</td>
                    <td className="py-2 px-3 text-center font-bold text-amber-600">{b.occupied_seats}</td>
                    <td className="py-2 px-3 text-right font-mono font-semibold text-slate-700">
                      {b.occupancy_rate_pct || 0}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
