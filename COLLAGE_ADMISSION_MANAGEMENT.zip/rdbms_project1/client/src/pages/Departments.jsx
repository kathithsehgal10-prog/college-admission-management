import React, { useState, useEffect } from 'react';
import {
  Plus,
  Building2,
  GraduationCap,
  Users,
  UserCheck,
  Eye,
  Edit2,
  Trash2,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import { departmentService } from '../services/departmentService';
import { PageHeader } from '../components/common/PageHeader';
import { DataTable } from '../components/common/DataTable';
import { SearchInput } from '../components/common/SearchInput';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { ErrorAlert } from '../components/common/ErrorAlert';
import { useToast } from '../contexts/ToastContext';

export function Departments() {
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  // Modals
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailedDept, setDetailedDept] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deptToDelete, setDeptToDelete] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const initialForm = { department_name: '', code: '', description: '' };
  const [formData, setFormData] = useState(initialForm);
  const [formErrors, setFormErrors] = useState({});

  const { success, error: toastError } = useToast();

  const fetchDepartments = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await departmentService.getAll({ search });
      setDepartments(res.data || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
        'Failed to load departments from MySQL database.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, [search]);

  const handleOpenAdd = () => {
    setEditingDept(null);
    setFormData(initialForm);
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenEdit = dept => {
    setEditingDept(dept);
    setFormData({
      department_name: dept.department_name || '',
      code: dept.code || '',
      description: dept.description || ''
    });
    setFormErrors({});
    setFormModalOpen(true);
  };

  const handleOpenDetail = async dept => {
    try {
      const res = await departmentService.getById(dept.department_id);
      setDetailedDept(res.data);
      setDetailModalOpen(true);
    } catch (err) {
      toastError(err.response?.data?.message || 'Could not load department details.');
    }
  };

  const handleFormSubmit = async e => {
    e.preventDefault();
    setFormErrors({});
    setSubmitting(true);

    try {
      if (editingDept) {
        await departmentService.update(editingDept.department_id, formData);
        success(`Department "${formData.department_name}" updated successfully.`);
      } else {
        await departmentService.create(formData);
        success(`Department "${formData.department_name}" created successfully.`);
      }
      setFormModalOpen(false);
      fetchDepartments();
    } catch (err) {
      if (err.response?.data?.errors) {
        const errorsObj = {};
        err.response.data.errors.forEach(issue => {
          errorsObj[issue.field] = issue.message;
        });
        setFormErrors(errorsObj);
      } else {
        toastError(err.response?.data?.message || 'Failed to save department.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deptToDelete) return;
    setSubmitting(true);
    try {
      await departmentService.delete(deptToDelete.department_id);
      success(`Department "${deptToDelete.department_name}" deleted successfully.`);
      setDeleteConfirmOpen(false);
      setDeptToDelete(null);
      fetchDepartments();
    } catch (err) {
      // Referential integrity conflict handled explicitly
      toastError(
        err.response?.data?.message ||
        'Cannot delete department because active courses, tutors, or students depend on it.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      header: 'ID',
      accessor: 'department_id',
      className: 'font-mono text-xs text-slate-500 w-16'
    },
    {
      header: 'Department Name',
      key: 'name',
      render: row => (
        <div>
          <span className="font-semibold text-slate-800">{row.department_name}</span>
          {row.description && <p className="text-xs text-slate-400 truncate max-w-sm">{row.description}</p>}
        </div>
      )
    },
    {
      header: 'Code',
      key: 'code',
      render: row => (
        <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
          {row.code || 'N/A'}
        </span>
      )
    },
    {
      header: 'Courses',
      key: 'courses',
      render: row => (
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700">
          <GraduationCap className="w-3.5 h-3.5 text-purple-600" />
          {row.total_courses}
        </span>
      )
    },
    {
      header: 'Tutors',
      key: 'tutors',
      render: row => (
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700">
          <UserCheck className="w-3.5 h-3.5 text-amber-600" />
          {row.total_tutors}
        </span>
      )
    },
    {
      header: 'Students',
      key: 'students',
      render: row => (
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700">
          <Users className="w-3.5 h-3.5 text-blue-600" />
          {row.total_students}
        </span>
      )
    },
    {
      header: 'Actions',
      key: 'actions',
      align: 'right',
      render: row => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={() => handleOpenDetail(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
            title="View Department Summary"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
            title="Edit Department"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setDeptToDelete(row);
              setDeleteConfirmOpen(true);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
            title="Delete Department"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Department Management"
        description="Academic faculties offering degree programs, advising students, and hosting teaching tutors"
        breadcrumbs={['Admissions Portal', 'Departments']}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchDepartments}
              disabled={loading}
              className="p-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition shadow-xs"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Add Department
            </button>
          </div>
        }
      />

      {error && <ErrorAlert message={error} onRetry={fetchDepartments} />}

      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search departments by name or faculty code..."
          className="w-full sm:max-w-md"
        />
      </div>

      <DataTable
        columns={columns}
        data={departments}
        loading={loading}
        emptyTitle="No departments found"
        emptyDescription="Create your first academic department to start linking courses and tutors."
        emptyActionLabel="Add Department"
        onEmptyAction={handleOpenAdd}
      />

      {/* Add / Edit Modal */}
      <Modal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        title={editingDept ? `Edit Department: ${editingDept.department_name}` : 'Create Academic Department'}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Department Name *
            </label>
            <input
              type="text"
              required
              value={formData.department_name}
              onChange={e => setFormData({ ...formData, department_name: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
              placeholder="e.g. Computer Science & Engineering"
            />
            {formErrors.department_name && (
              <p className="text-xs text-rose-600 mt-1">{formErrors.department_name}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Faculty Code (Optional)
            </label>
            <input
              type="text"
              value={formData.code}
              onChange={e => setFormData({ ...formData, code: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none font-mono"
              placeholder="e.g. CSE"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Description (Optional)
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
              placeholder="Brief summary of department curricula and specializations..."
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFormModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : editingDept ? 'Update Department' : 'Create Department'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Detail Modal */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Department Overview & Associated Relations"
        maxWidth="max-w-2xl"
      >
        {detailedDept && (
          <div className="space-y-6">
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-xl font-bold text-slate-900">{detailedDept.department_name}</h3>
                <p className="text-xs text-slate-500 font-mono">
                  Code: {detailedDept.code || 'N/A'} | ID: #{detailedDept.department_id}
                </p>
                {detailedDept.description && (
                  <p className="text-xs text-slate-600 mt-2">{detailedDept.description}</p>
                )}
              </div>
            </div>

            {/* Quick counts */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-purple-50 rounded-xl">
                <span className="text-lg font-bold text-purple-700">{detailedDept.total_courses}</span>
                <span className="text-xs text-purple-600 block">Courses</span>
              </div>
              <div className="p-3 bg-amber-50 rounded-xl">
                <span className="text-lg font-bold text-amber-700">{detailedDept.total_tutors}</span>
                <span className="text-xs text-amber-600 block">Faculty Tutors</span>
              </div>
              <div className="p-3 bg-blue-50 rounded-xl">
                <span className="text-lg font-bold text-blue-700">{detailedDept.total_students}</span>
                <span className="text-xs text-blue-600 block">Enrolled Students</span>
              </div>
            </div>

            {/* Courses Offered */}
            <div>
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2">Offered Courses</h4>
              {detailedDept.courses && detailedDept.courses.length > 0 ? (
                <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
                  {detailedDept.courses.map(c => (
                    <div key={c.course_id} className="p-3 flex items-center justify-between text-xs bg-white">
                      <span className="font-medium text-slate-800">{c.course_name}</span>
                      <span className="text-slate-500">
                        {c.duration_years} Years | Intake: {c.intake_capacity}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">No courses currently created under this department.</p>
              )}
            </div>

            {/* Associated Tutors */}
            <div>
              <h4 className="text-xs font-bold uppercase text-slate-500 mb-2">Faculty Tutors</h4>
              {detailedDept.tutors && detailedDept.tutors.length > 0 ? (
                <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
                  {detailedDept.tutors.map(t => (
                    <div key={t.tutor_id} className="p-3 flex items-center justify-between text-xs bg-white">
                      <div>
                        <span className="font-semibold text-slate-800">{t.tutor_name}</span>
                        <p className="text-[11px] text-slate-400">{t.qualification}</p>
                      </div>
                      <span className="font-mono text-slate-500">{t.phone}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 italic">No tutors assigned to this department.</p>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        onConfirm={handleDelete}
        title="Delete Academic Department"
        message={`Are you sure you want to remove department "${deptToDelete?.department_name}"? If courses, tutors, or students depend on this department, MySQL referential integrity rules will reject the deletion.`}
        confirmText="Delete Department"
        loading={submitting}
      />
    </div>
  );
}
