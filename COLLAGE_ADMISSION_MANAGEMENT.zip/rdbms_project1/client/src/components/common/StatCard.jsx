import React from 'react';

export function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  color = 'blue',
  loading = false,
  badge
}) {
  const colorMap = {
    blue: {
      iconBg: 'bg-blue-50 text-blue-600',
      border: 'border-blue-100',
      accent: 'text-blue-600'
    },
    emerald: {
      iconBg: 'bg-emerald-50 text-emerald-600',
      border: 'border-emerald-100',
      accent: 'text-emerald-600'
    },
    amber: {
      iconBg: 'bg-amber-50 text-amber-600',
      border: 'border-amber-100',
      accent: 'text-amber-600'
    },
    rose: {
      iconBg: 'bg-rose-50 text-rose-600',
      border: 'border-rose-100',
      accent: 'text-rose-600'
    },
    indigo: {
      iconBg: 'bg-indigo-50 text-indigo-600',
      border: 'border-indigo-100',
      accent: 'text-indigo-600'
    },
    purple: {
      iconBg: 'bg-purple-50 text-purple-600',
      border: 'border-purple-100',
      accent: 'text-purple-600'
    }
  };

  const theme = colorMap[color] || colorMap.blue;

  if (loading) {
    return (
      <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs animate-pulse">
        <div className="flex items-center justify-between mb-3">
          <div className="h-4 bg-slate-200 rounded w-24"></div>
          <div className="w-10 h-10 bg-slate-200 rounded-lg"></div>
        </div>
        <div className="h-8 bg-slate-200 rounded w-16 mb-2"></div>
        <div className="h-3 bg-slate-100 rounded w-32"></div>
      </div>
    );
  }

  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:shadow-md transition-shadow duration-200 flex flex-col justify-between">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">{title}</span>
        {Icon && (
          <div className={`p-2.5 rounded-lg ${theme.iconBg} shrink-0`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      <div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {value !== undefined && value !== null ? value : 0}
          </span>
          {badge && <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{badge}</span>}
        </div>
        {subtitle && <p className="text-xs text-slate-500 mt-1 font-medium">{subtitle}</p>}
      </div>
    </div>
  );
}
