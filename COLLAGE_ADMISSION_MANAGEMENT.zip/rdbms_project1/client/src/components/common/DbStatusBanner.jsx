import React, { useState } from 'react';
import { Database, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export function DbStatusBanner() {
  const { dbHealth, refreshHealth } = useAuth();
  const [checking, setChecking] = useState(false);

  const handleRefresh = async () => {
    setChecking(true);
    await refreshHealth();
    setTimeout(() => setChecking(false), 500);
  };

  // If connected, show a compact positive status badge or render nothing if healthy
  if (dbHealth?.connected) {
    return null;
  }

  return (
    <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2.5 sm:px-6 transition-all">
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2.5 text-amber-900">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
          </span>
          <span className="font-semibold flex items-center gap-1.5">
            <Database className="w-4 h-4 text-amber-600" />
            MySQL Database Pending Configuration:
          </span>
          <span className="text-amber-800 hidden md:inline">
            {dbHealth?.message || 'Server cannot connect to local MySQL service.'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded border border-amber-200">
            Set credentials in <code className="font-mono font-semibold">server/.env</code>
          </span>
          <button
            onClick={handleRefresh}
            disabled={checking}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-amber-900 bg-white border border-amber-300 rounded hover:bg-amber-50 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 ${checking ? 'animate-spin' : ''}`} />
            Check Connection
          </button>
        </div>
      </div>
    </div>
  );
}
