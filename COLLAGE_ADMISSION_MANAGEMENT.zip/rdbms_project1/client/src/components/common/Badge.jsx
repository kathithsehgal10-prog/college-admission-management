import React from 'react';

export function Badge({ status, type = 'default', children }) {
  const label = children || status;

  let colorClasses = 'bg-slate-100 text-slate-700 border-slate-200';

  const normalized = String(status || '').toLowerCase();

  if (['approved', 'active', 'healthy', 'connected', 'success', 'published'].includes(normalized)) {
    colorClasses = 'bg-emerald-50 text-emerald-700 border-emerald-200';
  } else if (['pending', 'in review', 'under_review', 'under review', 'warning'].includes(normalized)) {
    colorClasses = 'bg-amber-50 text-amber-700 border-amber-200';
  } else if (['waitlisted', 'waitlist'].includes(normalized)) {
    colorClasses = 'bg-orange-50 text-orange-700 border-orange-200';
  } else if (['documents_required', 'documents required'].includes(normalized)) {
    colorClasses = 'bg-purple-50 text-purple-700 border-purple-200';
  } else if (['submitted', 'upcoming'].includes(normalized)) {
    colorClasses = 'bg-blue-50 text-blue-700 border-blue-200';
  } else if (['rejected', 'cancelled', 'vacated', 'error', 'disconnected', 'withdrawn', 'closed'].includes(normalized)) {
    colorClasses = 'bg-rose-50 text-rose-700 border-rose-200';
  } else if (['draft', 'archived', 'inactive'].includes(normalized)) {
    colorClasses = 'bg-slate-100 text-slate-700 border-slate-300';
  } else if (['male', 'boys'].includes(normalized)) {
    colorClasses = 'bg-sky-50 text-sky-700 border-sky-200';
  } else if (['female', 'girls'].includes(normalized)) {
    colorClasses = 'bg-pink-50 text-pink-700 border-pink-200';
  } else if (['co-ed', 'other', 'info'].includes(normalized)) {
    colorClasses = 'bg-indigo-50 text-indigo-700 border-indigo-200';
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${colorClasses}`}>
      <span className="w-1.5 h-1.5 mr-1.5 rounded-full bg-current opacity-70"></span>
      {label}
    </span>
  );
}
