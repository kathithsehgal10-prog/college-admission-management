import api from './api';

export const tutorService = {
  async getAll(params = {}) {
    const res = await api.get('/tutors', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/tutors/${id}`);
    return res.data;
  },

  async create(data) {
    const res = await api.post('/tutors', data);
    return res.data;
  },

  async update(id, data) {
    const res = await api.put(`/tutors/${id}`, data);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/tutors/${id}`);
    return res.data;
  }
};
