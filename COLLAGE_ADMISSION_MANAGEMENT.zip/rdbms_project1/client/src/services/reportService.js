import api from './api';

export const reportService = {
  async getSummary() {
    const res = await api.get('/reports/summary');
    return res.data;
  },

  async downloadCsv(type) {
    const res = await api.get(`/reports/export/${type}`, {
      responseType: 'blob'
    });
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${type}_report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
};
