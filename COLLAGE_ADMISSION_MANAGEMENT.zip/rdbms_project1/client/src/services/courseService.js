import api from './api';

export const courseService = {
  async getAll(params = {}) {
    const res = await api.get('/courses', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/courses/${id}`);
    return res.data;
  },

  async create(data) {
    const res = await api.post('/courses', data);
    return res.data;
  },

  async update(id, data) {
    const res = await api.put(`/courses/${id}`, data);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/courses/${id}`);
    return res.data;
  }
};
