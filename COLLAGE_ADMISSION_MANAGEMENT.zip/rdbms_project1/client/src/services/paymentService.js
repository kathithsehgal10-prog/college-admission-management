import api from './api';

export const paymentService = {
  getAll: params => api.get('/payments', { params }),
  record: data => api.post('/payments', data)
};
