import api from './api';

export const busService = {
  async getAll(params = {}) {
    const res = await api.get('/buses', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/buses/${id}`);
    return res.data;
  },

  async create(data) {
    const res = await api.post('/buses', data);
    return res.data;
  },

  async update(id, data) {
    const res = await api.put(`/buses/${id}`, data);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/buses/${id}`);
    return res.data;
  },

  // Allocations
  async getAllocations(params = {}) {
    const res = await api.get('/bus-allocations', { params });
    return res.data;
  },

  async createAllocation(data) {
    const res = await api.post('/bus-allocations', data);
    return res.data;
  },

  async updateAllocation(id, data) {
    const res = await api.patch(`/bus-allocations/${id}`, data);
    return res.data;
  },

  async deleteAllocation(id) {
    const res = await api.delete(`/bus-allocations/${id}`);
    return res.data;
  }
};
