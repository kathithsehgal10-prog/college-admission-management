import api from './api';

export const cycleService = {
  async getAll(params = {}) {
    const res = await api.get('/admission-cycles', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/admission-cycles/${id}`);
    return res.data;
  },

  async create(payload) {
    const res = await api.post('/admission-cycles', payload);
    return res.data;
  },

  async update(id, payload) {
    const res = await api.put(`/admission-cycles/${id}`, payload);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/admission-cycles/${id}`);
    return res.data;
  }
};
