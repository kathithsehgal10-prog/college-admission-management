import api from './api';

export const applicationService = {
  async getAll(params = {}) {
    const res = await api.get('/applications', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/applications/${id}`);
    return res.data;
  },

  async getHistory(id) {
    const res = await api.get(`/applications/${id}/history`);
    return res.data;
  },

  async create(data) {
    const res = await api.post('/applications', data);
    return res.data;
  },

  async updateStatus(id, status, remarks, admin_remarks) {
    const res = await api.patch(`/applications/${id}/status`, { status, remarks, admin_remarks });
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/applications/${id}`);
    return res.data;
  }
};
