import api from './api';

export const authService = {
  async login(email, password) {
    const res = await api.post('/auth/login', { email, password });
    return res.data;
  },

  async getMe() {
    const res = await api.get('/auth/me');
    return res.data;
  },

  async logout() {
    try {
      await api.post('/auth/logout');
    } catch (_) {
      // Ignored for client-side token discard
    }
  },

  async checkHealth() {
    const res = await api.get('/health');
    return res.data;
  }
};
