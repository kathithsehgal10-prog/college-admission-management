import api from './api';

export const departmentService = {
  async getAll(params = {}) {
    const res = await api.get('/departments', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/departments/${id}`);
    return res.data;
  },

  async create(data) {
    const res = await api.post('/departments', data);
    return res.data;
  },

  async update(id, data) {
    const res = await api.put(`/departments/${id}`, data);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/departments/${id}`);
    return res.data;
  }
};
