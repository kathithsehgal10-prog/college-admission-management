import api from './api';

export const vivaService = {
  async getQueries() {
    const res = await api.get('/viva/queries');
    return res.data;
  },

  async executeQuery(payload) {
    const res = await api.post('/viva/execute', payload);
    return res.data;
  },

  async getSchema() {
    const res = await api.get('/viva/schema');
    return res.data;
  }
};
