import api from './api';

export const hostelService = {
  async getAll(params = {}) {
    const res = await api.get('/hostels', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/hostels/${id}`);
    return res.data;
  },

  async create(data) {
    const res = await api.post('/hostels', data);
    return res.data;
  },

  async update(id, data) {
    const res = await api.put(`/hostels/${id}`, data);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/hostels/${id}`);
    return res.data;
  },

  // Allocations
  async getAllocations(params = {}) {
    const res = await api.get('/hostel-allocations', { params });
    return res.data;
  },

  async createAllocation(data) {
    const res = await api.post('/hostel-allocations', data);
    return res.data;
  },

  async updateAllocation(id, data) {
    const res = await api.patch(`/hostel-allocations/${id}`, data);
    return res.data;
  },

  async deleteAllocation(id) {
    const res = await api.delete(`/hostel-allocations/${id}`);
    return res.data;
  }
};
