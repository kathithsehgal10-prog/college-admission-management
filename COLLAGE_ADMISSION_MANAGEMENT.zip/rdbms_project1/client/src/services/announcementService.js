import api from './api';

export const announcementService = {
  async getAll(params = {}) {
    const res = await api.get('/announcements', { params });
    return res.data;
  },

  async getById(id) {
    const res = await api.get(`/announcements/${id}`);
    return res.data;
  },

  async create(payload) {
    const res = await api.post('/announcements', payload);
    return res.data;
  },

  async update(id, payload) {
    const res = await api.put(`/announcements/${id}`, payload);
    return res.data;
  },

  async delete(id) {
    const res = await api.delete(`/announcements/${id}`);
    return res.data;
  }
};
