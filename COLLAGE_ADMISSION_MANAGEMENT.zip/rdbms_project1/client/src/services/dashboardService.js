import api from './api';

export const dashboardService = {
  async getStats() {
    const res = await api.get('/dashboard/stats');
    return res.data;
  },

  async getCharts() {
    const res = await api.get('/dashboard/charts');
    return res.data;
  },

  async getRecentActivity() {
    const res = await api.get('/dashboard/recent-activity');
    return res.data;
  }
};
