import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [admin, setAdmin] = useState(() => {
    const saved = localStorage.getItem('admin');
    try { return saved ? JSON.parse(saved) : null; }
    catch { localStorage.removeItem('admin'); return null; }
  });
  const [token, setToken] = useState(() => localStorage.getItem('token') || null);
  const [isLoading, setIsLoading] = useState(true);
  const [dbHealth, setDbHealth] = useState({
    connected: false,
    message: 'Checking database connectivity...',
    lastChecked: null
  });

  // Check health and user session on mount
  useEffect(() => {
    async function initialize() {
      // 1. Health check
      try {
        const health = await authService.checkHealth();
        setDbHealth(health.database || { connected: false, message: 'Unreachable' });
      } catch (err) {
        setDbHealth({
          connected: false,
          message: 'Backend API unreachable. Ensure Node.js server is started on port 5001.'
        });
      }

      // 2. Validate token if present
      if (token) {
        try {
          const res = await authService.getMe();
          setAdmin(res.data);
          localStorage.setItem('admin', JSON.stringify(res.data));
        } catch (err) {
          // Token expired or invalid
          setAdmin(null);
          setToken(null);
          localStorage.removeItem('token');
          localStorage.removeItem('admin');
        }
      }
      setIsLoading(false);
    }

    initialize();

    // Listen for 401 unauthorized events
    const handleUnauthorized = () => {
      setAdmin(null);
      setToken(null);
    };
    window.addEventListener('auth:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('auth:unauthorized', handleUnauthorized);
  }, [token]);

  const refreshHealth = async () => {
    try {
      const health = await authService.checkHealth();
      setDbHealth(health.database || { connected: false, message: 'Unreachable' });
      return health.database;
    } catch (err) {
      const failState = {
        connected: false,
        message: 'Backend server not responding.'
      };
      setDbHealth(failState);
      return failState;
    }
  };

  const login = async (email, password) => {
    const res = await authService.login(email, password);
    const { token: newToken, admin: newAdmin } = res.data;
    setToken(newToken);
    setAdmin(newAdmin);
    localStorage.setItem('token', newToken);
    localStorage.setItem('admin', JSON.stringify(newAdmin));
    return newAdmin;
  };

  const logout = async () => {
    await authService.logout();
    setAdmin(null);
    setToken(null);
    localStorage.removeItem('token');
    localStorage.removeItem('admin');
  };

  return (
    <AuthContext.Provider
      value={{
        admin,
        token,
        isAuthenticated: !!token && !!admin,
        isLoading,
        dbHealth,
        refreshHealth,
        login,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
