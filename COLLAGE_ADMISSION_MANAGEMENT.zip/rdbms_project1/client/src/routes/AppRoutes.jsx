import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AdminLayout } from '../components/layout/AdminLayout';
import { ProtectedRoute, PublicRoute } from './ProtectedRoute';

// Pages
import { Login } from '../pages/Login';
import { Dashboard } from '../pages/Dashboard';
import { Students } from '../pages/Students';
import { Departments } from '../pages/Departments';
import { Courses } from '../pages/Courses';
import { Tutors } from '../pages/Tutors';
import { Applications } from '../pages/Applications';
import { AdmissionCycles } from '../pages/AdmissionCycles';
import { Hostels } from '../pages/Hostels';
import { HostelAllocations } from '../pages/HostelAllocations';
import { Buses } from '../pages/Buses';
import { BusAllocations } from '../pages/BusAllocations';
import { Reports } from '../pages/Reports';
import { Announcements } from '../pages/Announcements';
import { Settings } from '../pages/Settings';
import { VivaLab } from '../pages/VivaLab';
import { NotFound } from '../pages/NotFound';

export function AppRoutes() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route
        path="/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />

      {/* Protected Administration Portal Routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="viva" element={<VivaLab />} />
        <Route path="students" element={<Students />} />
        <Route path="departments" element={<Departments />} />
        <Route path="courses" element={<Courses />} />
        <Route path="tutors" element={<Tutors />} />
        <Route path="applications" element={<Applications />} />
        <Route path="admission-cycles" element={<AdmissionCycles />} />
        <Route path="hostels" element={<Hostels />} />
        <Route path="hostel-allocations" element={<HostelAllocations />} />
        <Route path="buses" element={<Buses />} />
        <Route path="bus-allocations" element={<BusAllocations />} />
        <Route path="reports" element={<Reports />} />
        <Route path="announcements" element={<Announcements />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      {/* 404 Catch-All */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
