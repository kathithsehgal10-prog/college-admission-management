const mysql = require('mysql2/promise');
const config = require('./env');

// Submission requires MySQL. Never switch databases when a connection fails.
const pool = mysql.createPool({ ...config.db, connectTimeout: 5000, dateStrings: true });
let dbState = {
  connected: false, dialect: 'mysql', mode: 'standalone',
  message: 'Database connection has not been initialized yet.', lastChecked: null,
  databaseName: config.db.database, host: config.db.host, port: config.db.port
};
const connectionErrors = new Set(['ECONNREFUSED', 'ER_ACCESS_DENIED_ERROR', 'ENOTFOUND',
  'ER_BAD_DB_ERROR', 'ETIMEDOUT', 'ECONNRESET', 'EHOSTUNREACH', 'PROTOCOL_CONNECTION_LOST']);
function reportError(error) {
  if (connectionErrors.has(error.code)) {
    dbState.connected = false;
    dbState.message = `MySQL unavailable (${error.code}). Check MySQL and server/.env.`;
    error.statusCode = 503;
  }
  return error;
}
async function testConnection() {
  let connection;
  dbState.lastChecked = new Date();
  try {
    connection = await pool.getConnection();
    await connection.ping();
    const [version] = await connection.query('SELECT VERSION() AS version');
    dbState.serverVersion = version[0].version;
    dbState.connected = true;
    dbState.message = 'Successfully connected to MySQL database.';
  } catch (error) {
    reportError(error);
    dbState.connected = false;
    dbState.message = `MySQL connection failed (${error.code || 'unknown error'}). Check MySQL and server/.env.`;
  } finally {
    connection?.release();
  }
  return getDbState();
}
async function query(sql, params = []) {
  try {
    const [rows] = await pool.query(sql, params.map(p => p === undefined ? null : p));
    dbState.connected = true;
    return rows;
  } catch (error) { throw reportError(error); }
}
async function getConnection() {
  try { return await pool.getConnection(); }
  catch (error) { throw reportError(error); }
}
async function withTransaction(work) {
  // Acquisition is inside the caller's try/catch through this awaited helper.
  const connection = await getConnection();
  try {
    // Current occupancy reads must see commits after waiting for a resource lock.
    await connection.query('SET TRANSACTION ISOLATION LEVEL READ COMMITTED');
    await connection.beginTransaction();
    const result = await work(connection);
    await connection.commit();
    return result;
  } catch (error) {
    try { await connection.rollback(); } catch { /* Preserve original failure. */ }
    throw reportError(error);
  } finally { connection.release(); }
}
async function readOnlyQuery(sql) {
  const connection = await getConnection();
  try {
    await connection.query('START TRANSACTION READ ONLY');
    const [rows] = await connection.query({ sql, timeout: 5000 });
    return rows;
  } catch (error) { throw reportError(error); }
  finally {
    try { await connection.rollback(); } finally { connection.release(); }
  }
}
function getDbState() { return { ...dbState }; }
module.exports = { pool, query, readOnlyQuery, getConnection, withTransaction, testConnection, getDbState };
