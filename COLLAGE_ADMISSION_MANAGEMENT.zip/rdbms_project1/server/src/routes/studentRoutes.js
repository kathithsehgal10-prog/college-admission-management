const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const { validate } = require('../middleware/validate');
const { studentSchema, studentUpdateSchema } = require('../validators/studentValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, studentController.getAllStudents);
router.get('/:id', verifyToken, studentController.getStudentById);
router.post('/', verifyToken, validate(studentSchema), studentController.createStudent);
router.put('/:id', verifyToken, validate(studentUpdateSchema), studentController.updateStudent);
router.delete('/:id', verifyToken, studentController.deleteStudent);

module.exports = router;
