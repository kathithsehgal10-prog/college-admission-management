const express = require('express');
const router = express.Router();
const courseController = require('../controllers/courseController');
const { validate } = require('../middleware/validate');
const { courseSchema, courseUpdateSchema } = require('../validators/courseValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, courseController.getAllCourses);
router.get('/:id', verifyToken, courseController.getCourseById);
router.post('/', verifyToken, validate(courseSchema), courseController.createCourse);
router.put('/:id', verifyToken, validate(courseUpdateSchema), courseController.updateCourse);
router.delete('/:id', verifyToken, courseController.deleteCourse);

module.exports = router;
