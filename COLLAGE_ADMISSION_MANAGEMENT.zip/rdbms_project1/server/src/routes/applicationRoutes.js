const express = require('express');
const router = express.Router();
const applicationController = require('../controllers/applicationController');
const { validate } = require('../middleware/validate');
const { createApplicationSchema, updateApplicationStatusSchema } = require('../validators/applicationValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, applicationController.getAllApplications);
router.get('/:id', verifyToken, applicationController.getApplicationById);
router.get('/:id/history', verifyToken, applicationController.getApplicationHistory);
router.post('/', verifyToken, validate(createApplicationSchema), applicationController.createApplication);
router.patch('/:id/status', verifyToken, validate(updateApplicationStatusSchema), applicationController.updateApplicationStatus);
router.delete('/:id', verifyToken, applicationController.deleteApplication);

module.exports = router;
