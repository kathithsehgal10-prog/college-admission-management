const express = require('express');
const router = express.Router();
const departmentController = require('../controllers/departmentController');
const { validate } = require('../middleware/validate');
const { departmentSchema, departmentUpdateSchema } = require('../validators/departmentValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, departmentController.getAllDepartments);
router.get('/:id', verifyToken, departmentController.getDepartmentById);
router.post('/', verifyToken, validate(departmentSchema), departmentController.createDepartment);
router.put('/:id', verifyToken, validate(departmentUpdateSchema), departmentController.updateDepartment);
router.delete('/:id', verifyToken, departmentController.deleteDepartment);

module.exports = router;
