const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, paymentController.getAllPayments);
router.post('/', verifyToken, paymentController.recordPayment);

module.exports = router;
