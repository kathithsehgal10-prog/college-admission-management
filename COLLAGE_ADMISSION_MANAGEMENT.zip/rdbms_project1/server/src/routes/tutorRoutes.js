const express = require('express');
const router = express.Router();
const tutorController = require('../controllers/tutorController');
const { validate } = require('../middleware/validate');
const { tutorSchema, tutorUpdateSchema } = require('../validators/tutorValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, tutorController.getAllTutors);
router.get('/:id', verifyToken, tutorController.getTutorById);
router.post('/', verifyToken, validate(tutorSchema), tutorController.createTutor);
router.put('/:id', verifyToken, validate(tutorUpdateSchema), tutorController.updateTutor);
router.delete('/:id', verifyToken, tutorController.deleteTutor);

module.exports = router;
