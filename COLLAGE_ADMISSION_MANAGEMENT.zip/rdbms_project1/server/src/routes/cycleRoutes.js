const express = require('express');
const router = express.Router();
const cycleController = require('../controllers/cycleController');
const { validate } = require('../middleware/validate');
const { cycleSchema } = require('../validators/cycleValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, cycleController.getAllCycles);
router.get('/:id', verifyToken, cycleController.getCycleById);
router.post('/', verifyToken, validate(cycleSchema), cycleController.createCycle);
router.put('/:id', verifyToken, validate(cycleSchema), cycleController.updateCycle);
router.delete('/:id', verifyToken, cycleController.deleteCycle);

module.exports = router;
