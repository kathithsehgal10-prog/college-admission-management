const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { verifyToken } = require('../middleware/auth');

router.get('/summary', verifyToken, reportController.getSummaryReport);
router.get('/export/:type', verifyToken, reportController.exportCsv);

module.exports = router;
