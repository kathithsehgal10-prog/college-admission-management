const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validate } = require('../middleware/validate');
const { loginSchema } = require('../validators/authValidator');
const { verifyToken } = require('../middleware/auth');

router.post('/login', validate(loginSchema), authController.login);
router.get('/me', verifyToken, authController.getMe);
router.post('/logout', (req, res) => {
  // Stateless JWT logout acknowledgment
  res.status(200).json({ success: true, message: 'Logged out successfully.' });
});

module.exports = router;
