const express = require('express');
const router = express.Router();
const busController = require('../controllers/busController');
const { validate } = require('../middleware/validate');
const { busSchema, busUpdateSchema } = require('../validators/busValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, busController.getAllBuses);
router.get('/:id', verifyToken, busController.getBusById);
router.post('/', verifyToken, validate(busSchema), busController.createBus);
router.put('/:id', verifyToken, validate(busUpdateSchema), busController.updateBus);
router.delete('/:id', verifyToken, busController.deleteBus);

module.exports = router;
