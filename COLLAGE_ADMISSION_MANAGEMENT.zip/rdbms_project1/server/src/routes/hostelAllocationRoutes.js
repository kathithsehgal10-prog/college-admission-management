const express = require('express');
const router = express.Router();
const hostelAllocationController = require('../controllers/hostelAllocationController');
const { validate } = require('../middleware/validate');
const {
  hostelAllocationSchema,
  updateHostelAllocationStatusSchema
} = require('../validators/hostelValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, hostelAllocationController.getAllAllocations);
router.post('/', verifyToken, validate(hostelAllocationSchema), hostelAllocationController.createAllocation);
router.patch('/:id', verifyToken, validate(updateHostelAllocationStatusSchema), hostelAllocationController.updateAllocation);
router.delete('/:id', verifyToken, hostelAllocationController.deleteAllocation);

module.exports = router;
