const express = require('express');
const router = express.Router();
const hostelController = require('../controllers/hostelController');
const hostelAllocationController = require('../controllers/hostelAllocationController');
const { validate } = require('../middleware/validate');
const {
  hostelSchema,
  hostelUpdateSchema,
  hostelAllocationSchema,
  updateHostelAllocationStatusSchema
} = require('../validators/hostelValidator');
const { verifyToken } = require('../middleware/auth');

// Hostel CRUD
router.get('/', verifyToken, hostelController.getAllHostels);
router.get('/:id', verifyToken, hostelController.getHostelById);
router.post('/', verifyToken, validate(hostelSchema), hostelController.createHostel);
router.put('/:id', verifyToken, validate(hostelUpdateSchema), hostelController.updateHostel);
router.delete('/:id', verifyToken, hostelController.deleteHostel);

// Allocation Sub-routes
router.get('/allocations/all', verifyToken, hostelAllocationController.getAllAllocations);
router.post('/allocations', verifyToken, validate(hostelAllocationSchema), hostelAllocationController.createAllocation);
router.patch('/allocations/:id', verifyToken, validate(updateHostelAllocationStatusSchema), hostelAllocationController.updateAllocation);
router.delete('/allocations/:id', verifyToken, hostelAllocationController.deleteAllocation);

module.exports = router;
