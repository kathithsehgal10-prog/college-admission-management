const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middleware/auth');
const vivaController = require('../controllers/vivaController');

// All viva demonstration endpoints are protected behind admin auth
router.use(verifyToken);

router.get('/queries', vivaController.getVivaQueries);
router.post('/execute', vivaController.executeVivaQuery);
router.get('/schema', vivaController.getSchemaMetadata);

module.exports = router;
