const express = require('express');
const router = express.Router();
const busAllocationController = require('../controllers/busAllocationController');
const { validate } = require('../middleware/validate');
const {
  busAllocationSchema,
  updateBusAllocationStatusSchema
} = require('../validators/busValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, busAllocationController.getAllAllocations);
router.post('/', verifyToken, validate(busAllocationSchema), busAllocationController.createAllocation);
router.patch('/:id', verifyToken, validate(updateBusAllocationStatusSchema), busAllocationController.updateAllocation);
router.delete('/:id', verifyToken, busAllocationController.deleteAllocation);

module.exports = router;
