const express = require('express');
const router = express.Router();
const announcementController = require('../controllers/announcementController');
const { validate } = require('../middleware/validate');
const { announcementSchema } = require('../validators/announcementValidator');
const { verifyToken } = require('../middleware/auth');

router.get('/', verifyToken, announcementController.getAllAnnouncements);
router.get('/:id', verifyToken, announcementController.getAnnouncementById);
router.post('/', verifyToken, validate(announcementSchema), announcementController.createAnnouncement);
router.put('/:id', verifyToken, validate(announcementSchema), announcementController.updateAnnouncement);
router.delete('/:id', verifyToken, announcementController.deleteAnnouncement);

module.exports = router;
