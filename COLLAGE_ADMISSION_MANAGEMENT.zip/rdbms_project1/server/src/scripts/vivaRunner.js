#!/usr/bin/env node

/**
 * College Admission Management System — Interactive SQL Viva Query Runner
 * Demonstrates relational queries, joins, views, and aggregations directly in the terminal.
 */

const db = require('../config/db');

const QUERIES = [
  {
    title: '1. Multi-Table INNER JOIN (4 Entities: Applications, Students, Courses, Departments)',
    description: 'Lists all approved candidates along with their academic departments and entrance scores.',
    sql: `SELECT 
    s.student_id AS ID,
    s.name AS Student,
    s.marks AS Entrance,
    s.rank AS merit_rank,
    c.course_name AS Course,
    d.department_name AS Dept
FROM applications a
JOIN students s ON a.student_id = s.student_id
JOIN courses c ON a.course_id = c.course_id
JOIN departments d ON c.department_id = d.department_id
WHERE a.status = 'APPROVED'
ORDER BY s.marks DESC;`
  },
  {
    title: '2. LEFT OUTER JOIN with Multi-Table Aggregation (Departments Summary)',
    description: 'Aggregates counts of courses, mentors, and students per department.',
    sql: `SELECT 
    d.department_name AS Department,
    COUNT(DISTINCT c.course_id) AS Courses,
    COUNT(DISTINCT t.tutor_id) AS Faculty,
    COUNT(DISTINCT s.student_id) AS Enrolled,
    COALESCE(ROUND(AVG(s.marks), 2), 0) AS Avg_Marks
FROM departments d
LEFT JOIN courses c ON d.department_id = c.department_id
LEFT JOIN tutors t ON d.department_id = t.department_id
LEFT JOIN students s ON d.department_id = s.department_id
GROUP BY d.department_id, d.department_name
ORDER BY Enrolled DESC;`
  },
  {
    title: '3. Subquery with NOT IN (Unenrolled Applicants)',
    description: 'Identifies applicants who registered dossiers but have not submitted course applications.',
    sql: `SELECT 
    student_id AS ID, 
    name AS Student, 
    email AS Email, 
    marks AS Marks 
FROM students 
WHERE student_id NOT IN (
    SELECT DISTINCT student_id FROM applications
);`
  },
  {
    title: '4. Correlated Capacity Calculation (Hostel Vacancy Calculation)',
    description: 'Dynamically computes available beds by subtracting active resident count from total capacity.',
    sql: `SELECT 
    h.name AS Hostel,
    h.type AS Type,
    h.number_of_seats AS Total_Capacity,
    (SELECT COUNT(*) FROM hostel_allocations ha WHERE ha.hostel_id = h.hostel_id AND ha.status = 'Active') AS Occupied,
    (h.number_of_seats - (SELECT COUNT(*) FROM hostel_allocations ha WHERE ha.hostel_id = h.hostel_id AND ha.status = 'Active')) AS Vacant
FROM hostels h;`
  },
  {
    title: '5. GROUP BY with HAVING (Departments with Average Marks > 85.00)',
    description: 'Filters departments where admitted candidates maintain top merit averages.',
    sql: `SELECT 
    d.department_name AS Department,
    COUNT(s.student_id) AS Students,
    ROUND(AVG(s.marks), 2) AS Avg_Score,
    MAX(s.marks) AS Max_Score
FROM departments d
JOIN students s ON d.department_id = s.department_id
GROUP BY d.department_id, d.department_name
HAVING AVG(s.marks) > 85.00
ORDER BY Avg_Score DESC;`
  },
  {
    title: '6. Database View: view_department_stats',
    description: 'Real-time aggregated view of university departments.',
    sql: `SELECT * FROM view_department_stats ORDER BY total_students DESC;`
  },
  {
    title: '7. Database View: view_hostel_occupancy',
    description: 'Live residential occupancy and available bed tracking.',
    sql: `SELECT * FROM view_hostel_occupancy;`
  },
  {
    title: '8. Database View: view_bus_occupancy',
    description: 'Daily commuter vehicle route seating occupancy.',
    sql: `SELECT * FROM view_bus_occupancy;`
  },
  {
    title: '9. Stored Function: fn_calculate_merit_score (Composite Weighting)',
    description: 'Computes formula: 50% Entrance Exam + 25% 10th Board + 25% 12th Board.',
    sql: `SELECT 
    student_id AS ID,
    name AS Student,
    marks AS Entrance,
    tenth_marks AS Board_10th,
    twelfth_marks AS Board_12th,
    fn_calculate_merit_score(marks, tenth_marks, twelfth_marks) AS Composite_Score
FROM students
ORDER BY Composite_Score DESC
LIMIT 5;`
  }
];

async function main() {
  console.log('\n================================================================');
  console.log('🎓 College Admission System — RDBMS Viva Demonstration Runner');
  console.log('================================================================\n');

  const health = await db.testConnection();
  console.log(`Database Dialect: ${health.dialect.toUpperCase()}`);
  console.log(`Status:           ${health.message}\n`);

  if (!health.connected) {
    await db.pool.end();
    process.exitCode = 1;
    return;
  }
  let failures = 0;
  for (let i = 0; i < QUERIES.length; i++) {
    const q = QUERIES[i];
    console.log('----------------------------------------------------------------');
    console.log(`📌 ${q.title}`);
    console.log(`   ${q.description}`);
    console.log('----------------------------------------------------------------');

    try {
      const rows = await db.query(q.sql);
      if (Array.isArray(rows) && rows.length > 0) {
        console.table(rows);
      } else {
        console.log('   (0 rows returned)\n');
      }
    } catch (err) {
      failures++;
      console.error(`❌ Execution error: ${err.message}\n`);
    }
  }

  console.log('================================================================');
  console.log(failures ? `Demonstration failed: ${failures} query errors.` : 'Demonstration completed successfully.');
  console.log('================================================================\n');

  await db.pool.end();
  process.exitCode = failures ? 1 : 0;
}

main().catch(err => {
  console.error('Fatal error running viva queries:', err);
  process.exit(1);
});
