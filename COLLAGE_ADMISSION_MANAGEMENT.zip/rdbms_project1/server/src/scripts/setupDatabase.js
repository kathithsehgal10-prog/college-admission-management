const mysql = require('mysql2/promise');
const config = require('../config/env');
const fs = require('node:fs');
const path = require('node:path');
// Understand MySQL CLI DELIMITER directives without enabling multipleStatements.
function statements(source) {
  let delimiter = ';'; let buffer = ''; const result = [];
  for (const line of source.split('\n')) {
    const directive = line.match(/^\s*DELIMITER\s+(\S+)\s*$/i);
    if (directive) { delimiter = directive[1]; continue; }
    if (/^\s*--/.test(line) || !line.trim()) continue;
    buffer += line + '\n';
    if (buffer.trimEnd().endsWith(delimiter)) {
      result.push(buffer.trimEnd().slice(0, -delimiter.length)); buffer = '';
    }
  }
  if (buffer.trim()) throw Error('Unterminated SQL statement.');
  return result;
}
async function main() {
  const name = config.db.database;
  if (!/^[a-zA-Z0-9_]+$/.test(name)) throw Error('Use letters, numbers and underscores in DB_NAME.');
  const { database, ...options } = config.db;
  const connection = await mysql.createConnection(options);
  try {
    const [tables] = await connection.query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?', [name]);
    if (tables.length) throw Error(`Database ${name} already contains tables. Setup refuses to overwrite existing data. Use a new DB_NAME or review an explicit migration.`);
    for (const file of ['schema.sql', 'seed.sql', 'procedures_and_triggers.sql']) {
      const source = fs.readFileSync(path.resolve(__dirname, '../../../database', file), 'utf8').replace(/\bcollege_admission\b/g, name);
      for (const sql of statements(source)) await connection.query(sql);
      console.log(`Imported ${file}`);
    }
    console.log(`Created MySQL database ${name}. Next: npm run create-admin.`);
  } finally { await connection.end(); }
}
if (require.main === module) main().catch(error => { console.error(error.message); process.exitCode = 1; });
module.exports = { statements };
