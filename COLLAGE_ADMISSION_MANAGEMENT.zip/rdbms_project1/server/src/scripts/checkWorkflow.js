const path=require('node:path');
const root=path.resolve(__dirname,'../../..');
const config=require('../config/env');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const credentialPath=path.join(root,'server/credentials.local.json');
const credentials=fs.existsSync(credentialPath)?JSON.parse(fs.readFileSync(credentialPath,'utf8')):{app:{email:process.env.DEMO_ADMIN_EMAIL,password:process.env.DEMO_ADMIN_PASSWORD},workbench:config.db};
if(!credentials.app.email||!credentials.app.password)throw Error('Set DEMO_ADMIN_EMAIL and DEMO_ADMIN_PASSWORD for live checks.');
const mysql=require('mysql2/promise');
const base=`http://127.0.0.1:${config.port}/api`;
let token='';const checks=[];const created={students:[],hostels:[],buses:[],courses:[]};
async function call(method,url,body,status=200){
 const response=await fetch(base+url,{method,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})});
 const text=await response.text();let data;try{data=JSON.parse(text)}catch{data=text}
 assert.equal(response.status,status,`${method} ${url}: ${text}`);
 return data;
}
function pass(name){checks.push({name,passed:true});console.log('PASS',name)}
async function main(){
 const health=await call('GET','/health');assert.equal(health.database.connected,true);assert.equal(health.database.dialect,'mysql');assert.equal(health.database.port,config.db.port);pass('Real MySQL health');
 await call('GET','/students',null,401);pass('Unauthenticated API blocked');
 await call('POST','/auth/login',{email:credentials.app.email,password:'invalid'},401);pass('Incorrect password blocked');
 const auth=await call('POST','/auth/login',credentials.app);token=auth.data.token;assert.ok(token);pass('Administrator login');
 for(const url of ['/auth/me','/dashboard/stats','/dashboard/charts','/dashboard/recent-activity','/students','/departments','/courses','/tutors','/applications','/hostels','/hostel-allocations','/buses','/bus-allocations','/admission-cycles','/announcements','/payments','/reports/summary','/viva/schema'])await call('GET',url);
 pass('All UI data endpoints');
 const suffix=Date.now();
 for(const label of ['A','B']){
  const body={name:'Verification Student '+label,gender:'Male',age:19,address:'Fictional campus address',phone:'9876543210',email:`check-${suffix}-${label}@example.com`,marks:85,tenth_marks:88,twelfth_marks:90};
  const response=await call('POST','/students',body,201);created.students.push(response.data.student_id);
 }
 const connection=await mysql.createConnection({host:credentials.workbench.host,port:credentials.workbench.port,user:credentials.workbench.user,password:credentials.workbench.password,database:credentials.workbench.database});
 const [rows]=await connection.query('SELECT name FROM students WHERE student_id = ?',[created.students[0]]);assert.equal(rows[0].name,'Verification Student A');await connection.end();pass('Student creation persists in MySQL');
 const course=await call('POST','/courses',{course_name:'Verification course '+suffix,course_code:'CHK'+String(suffix).slice(-8),duration_years:4,department_id:1,intake_capacity:1},201);created.courses.push(course.data.course_id);
 const app=await call('POST','/applications',{student_id:created.students[0],course_id:course.data.course_id,cycle_id:1},201);
 const other=await call('POST','/applications',{student_id:created.students[1],course_id:course.data.course_id,cycle_id:1},201);
 await call('PATCH',`/applications/${app.data.application_id}/status`,{status:'APPROVED'});
 const details=await call('GET',`/students/${created.students[0]}`);assert.equal(details.data.department_id,1);
 const history=await call('GET',`/applications/${app.data.application_id}`);assert.ok(history.data.history.length>=2);pass('Approval, enrollment and status history');
 await call('PATCH',`/applications/${other.data.application_id}/status`,{status:'APPROVED'},409);pass('Course capacity enforced');
 await call('POST','/applications',{student_id:created.students[0],course_id:2,status:'APPROVED',cycle_id:1},409);pass('Second approved admission blocked');
 await call('PATCH',`/applications/${app.data.application_id}/status`,{status:'REJECTED'});
 const revoked=await call('GET',`/students/${created.students[0]}`);assert.equal(revoked.data.department_id,null);pass('Revocation synchronizes enrollment');
 for(const kind of ['hostel','bus']){
  const url=kind==='hostel'?'/hostels':'/buses';
  const body=kind==='hostel'?{name:'Verification Hostel '+suffix,type:'Boys',address:'Fictional campus hostel',number_of_seats:1}:{bus_number:'CHK-'+suffix,route:'Fictional verification route',destination:'Campus',capacity:1};
  const resource=await call('POST',url,body,201);const key=kind+'_id', id=resource.data[key];created[kind==='hostel'?'hostels':'buses'].push(id);
  const allocUrl='/'+kind+'-allocations';
  const first=await call('POST',allocUrl,{student_id:created.students[0],[key]:id},201);
  await call('POST',allocUrl,{student_id:created.students[1],[key]:id},409);
  await call('PATCH',`${allocUrl}/${first.data.allocation_id}`,{status:kind==='hostel'?'Vacated':'Cancelled'});
  await call('POST',allocUrl,{student_id:created.students[1],[key]:id},201);
  await call('PATCH',`${allocUrl}/${first.data.allocation_id}`,{status:'Active'},409);pass(kind+' capacity and reactivation');
 }
 await call('POST','/payments',{application_id:app.data.application_id,amount:100,transaction_reference:'CHECK-'+suffix},201);pass('Payment ledger record');
 const csv=await call('GET','/reports/export/payments');assert.match(csv,/Transaction Reference/);pass('CSV export');
 const catalog=await call('GET','/viva/queries');for(const item of catalog.data)await call('POST','/viva/execute',{queryId:item.id});pass('All SQL viva queries through API');
 await call('POST','/viva/execute',{sql:'DELETE FROM students'},400);pass('SQL modification blocked');
}
(async()=>{
 try{await main()}
 finally{
  for(const id of created.students)await call('DELETE','/students/'+id);
  for(const id of created.hostels)await call('DELETE','/hostels/'+id);
  for(const id of created.buses)await call('DELETE','/buses/'+id);
  for(const id of created.courses)await call('DELETE','/courses/'+id);
 }
 fs.writeFileSync(root+'/docs/LIVE_DEMO_VERIFICATION.json',JSON.stringify({checkedAt:new Date().toISOString(),api:base,database:config.db.database,mysqlPort:config.db.port,checks,testRecordsCleaned:true},null,2));
 console.log('Verified',checks.length,'live checks; test records cleaned.');
})().catch(error=>{console.error(error.message);process.exitCode=1});
