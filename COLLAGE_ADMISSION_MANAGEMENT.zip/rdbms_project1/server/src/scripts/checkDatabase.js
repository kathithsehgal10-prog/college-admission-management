const db = require('../config/db');
const fs = require('node:fs');
const path = require('node:path');
async function main() {
  const health = await db.testConnection();
  if (!health.connected) throw Error(health.message);
  const [version] = await db.query('SELECT VERSION() AS version, DATABASE() AS database_name');
  const tables = await db.query("SELECT TABLE_NAME AS name FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME");
  const expected = ['users', 'admins', 'departments', 'courses', 'tutors', 'students', 'admission_cycles', 'applications', 'application_status_history', 'hostels', 'hostel_allocations', 'buses', 'bus_allocations', 'announcements', 'payments', 'audit_logs'];
  const missing = expected.filter(name => !tables.some(table => table.name === name));
  if (missing.length) throw Error(`Missing MySQL tables: ${missing.join(', ')}. Import or migrate the schema.`);
  const controller = require('../controllers/vivaController');
  let catalog;
  await controller.getVivaQueries({}, { status() { return this; }, json(body) { catalog = body.data; } });
  const queryResults = [];
  for (const query of catalog) {
    const rows = await db.readOnlyQuery(query.sql);
    queryResults.push({ id: query.id, rows: rows.length, passed: true });
  }
  let metadata;
  await controller.getSchemaMetadata({}, { status() { return this; }, json(body) { metadata = body.data; } }, error => { throw error; });
  const report = { checkedAt: new Date().toISOString(), ...version, tables: tables.map(row => row.name), metadata, queries: queryResults };
  const output = path.resolve(__dirname, '../../../docs/MYSQL_VERIFICATION.json');
  fs.writeFileSync(output, JSON.stringify(report, null, 2));
  console.log(`Verified real MySQL ${version.version}: ${tables.length} tables, ${queryResults.length} SQL demonstrations. Evidence saved to docs/MYSQL_VERIFICATION.json.`);
}
main().catch(error => { console.error(error.message); process.exitCode = 1; }).finally(() => db.pool.end());
