const mysql = require('mysql2/promise');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const readline = require('node:readline');
const bcrypt = require('bcryptjs');
const { statements } = require('./setupDatabase');
const config = require('../config/env');
const rootPath = path.resolve(__dirname, '../../..');
function prompt(text) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(text, value => { rl.close(); resolve(value); }));
}
async function main() {
  const password = process.env.MYSQL_ADMIN_PASSWORD || (config.db.user === 'root' ? config.db.password : '') || await prompt('Existing MySQL root password (input is visible; do not screen-share): ');
  const port = Number(process.env.MYSQL_ADMIN_PORT || config.db.port);
  const admin = await mysql.createConnection({ host: '127.0.0.1', port, user: 'root', password });
  const database = 'college_submission';
  const user = 'cams_submission';
  const dbPassword = 'Cams!' + crypto.randomBytes(12).toString('base64url');
  const loginPassword = 'Demo!' + crypto.randomBytes(9).toString('base64url');
  try {
    const [tables] = await admin.query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?', [database]);
    if (tables.length) {
      if (process.env.CAMS_RESUME_EMPTY_SETUP !== 'true') throw Error(`${database} already has tables. Refusing to overwrite it.`);
      // Only resume the empty schema created by this interrupted setup.
      for (const table of tables) {
        const name = table.TABLE_NAME;
        if (!/^[a-zA-Z0-9_]+$/.test(name)) throw Error('Unexpected table name.');
        const [counts] = await admin.query(`SELECT COUNT(*) AS total FROM \`${database}\`.\`${name}\``);
        if (Number(counts[0].total)) throw Error('Partial database contains data; automatic replay refused.');
      }
    }
    const [accounts] = await admin.query("SELECT User FROM mysql.user WHERE User = ? AND Host = 'localhost'", [user]);
    if (accounts.length) throw Error(`${user} already exists. Refusing to change its password.`);
    for (const file of ['schema.sql', 'seed.sql', 'procedures_and_triggers.sql']) {
      const sql = fs.readFileSync(path.join(rootPath, 'database', file), 'utf8').replace(/\bcollege_admission\b/g, database);
      for (const statement of statements(sql)) {
        try { await admin.query(statement); }
        catch (error) { error.message = `${file}: ${error.message} (${error.code})`; throw error; }
      }
      console.log(`Imported ${file}`);
    }
    // New dedicated account: limited to this project's database.
    await admin.query("CREATE USER ?@'localhost' IDENTIFIED BY ?", [user, dbPassword]);
    await admin.query("GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON `college_submission`.* TO ?@'localhost'", [user]);
    const hash = await bcrypt.hash(loginPassword, 10);
    await admin.query('INSERT INTO college_submission.admins (admin_name, email, password_hash, role) VALUES (?, ?, ?, ?)', ['Submission Administrator', 'admin@college.edu', hash, 'admin']);
    const envPath = path.join(rootPath, 'server/.env');
    if (fs.existsSync(envPath)) fs.copyFileSync(envPath, envPath + '.before-provision.local');
    const env = `DB_HOST=127.0.0.1\nDB_PORT=${port}\nDB_USER=${user}\nDB_PASSWORD=${dbPassword}\nDB_NAME=${database}\nPORT=5001\nCLIENT_ORIGIN=http://localhost:5173\nJWT_SECRET=${crypto.randomBytes(32).toString('hex')}\nJWT_EXPIRES_IN=24h\nNODE_ENV=development\n`;
    fs.writeFileSync(envPath, env, { mode: 0o600 });
    fs.writeFileSync(path.join(rootPath, 'client/.env'), 'VITE_API_BASE_URL=http://localhost:5001/api\n');
    const credentials = { workbench: { name: 'CAMS Submission', host: '127.0.0.1', port, user, database, password: dbPassword }, app: { email: 'admin@college.edu', password: loginPassword } };
    fs.writeFileSync(path.join(rootPath, 'server/credentials.local.json'), JSON.stringify(credentials, null, 2), { mode: 0o600 });
    console.log('Created database, project account, administrator, and project configuration.');
    console.log('Workbench / MySQL username:', user);
    console.log('Workbench / MySQL password:', dbPassword);
    console.log('Application email: admin@college.edu');
    console.log('Application password:', loginPassword);
    console.log('Credentials saved locally in server/credentials.local.json (excluded from submission).');
  } finally { await admin.end(); }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
