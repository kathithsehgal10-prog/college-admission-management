const readline = require('readline');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { createAdminSchema } = require('../validators/authValidator');

async function prompt(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => {
    rl.question(question, answer => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

async function run() {
  console.log('\n======================================================');
  console.log(' College Admission System — Administrator Account Setup');
  console.log('======================================================\n');

  try {
    const health = await db.testConnection();
    if (!health.connected) {
      console.error('❌ Database connection failed:', health.message);
      console.error('Please verify MySQL is running and your server/.env settings are correct.\n');
      process.exit(1);
    }

    let adminName = process.env.ADMIN_NAME;
    let email = process.env.ADMIN_EMAIL;
    let password = process.env.ADMIN_PASSWORD;

    if (!adminName) {
      adminName = await prompt('Enter Administrator Name (e.g., Admin Officer): ');
    }
    if (!email) {
      email = await prompt('Enter Administrator Email: ');
    }
    if (!password) {
      password = await prompt('Enter Administrator Password (min 8 chars): ');
    }

    // Validate using Zod schema
    const validation = createAdminSchema.safeParse({ admin_name: adminName, email, password });
    if (!validation.success) {
      console.error('\n❌ Input Validation Error:');
      validation.error.errors.forEach(err => console.error(`  - ${err.path.join('.')}: ${err.message}`));
      process.exit(1);
    }

    // Hash password with salt rounds = 10
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Check if user already exists
    const existing = await db.query('SELECT admin_id FROM admins WHERE email = ?', [email]);
    if (existing.length > 0) {
      console.log(`\nAdministrator with email "${email}" already exists. Updating password...`);
      await db.query('UPDATE admins SET admin_name = ?, password_hash = ? WHERE email = ?', [
        adminName,
        passwordHash,
        email
      ]);
      console.log('✅ Administrator account updated successfully!\n');
    } else {
      await db.query(
        'INSERT INTO admins (admin_name, email, password_hash, role) VALUES (?, ?, ?, ?)',
        [adminName, email, passwordHash, 'admin']
      );
      console.log(`\n✅ Administrator "${adminName}" (${email}) created successfully!\n`);
    }

    process.exit(0);
  } catch (error) {
    console.error('\n❌ Error creating administrator:', error.message);
    process.exit(1);
  }
}

run();
