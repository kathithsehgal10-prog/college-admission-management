const app = require('./app');
const config = require('./config/env');
const db = require('./config/db');

const server = app.listen(config.port, async () => {
  console.log('\n======================================================');
  console.log(`🚀 College Admission System API running on port ${config.port}`);
  console.log(`   Health endpoint: http://localhost:${config.port}/api/health`);
  console.log(`   Environment:     ${config.nodeEnv}`);
  console.log('======================================================');

  // Perform non-blocking initial database connectivity check
  const dbHealth = await db.testConnection();
  if (dbHealth.dialect === 'mysql' && dbHealth.connected) {
    console.log(`✅ Connected to MySQL Database: ${dbHealth.databaseName} @ ${dbHealth.host}:${dbHealth.port}`);
  } else {
    console.log('⚠️  Database is not connected yet.');
    console.log(`   Status: ${dbHealth.message}`);
  }
  console.log('======================================================\n');
});

server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? `Port ${config.port} is already in use. Stop the other API or change PORT and VITE_API_BASE_URL together.` : error.message);
  process.exit(1);
});

function handleShutdown(signal) {
  console.log(`\nReceived ${signal}. Shutting down server gracefully...`);
  server.close(async () => {
    if (db.pool) {
      try {
        await db.pool.end();
        console.log('MySQL connection pool closed.');
      } catch (err) {
        console.error('Error closing MySQL pool:', err.message);
      }
    }
    console.log('Process terminated.');
    process.exit(0);
  });
}

process.on('SIGTERM', () => handleShutdown('SIGTERM'));
process.on('SIGINT', () => handleShutdown('SIGINT'));

module.exports = server;
