const { ZodError } = require('zod');

/**
 * Validate incoming request against a Zod schema
 * @param {import('zod').ZodSchema} schema - Zod schema to validate with
 * @param {'body' | 'query' | 'params'} source - Request property to inspect (default 'body')
 */
function validate(schema, source = 'body') {
  return (req, res, next) => {
    try {
      const parsed = schema.parse(req[source]);
      req[source] = parsed;
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const issues = error.errors.map(err => ({
          field: err.path.join('.'),
          message: err.message
        }));
        return res.status(400).json({
          success: false,
          message: 'Validation failed for request data.',
          errors: issues
        });
      }
      next(error);
    }
  };
}

module.exports = { validate };
