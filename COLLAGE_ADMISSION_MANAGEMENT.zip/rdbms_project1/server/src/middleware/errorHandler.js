const config = require('../config/env');

function errorHandler(err, req, res, next) {
  // eslint-disable-next-line no-console
  if (config.nodeEnv !== 'test') {
    console.error(`[Error] ${req.method} ${req.originalUrl}:`, err.message);
  }

  // Database unavailable / connection error
  if (err.statusCode === 503 || err.code === 'ECONNREFUSED' || err.code === 'ER_ACCESS_DENIED_ERROR') {
    return res.status(503).json({
      success: false,
      message: err.message || 'Database connection is currently unavailable. Please verify MySQL server configuration in server/.env.',
      code: 'DATABASE_UNAVAILABLE'
    });
  }

  // MySQL Duplicate Key Error (e.g. unique email, duplicate application)
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({
      success: false,
      message: 'A record with this information already exists (Duplicate entry).',
      detail: err.sqlMessage || err.message,
      code: 'DUPLICATE_ENTRY'
    });
  }

  // MySQL Foreign Key Constraint on Delete (Child records exist)
  if (err.code === 'ER_ROW_IS_REFERENCED_2') {
    return res.status(409).json({
      success: false,
      message: 'Cannot delete or update this record because related child records depend on it.',
      detail: 'Referential integrity constraint prevents deletion while dependent records exist.',
      code: 'FOREIGN_KEY_CONFLICT'
    });
  }

  // MySQL Foreign Key Not Found on Insert (Referenced parent record doesn't exist)
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(400).json({
      success: false,
      message: 'Referenced foreign record does not exist.',
      detail: err.sqlMessage || err.message,
      code: 'INVALID_FOREIGN_KEY'
    });
  }

  if (err.code === 'ER_SIGNAL_EXCEPTION' || err.code === 'ER_CHECK_CONSTRAINT_VIOLATED') {
    return res.status(409).json({ success: false, message: err.sqlMessage || 'Database business rule rejected this change.' });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ success: false, message: 'Request body must contain valid JSON.' });
  }
  // Custom status code or default 500
  const statusCode = err.statusCode || 500;
  const response = {
    success: false,
    message: err.message || 'An unexpected internal server error occurred.'
  };

  if (err.errors) {
    response.errors = err.errors;
  }

  if (config.nodeEnv === 'development' && statusCode === 500) {
    response.stack = err.stack;
  }

  res.status(statusCode).json(response);
}

module.exports = errorHandler;
