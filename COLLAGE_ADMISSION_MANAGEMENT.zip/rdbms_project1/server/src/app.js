const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const config = require('./config/env');
const errorHandler = require('./middleware/errorHandler');

// Route modules
const healthRoutes = require('./routes/healthRoutes');
const authRoutes = require('./routes/authRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const studentRoutes = require('./routes/studentRoutes');
const departmentRoutes = require('./routes/departmentRoutes');
const courseRoutes = require('./routes/courseRoutes');
const tutorRoutes = require('./routes/tutorRoutes');
const applicationRoutes = require('./routes/applicationRoutes');
const hostelRoutes = require('./routes/hostelRoutes');
const hostelAllocationRoutes = require('./routes/hostelAllocationRoutes');
const busRoutes = require('./routes/busRoutes');
const busAllocationRoutes = require('./routes/busAllocationRoutes');
const reportRoutes = require('./routes/reportRoutes');
const vivaRoutes = require('./routes/vivaRoutes');
const cycleRoutes = require('./routes/cycleRoutes');
const announcementRoutes = require('./routes/announcementRoutes');
const paymentRoutes = require('./routes/paymentRoutes');

const app = express();

// Security and utility middleware
app.use(helmet());

// Dynamic CORS configuration allowing clientOrigin and local Vite dev hosts
const allowedOrigins = [
  config.clientOrigin,
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:3000'
].filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (like mobile apps, curl, or server-to-server)
      if (!origin || allowedOrigins.includes(origin) || config.nodeEnv === 'development') {
        callback(null, true);
      } else {
        callback(new Error('CORS origin blocked by security policy.'));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
  })
);

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

if (config.nodeEnv !== 'test') {
  app.use(morgan('dev'));
}

// API Routes
app.use('/api', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/tutors', tutorRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/hostels', hostelRoutes);
app.use('/api/hostel-allocations', hostelAllocationRoutes);
app.use('/api/buses', busRoutes);
app.use('/api/bus-allocations', busAllocationRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/viva', vivaRoutes);
app.use('/api/admission-cycles', cycleRoutes);
app.use('/api/announcements', announcementRoutes);
app.use('/api/payments', paymentRoutes);

// Root informational endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    name: 'College Admission Management System API',
    status: 'online',
    version: '1.0.0',
    documentation: '/docs/API_DOCUMENTATION.md',
    healthCheck: '/api/health'
  });
});

// 404 handler for undefined endpoints
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Resource not found: ${req.method} ${req.originalUrl}`
  });
});

// Centralized error handler
app.use(errorHandler);

module.exports = app;
