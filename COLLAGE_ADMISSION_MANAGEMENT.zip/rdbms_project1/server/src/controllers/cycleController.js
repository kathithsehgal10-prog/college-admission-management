const db = require('../config/db');

async function getAllCycles(req, res, next) {
  try {
    const status = req.query.status ? req.query.status.trim().toUpperCase() : '';
    const search = req.query.search ? req.query.search.trim() : '';

    const whereClauses = [];
    const params = [];

    if (status && ['UPCOMING', 'ACTIVE', 'CLOSED'].includes(status)) {
      whereClauses.push('c.status = ?');
      params.push(status);
    }

    if (search) {
      whereClauses.push('(c.cycle_name LIKE ? OR c.description LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    const sql = `
      SELECT 
        c.cycle_id,
        c.cycle_name,
        DATE_FORMAT(c.start_date, '%Y-%m-%d') AS start_date,
        DATE_FORMAT(c.end_date, '%Y-%m-%d') AS end_date,
        c.status,
        c.description,
        COUNT(a.application_id) AS total_applications,
        COUNT(CASE WHEN a.status IN ('APPROVED', 'Approved') THEN 1 END) AS approved_applications,
        c.created_at,
        c.updated_at
      FROM admission_cycles c
      LEFT JOIN applications a ON c.cycle_id = a.cycle_id
      ${whereSql}
      GROUP BY c.cycle_id, c.cycle_name, c.start_date, c.end_date, c.status, c.description, c.created_at, c.updated_at
      ORDER BY c.start_date DESC
    `;

    const cycles = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: cycles
    });
  } catch (error) {
    next(error);
  }
}

async function getCycleById(req, res, next) {
  try {
    const { id } = req.params;
    const [cycle] = await db.query(
      `
      SELECT 
        c.cycle_id,
        c.cycle_name,
        DATE_FORMAT(c.start_date, '%Y-%m-%d') AS start_date,
        DATE_FORMAT(c.end_date, '%Y-%m-%d') AS end_date,
        c.status,
        c.description,
        COUNT(a.application_id) AS total_applications
      FROM admission_cycles c
      LEFT JOIN applications a ON c.cycle_id = a.cycle_id
      WHERE c.cycle_id = ?
      GROUP BY c.cycle_id, c.cycle_name, c.start_date, c.end_date, c.status, c.description
      LIMIT 1
      `,
      [id]
    );

    if (!cycle) {
      return res.status(404).json({ success: false, message: `Admission cycle #${id} not found.` });
    }

    res.status(200).json({ success: true, data: cycle });
  } catch (error) {
    next(error);
  }
}

async function createCycle(req, res, next) {
  try {
    const { cycle_name, start_date, end_date, status, description } = req.body;

    const existing = await db.query('SELECT cycle_id FROM admission_cycles WHERE cycle_name = ?', [cycle_name]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: 'An admission cycle with this name already exists.' });
    }

    const result = await db.query(
      'INSERT INTO admission_cycles (cycle_name, start_date, end_date, status, description) VALUES (?, ?, ?, ?, ?)',
      [cycle_name, start_date, end_date, status || 'ACTIVE', description || null]
    );

    const [newCycle] = await db.query(
      `SELECT cycle_id, cycle_name, DATE_FORMAT(start_date, '%Y-%m-%d') AS start_date, DATE_FORMAT(end_date, '%Y-%m-%d') AS end_date, status, description FROM admission_cycles WHERE cycle_id = ?`,
      [result.insertId]
    );

    res.status(201).json({
      success: true,
      message: 'Admission cycle created successfully.',
      data: newCycle
    });
  } catch (error) {
    next(error);
  }
}

async function updateCycle(req, res, next) {
  try {
    const { id } = req.params;
    const { cycle_name, start_date, end_date, status, description } = req.body;

    const [existing] = await db.query('SELECT cycle_id FROM admission_cycles WHERE cycle_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ success: false, message: `Admission cycle #${id} not found.` });
    }

    if (cycle_name) {
      const conflict = await db.query('SELECT cycle_id FROM admission_cycles WHERE cycle_name = ? AND cycle_id != ?', [cycle_name, id]);
      if (conflict.length > 0) {
        return res.status(409).json({ success: false, message: 'Cycle name already in use by another session.' });
      }
    }

    await db.query(
      `UPDATE admission_cycles 
       SET cycle_name = COALESCE(?, cycle_name),
           start_date = COALESCE(?, start_date),
           end_date = COALESCE(?, end_date),
           status = COALESCE(?, status),
           description = COALESCE(?, description)
       WHERE cycle_id = ?`,
      [cycle_name, start_date, end_date, status, description, id]
    );

    const [updated] = await db.query(
      `SELECT cycle_id, cycle_name, DATE_FORMAT(start_date, '%Y-%m-%d') AS start_date, DATE_FORMAT(end_date, '%Y-%m-%d') AS end_date, status, description FROM admission_cycles WHERE cycle_id = ?`,
      [id]
    );

    res.status(200).json({
      success: true,
      message: 'Admission cycle updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteCycle(req, res, next) {
  try {
    const { id } = req.params;

    const [existing] = await db.query('SELECT cycle_id FROM admission_cycles WHERE cycle_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ success: false, message: `Admission cycle #${id} not found.` });
    }

    // Check if applications reference this cycle
    const [apps] = await db.query('SELECT COUNT(*) AS count FROM applications WHERE cycle_id = ?', [id]);
    if (apps && apps.count > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete cycle #${id}: ${apps.count} applications are associated with this admission cycle.`
      });
    }

    await db.query('DELETE FROM admission_cycles WHERE cycle_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Admission cycle #${id} deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllCycles,
  getCycleById,
  createCycle,
  updateCycle,
  deleteCycle
};
