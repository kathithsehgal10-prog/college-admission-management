const db = require('../config/db');

async function getAllDepartments(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';
    let sql = `
      SELECT 
        d.department_id,
        d.department_name,
        d.code,
        d.description,
        COUNT(DISTINCT c.course_id) AS total_courses,
        COUNT(DISTINCT t.tutor_id) AS total_tutors,
        COUNT(DISTINCT s.student_id) AS total_students,
        d.created_at,
        d.updated_at
      FROM departments d
      LEFT JOIN courses c ON d.department_id = c.department_id
      LEFT JOIN tutors t ON d.department_id = t.department_id
      LEFT JOIN students s ON d.department_id = s.department_id
    `;
    const params = [];

    if (search) {
      sql += ' WHERE (d.department_name LIKE ? OR d.code LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' GROUP BY d.department_id, d.department_name, d.code, d.description ORDER BY d.department_id ASC';

    const departments = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: departments.map(d => ({
        ...d,
        total_courses: Number(d.total_courses),
        total_tutors: Number(d.total_tutors),
        total_students: Number(d.total_students)
      }))
    });
  } catch (error) {
    next(error);
  }
}

async function getDepartmentById(req, res, next) {
  const { id } = req.params;

  try {
    const [department] = await db.query(
      `
      SELECT 
        d.*,
        COUNT(DISTINCT c.course_id) AS total_courses,
        COUNT(DISTINCT t.tutor_id) AS total_tutors,
        COUNT(DISTINCT s.student_id) AS total_students
      FROM departments d
      LEFT JOIN courses c ON d.department_id = c.department_id
      LEFT JOIN tutors t ON d.department_id = t.department_id
      LEFT JOIN students s ON d.department_id = s.department_id
      WHERE d.department_id = ?
      GROUP BY d.department_id
      LIMIT 1
      `,
      [id]
    );

    if (!department) {
      return res.status(404).json({
        success: false,
        message: `Department with ID ${id} not found.`
      });
    }

    const [courses, tutors, students] = await Promise.all([
      db.query('SELECT course_id, course_name, duration_years, intake_capacity FROM courses WHERE department_id = ?', [id]),
      db.query('SELECT tutor_id, tutor_name, email, phone, qualification FROM tutors WHERE department_id = ?', [id]),
      db.query('SELECT student_id, name, email, marks, `rank` FROM students WHERE department_id = ? ORDER BY marks DESC LIMIT 10', [id])
    ]);

    res.status(200).json({
      success: true,
      data: {
        ...department,
        total_courses: Number(department.total_courses),
        total_tutors: Number(department.total_tutors),
        total_students: Number(department.total_students),
        courses,
        tutors,
        recentStudents: students
      }
    });
  } catch (error) {
    next(error);
  }
}

async function createDepartment(req, res, next) {
  const { department_name, code, description } = req.body;

  try {
    const result = await db.query(
      'INSERT INTO departments (department_name, code, description) VALUES (?, ?, ?)',
      [department_name, code || null, description || null]
    );

    res.status(201).json({
      success: true,
      message: 'Department created successfully.',
      data: {
        department_id: result.insertId,
        department_name,
        code,
        description
      }
    });
  } catch (error) {
    next(error);
  }
}

async function updateDepartment(req, res, next) {
  const { id } = req.params;
  const { department_name, code, description } = req.body;

  try {
    const [existing] = await db.query('SELECT department_id FROM departments WHERE department_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Department with ID ${id} not found.`
      });
    }

    await db.query(
      'UPDATE departments SET department_name = COALESCE(?, department_name), code = COALESCE(?, code), description = COALESCE(?, description) WHERE department_id = ?',
      [department_name, code, description, id]
    );

    const [updated] = await db.query('SELECT * FROM departments WHERE department_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: 'Department updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteDepartment(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT department_id, department_name FROM departments WHERE department_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Department with ID ${id} not found.`
      });
    }

    // Check if courses, tutors, or students are assigned
    const [coursesCount, tutorsCount, studentsCount] = await Promise.all([
      db.query('SELECT COUNT(*) AS count FROM courses WHERE department_id = ?', [id]),
      db.query('SELECT COUNT(*) AS count FROM tutors WHERE department_id = ?', [id]),
      db.query('SELECT COUNT(*) AS count FROM students WHERE department_id = ?', [id])
    ]);

    const numCourses = Number(coursesCount[0].count);
    const numTutors = Number(tutorsCount[0].count);
    const numStudents = Number(studentsCount[0].count);

    if (numCourses > 0 || numTutors > 0 || numStudents > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete department "${existing.department_name}" because active relations depend on it (${numCourses} courses, ${numTutors} tutors, ${numStudents} students). Please reassign or remove them first.`,
        code: 'FOREIGN_KEY_CONFLICT',
        dependencies: {
          courses: numCourses,
          tutors: numTutors,
          students: numStudents
        }
      });
    }

    await db.query('DELETE FROM departments WHERE department_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Department "${existing.department_name}" (ID: ${id}) deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllDepartments,
  getDepartmentById,
  createDepartment,
  updateDepartment,
  deleteDepartment
};
