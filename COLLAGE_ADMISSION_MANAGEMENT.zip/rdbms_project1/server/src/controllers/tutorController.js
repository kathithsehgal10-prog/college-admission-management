const db = require('../config/db');

async function getAllTutors(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';
    const departmentId = req.query.department_id ? parseInt(req.query.department_id, 10) : null;

    let sql = `
      SELECT 
        t.tutor_id,
        t.tutor_name,
        t.email,
        t.phone,
        t.qualification,
        t.department_id,
        d.department_name,
        d.code AS department_code,
        t.created_at,
        t.updated_at
      FROM tutors t
      JOIN departments d ON t.department_id = d.department_id
    `;
    const params = [];
    const whereClauses = [];

    if (search) {
      whereClauses.push('(t.tutor_name LIKE ? OR t.email LIKE ? OR t.phone LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (departmentId) {
      whereClauses.push('t.department_id = ?');
      params.push(departmentId);
    }

    if (whereClauses.length > 0) {
      sql += ` WHERE ${whereClauses.join(' AND ')}`;
    }

    sql += ' ORDER BY t.tutor_id ASC';

    const tutors = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: tutors
    });
  } catch (error) {
    next(error);
  }
}

async function getTutorById(req, res, next) {
  const { id } = req.params;

  try {
    const [tutor] = await db.query(
      `
      SELECT 
        t.*,
        d.department_name,
        d.code AS department_code
      FROM tutors t
      JOIN departments d ON t.department_id = d.department_id
      WHERE t.tutor_id = ?
      LIMIT 1
      `,
      [id]
    );

    if (!tutor) {
      return res.status(404).json({
        success: false,
        message: `Tutor with ID ${id} not found.`
      });
    }

    res.status(200).json({
      success: true,
      data: tutor
    });
  } catch (error) {
    next(error);
  }
}

async function createTutor(req, res, next) {
  const { tutor_name, email, phone, qualification, department_id } = req.body;

  try {
    const [dept] = await db.query('SELECT department_id FROM departments WHERE department_id = ?', [department_id]);
    if (!dept) {
      return res.status(400).json({
        success: false,
        message: `Department with ID ${department_id} does not exist.`
      });
    }

    const result = await db.query(
      'INSERT INTO tutors (tutor_name, email, phone, qualification, department_id) VALUES (?, ?, ?, ?, ?)',
      [tutor_name, email, phone, qualification || 'M.Tech / Ph.D', department_id]
    );

    res.status(201).json({
      success: true,
      message: 'Tutor profile created successfully.',
      data: {
        tutor_id: result.insertId,
        ...req.body
      }
    });
  } catch (error) {
    next(error);
  }
}

async function updateTutor(req, res, next) {
  const { id } = req.params;
  const { tutor_name, email, phone, qualification, department_id } = req.body;

  try {
    const [existing] = await db.query('SELECT tutor_id FROM tutors WHERE tutor_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Tutor with ID ${id} not found.`
      });
    }

    if (department_id) {
      const [dept] = await db.query('SELECT department_id FROM departments WHERE department_id = ?', [department_id]);
      if (!dept) {
        return res.status(400).json({
          success: false,
          message: `Department with ID ${department_id} does not exist.`
        });
      }
    }

    await db.query(
      `
      UPDATE tutors 
      SET tutor_name = COALESCE(?, tutor_name),
          email = COALESCE(?, email),
          phone = COALESCE(?, phone),
          qualification = COALESCE(?, qualification),
          department_id = COALESCE(?, department_id)
      WHERE tutor_id = ?
      `,
      [tutor_name, email, phone, qualification, department_id, id]
    );

    const [updated] = await db.query(
      `
      SELECT t.*, d.department_name 
      FROM tutors t 
      JOIN departments d ON t.department_id = d.department_id 
      WHERE t.tutor_id = ?
      `,
      [id]
    );

    res.status(200).json({
      success: true,
      message: 'Tutor details updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteTutor(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT tutor_id, tutor_name FROM tutors WHERE tutor_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Tutor with ID ${id} not found.`
      });
    }

    await db.query('DELETE FROM tutors WHERE tutor_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Tutor "${existing.tutor_name}" (ID: ${id}) deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllTutors,
  getTutorById,
  createTutor,
  updateTutor,
  deleteTutor
};
