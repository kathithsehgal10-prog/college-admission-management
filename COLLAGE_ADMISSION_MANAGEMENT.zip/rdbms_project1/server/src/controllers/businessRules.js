function fail(statusCode, message) { throw Object.assign(new Error(message), { statusCode }); }
async function checkAdmission(connection, studentId, courseId, excludeId = 0) {
  const [courses] = await connection.query('SELECT course_id, department_id, intake_capacity FROM courses WHERE course_id = ? FOR UPDATE', [courseId]);
  if (!courses.length) fail(404, 'Course not found.');
  const [other] = await connection.query("SELECT application_id FROM applications WHERE student_id = ? AND status = 'APPROVED' AND application_id <> ?", [studentId, excludeId]);
  if (other.length) fail(409, 'Student already has an approved admission. Revoke it before approving another course.');
  const [counts] = await connection.query("SELECT COUNT(*) AS total FROM applications WHERE course_id = ? AND status = 'APPROVED' AND application_id <> ?", [courseId, excludeId]);
  if (Number(counts[0].total) >= courses[0].intake_capacity) fail(409, 'Course intake capacity is full.');
  return courses[0];
}
async function syncDepartment(connection, studentId) {
  const [approved] = await connection.query("SELECT c.department_id FROM applications a JOIN courses c ON a.course_id = c.course_id WHERE a.student_id = ? AND a.status = 'APPROVED' ORDER BY a.application_id DESC LIMIT 1", [studentId]);
  await connection.query('UPDATE students SET department_id = ? WHERE student_id = ?', [approved[0]?.department_id ?? null, studentId]);
}
module.exports = { fail, checkAdmission, syncDepartment };
