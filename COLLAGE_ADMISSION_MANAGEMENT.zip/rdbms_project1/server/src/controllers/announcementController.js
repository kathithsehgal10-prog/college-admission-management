const db = require('../config/db');

async function getAllAnnouncements(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';
    const publishedOnly = req.query.published === 'true';

    const whereClauses = [];
    const params = [];

    if (publishedOnly) {
      whereClauses.push('is_published = 1');
    }

    if (search) {
      whereClauses.push('(title LIKE ? OR content LIKE ? OR published_by LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    const sql = `
      SELECT 
        announcement_id,
        title,
        content,
        published_by,
        is_published,
        published_at,
        created_at,
        updated_at
      FROM announcements
      ${whereSql}
      ORDER BY published_at DESC, announcement_id DESC
    `;

    const announcements = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: announcements
    });
  } catch (error) {
    next(error);
  }
}

async function getAnnouncementById(req, res, next) {
  try {
    const { id } = req.params;
    const [item] = await db.query('SELECT * FROM announcements WHERE announcement_id = ? LIMIT 1', [id]);

    if (!item) {
      return res.status(404).json({ success: false, message: `Announcement #${id} not found.` });
    }

    res.status(200).json({ success: true, data: item });
  } catch (error) {
    next(error);
  }
}

async function createAnnouncement(req, res, next) {
  try {
    const { title, content, published_by, is_published } = req.body;

    const result = await db.query(
      'INSERT INTO announcements (title, content, published_by, is_published, published_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)',
      [title, content, published_by || 'Admission Directorate', is_published === false ? 0 : 1]
    );

    const [newItem] = await db.query('SELECT * FROM announcements WHERE announcement_id = ?', [result.insertId]);

    res.status(201).json({
      success: true,
      message: 'Announcement published successfully.',
      data: newItem
    });
  } catch (error) {
    next(error);
  }
}

async function updateAnnouncement(req, res, next) {
  try {
    const { id } = req.params;
    const { title, content, published_by, is_published } = req.body;

    const [existing] = await db.query('SELECT announcement_id FROM announcements WHERE announcement_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ success: false, message: `Announcement #${id} not found.` });
    }

    await db.query(
      `UPDATE announcements 
       SET title = COALESCE(?, title),
           content = COALESCE(?, content),
           published_by = COALESCE(?, published_by),
           is_published = COALESCE(?, is_published)
       WHERE announcement_id = ?`,
      [title, content, published_by, is_published !== undefined ? (is_published ? 1 : 0) : null, id]
    );

    const [updated] = await db.query('SELECT * FROM announcements WHERE announcement_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: 'Announcement updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteAnnouncement(req, res, next) {
  try {
    const { id } = req.params;

    const [existing] = await db.query('SELECT announcement_id FROM announcements WHERE announcement_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ success: false, message: `Announcement #${id} not found.` });
    }

    await db.query('DELETE FROM announcements WHERE announcement_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Announcement #${id} deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllAnnouncements,
  getAnnouncementById,
  createAnnouncement,
  updateAnnouncement,
  deleteAnnouncement
};
