const db = require('../config/db');

async function getAllCourses(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';
    const departmentId = req.query.department_id ? parseInt(req.query.department_id, 10) : null;

    let sql = `
      SELECT 
        c.course_id,
        c.course_name,
        c.course_code,
        c.duration_years,
        c.department_id,
        c.intake_capacity,
        d.department_name,
        d.code AS department_code,
        COUNT(a.application_id) AS total_applications,
        COUNT(CASE WHEN a.status = 'APPROVED' THEN 1 END) AS approved_applications,
        c.created_at,
        c.updated_at
      FROM courses c
      JOIN departments d ON c.department_id = d.department_id
      LEFT JOIN applications a ON c.course_id = a.course_id
    `;
    const params = [];
    const whereClauses = [];

    if (search) {
      whereClauses.push('(c.course_name LIKE ? OR c.course_code LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }

    if (departmentId) {
      whereClauses.push('c.department_id = ?');
      params.push(departmentId);
    }

    if (whereClauses.length > 0) {
      sql += ` WHERE ${whereClauses.join(' AND ')}`;
    }

    sql += ' GROUP BY c.course_id, d.department_name, d.code ORDER BY c.course_id ASC';

    const courses = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: courses.map(c => ({
        ...c,
        total_applications: Number(c.total_applications),
        approved_applications: Number(c.approved_applications)
      }))
    });
  } catch (error) {
    next(error);
  }
}

async function getCourseById(req, res, next) {
  const { id } = req.params;

  try {
    const [course] = await db.query(
      `
      SELECT 
        c.*,
        d.department_name,
        d.code AS department_code,
        COUNT(a.application_id) AS total_applications,
        COUNT(CASE WHEN a.status = 'APPROVED' THEN 1 END) AS approved_applications
      FROM courses c
      JOIN departments d ON c.department_id = d.department_id
      LEFT JOIN applications a ON c.course_id = a.course_id
      WHERE c.course_id = ?
      GROUP BY c.course_id, d.department_name, d.code
      LIMIT 1
      `,
      [id]
    );

    if (!course) {
      return res.status(404).json({
        success: false,
        message: `Course with ID ${id} not found.`
      });
    }

    // Get recent applications for this course
    const applications = await db.query(
      `
      SELECT a.application_id, a.application_date, a.status, s.student_id, s.name AS student_name, s.marks
      FROM applications a
      JOIN students s ON a.student_id = s.student_id
      WHERE a.course_id = ?
      ORDER BY a.application_date DESC
      LIMIT 15
      `,
      [id]
    );

    res.status(200).json({
      success: true,
      data: {
        ...course,
        total_applications: Number(course.total_applications),
        approved_applications: Number(course.approved_applications),
        applications
      }
    });
  } catch (error) {
    next(error);
  }
}

async function createCourse(req, res, next) {
  const { course_name, course_code, duration_years, department_id, intake_capacity } = req.body;

  try {
    // Validate department exists
    const [dept] = await db.query('SELECT department_id FROM departments WHERE department_id = ?', [department_id]);
    if (!dept) {
      return res.status(400).json({
        success: false,
        message: `Department with ID ${department_id} does not exist.`
      });
    }

    const result = await db.query(
      'INSERT INTO courses (course_name, course_code, duration_years, department_id, intake_capacity) VALUES (?, ?, ?, ?, ?)',
      [course_name, course_code || null, duration_years || 4, department_id, intake_capacity || 60]
    );

    res.status(201).json({
      success: true,
      message: 'Course created successfully.',
      data: {
        course_id: result.insertId,
        ...req.body
      }
    });
  } catch (error) {
    next(error);
  }
}

async function updateCourse(req, res, next) {
  const { id } = req.params;
  const { course_name, course_code, duration_years, department_id, intake_capacity } = req.body;

  try {
    const updated = await db.withTransaction(async connection => {
    const txQuery = async (sql, params) => (await connection.query(sql, params.map(p => p === undefined ? null : p)))[0];
    const [existing] = await txQuery('SELECT course_id FROM courses WHERE course_id = ? FOR UPDATE', [id]);
    if (!existing) {
      throw Object.assign(new Error(`Course with ID ${id} not found.`), { statusCode: 404 });
    }

    const [count] = await txQuery("SELECT COUNT(*) AS total FROM applications WHERE course_id = ? AND status = 'APPROVED'", [id]);
    if (intake_capacity !== undefined && intake_capacity < Number(count.total)) {
      throw Object.assign(new Error('Course capacity cannot be below current approved admissions.'), { statusCode: 409 });
    }
    if (department_id && Number(count.total) > 0) {
      const [course] = await txQuery('SELECT department_id FROM courses WHERE course_id = ?', [id]);
      if (Number(department_id) !== Number(course.department_id)) {
        throw Object.assign(new Error('Revoke approved admissions before changing this course department.'), { statusCode: 409 });
      }
    }
    if (department_id) {
      const [dept] = await txQuery('SELECT department_id FROM departments WHERE department_id = ?', [department_id]);
      if (!dept) {
        throw Object.assign(new Error(`Department with ID ${department_id} does not exist.`), { statusCode: 400 });
      }
    }

    await txQuery(
      `
      UPDATE courses 
      SET course_name = COALESCE(?, course_name),
          course_code = COALESCE(?, course_code),
          duration_years = COALESCE(?, duration_years),
          department_id = COALESCE(?, department_id),
          intake_capacity = COALESCE(?, intake_capacity)
      WHERE course_id = ?
      `,
      [course_name, course_code, duration_years, department_id, intake_capacity, id]
    );

    const [updated] = await txQuery(
      `
      SELECT c.*, d.department_name 
      FROM courses c 
      JOIN departments d ON c.department_id = d.department_id 
      WHERE c.course_id = ?
      `,
      [id]
    );

    return updated;
    });

    res.status(200).json({
      success: true,
      message: 'Course updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteCourse(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT course_id, course_name FROM courses WHERE course_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Course with ID ${id} not found.`
      });
    }

    // Check application history
    const [apps] = await db.query('SELECT COUNT(*) AS count FROM applications WHERE course_id = ?', [id]);
    const appCount = Number(apps.count);

    if (appCount > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete course "${existing.course_name}" because ${appCount} admission applications are registered under it.`,
        code: 'FOREIGN_KEY_CONFLICT'
      });
    }

    await db.query('DELETE FROM courses WHERE course_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Course "${existing.course_name}" (ID: ${id}) deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllCourses,
  getCourseById,
  createCourse,
  updateCourse,
  deleteCourse
};
