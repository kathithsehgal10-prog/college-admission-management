const db = require('../config/db');

async function getAllAllocations(req, res, next) {
  try {
    const busId = req.query.bus_id ? parseInt(req.query.bus_id, 10) : null;
    const status = req.query.status ? req.query.status.trim() : '';
    const search = req.query.search ? req.query.search.trim() : '';

    let sql = `
      SELECT 
        ba.allocation_id,
        ba.student_id,
        s.name AS student_name,
        s.email AS student_email,
        s.phone AS student_phone,
        ba.bus_id,
        b.bus_number,
        b.route,
        b.destination,
        ba.allocation_date,
        ba.status,
        ba.created_at,
        ba.updated_at
      FROM bus_allocations ba
      JOIN students s ON ba.student_id = s.student_id
      JOIN buses b ON ba.bus_id = b.bus_id
    `;
    const params = [];
    const where = [];

    if (busId) {
      where.push('ba.bus_id = ?');
      params.push(busId);
    }

    if (status && ['Active', 'Cancelled'].includes(status)) {
      where.push('ba.status = ?');
      params.push(status);
    }

    if (search) {
      where.push('(s.name LIKE ? OR s.email LIKE ? OR b.bus_number LIKE ? OR b.route LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (where.length > 0) {
      sql += ` WHERE ${where.join(' AND ')}`;
    }

    sql += ' ORDER BY ba.allocation_id DESC';

    const allocations = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: allocations
    });
  } catch (error) {
    next(error);
  }
}

const { createAllocation, updateAllocation } = require('./allocationActions')('bus');

async function deleteAllocation(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT allocation_id FROM bus_allocations WHERE allocation_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Bus allocation with ID ${id} not found.`
      });
    }

    await db.query('DELETE FROM bus_allocations WHERE allocation_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Bus allocation ID ${id} removed successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllAllocations,
  createAllocation,
  updateAllocation,
  deleteAllocation
};
