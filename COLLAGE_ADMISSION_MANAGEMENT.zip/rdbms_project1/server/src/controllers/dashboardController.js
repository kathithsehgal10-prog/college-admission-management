const db = require('../config/db');

async function getStats(req, res, next) {
  try {
    const [
      studentsCount,
      departmentsCount,
      coursesCount,
      tutorsCount,
      totalAppsCount,
      pendingAppsCount,
      approvedAppsCount,
      rejectedAppsCount,
      totalHostelCapacity,
      activeHostelOccupancy,
      totalBusCapacity,
      activeBusOccupancy
    ] = await Promise.all([
      db.query('SELECT COUNT(*) AS total FROM students'),
      db.query('SELECT COUNT(*) AS total FROM departments'),
      db.query('SELECT COUNT(*) AS total FROM courses'),
      db.query('SELECT COUNT(*) AS total FROM tutors'),
      db.query('SELECT COUNT(*) AS total FROM applications'),
      db.query("SELECT COUNT(*) AS total FROM applications WHERE status IN ('Pending', 'SUBMITTED', 'UNDER_REVIEW', 'DOCUMENTS_REQUIRED')"),
      db.query("SELECT COUNT(*) AS total FROM applications WHERE status IN ('Approved', 'APPROVED')"),
      db.query("SELECT COUNT(*) AS total FROM applications WHERE status IN ('Rejected', 'REJECTED')"),
      db.query('SELECT COALESCE(SUM(number_of_seats), 0) AS total FROM hostels'),
      db.query("SELECT COUNT(*) AS total FROM hostel_allocations WHERE status = 'Active'"),
      db.query('SELECT COALESCE(SUM(capacity), 0) AS total FROM buses'),
      db.query("SELECT COUNT(*) AS total FROM bus_allocations WHERE status = 'Active'")
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalStudents: Number(studentsCount[0].total),
        totalDepartments: Number(departmentsCount[0].total),
        totalCourses: Number(coursesCount[0].total),
        totalTutors: Number(tutorsCount[0].total),
        totalApplications: Number(totalAppsCount[0].total),
        pendingApplications: Number(pendingAppsCount[0].total),
        approvedApplications: Number(approvedAppsCount[0].total),
        rejectedApplications: Number(rejectedAppsCount[0].total),
        hostel: {
          capacity: Number(totalHostelCapacity[0].total),
          occupied: Number(activeHostelOccupancy[0].total)
        },
        transportation: {
          capacity: Number(totalBusCapacity[0].total),
          occupied: Number(activeBusOccupancy[0].total)
        }
      }
    });
  } catch (error) {
    next(error);
  }
}

async function getCharts(req, res, next) {
  try {
    const [applicationStatusData, deptDistributionData, timelineData, hostelOccupancyData] = await Promise.all([
      // Status breakdown
      db.query(`
        SELECT status, COUNT(*) AS count
        FROM applications
        GROUP BY status
      `),
      // Students per department
      db.query(`
        SELECT 
          d.department_id,
          d.department_name,
          COALESCE(d.code, d.department_name) AS label,
          COUNT(s.student_id) AS student_count
        FROM departments d
        LEFT JOIN students s ON d.department_id = s.department_id
        GROUP BY d.department_id, d.department_name, d.code
        ORDER BY student_count DESC
      `),
      // Applications timeline
      db.query(`
        SELECT 
          DATE_FORMAT(application_date, '%Y-%m-%d') AS date,
          COUNT(*) AS count
        FROM applications
        GROUP BY application_date
        ORDER BY application_date ASC
        LIMIT 15
      `),
      // Hostel Occupancy
      db.query(`
        SELECT 
          h.name,
          h.number_of_seats AS capacity,
          COUNT(ha.allocation_id) AS occupied
        FROM hostels h
        LEFT JOIN hostel_allocations ha ON h.hostel_id = ha.hostel_id AND ha.status = 'Active'
        GROUP BY h.hostel_id, h.name, h.number_of_seats
      `)
    ]);

    res.status(200).json({
      success: true,
      data: {
        applicationStatus: applicationStatusData.map(r => ({
          status: r.status,
          count: Number(r.count)
        })),
        departmentDistribution: deptDistributionData.map(r => ({
          department_id: r.department_id,
          name: r.department_name,
          label: r.label,
          studentCount: Number(r.student_count)
        })),
        applicationTimeline: timelineData.map(r => ({
          date: r.date,
          applications: Number(r.count)
        })),
        hostelOccupancy: hostelOccupancyData.map(r => ({
          name: r.name,
          capacity: Number(r.capacity),
          occupied: Number(r.occupied)
        }))
      }
    });
  } catch (error) {
    next(error);
  }
}

async function getRecentActivity(req, res, next) {
  try {
    const [recentStudents, recentApplications] = await Promise.all([
      db.query(`
        SELECT 
          s.student_id, 
          s.name, 
          s.email, 
          s.marks, 
          s.created_at,
          d.department_name
        FROM students s
        LEFT JOIN departments d ON s.department_id = d.department_id
        ORDER BY s.created_at DESC, s.student_id DESC
        LIMIT 5
      `),
      db.query(`
        SELECT 
          a.application_id, 
          a.application_date, 
          a.status, 
          a.created_at,
          s.student_id,
          s.name AS student_name, 
          c.course_name, 
          d.department_name
        FROM applications a
        JOIN students s ON a.student_id = s.student_id
        JOIN courses c ON a.course_id = c.course_id
        JOIN departments d ON c.department_id = d.department_id
        ORDER BY a.created_at DESC, a.application_id DESC
        LIMIT 5
      `)
    ]);

    res.status(200).json({
      success: true,
      data: {
        recentStudents,
        recentApplications
      }
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getStats,
  getCharts,
  getRecentActivity
};
