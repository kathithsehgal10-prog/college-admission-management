const db = require('../config/db');

async function getSummaryReport(req, res, next) {
  try {
    const [deptStats, appStatusStats, courseStats, hostelStats, busStats, meritSummary] = await Promise.all([
      // Department statistics
      db.query(`
        SELECT 
          d.department_id,
          d.department_name,
          d.code,
          COUNT(DISTINCT c.course_id) AS total_courses,
          COUNT(DISTINCT t.tutor_id) AS total_tutors,
          COUNT(DISTINCT s.student_id) AS enrolled_students,
          ROUND(AVG(s.marks), 2) AS avg_marks
        FROM departments d
        LEFT JOIN courses c ON d.department_id = c.department_id
        LEFT JOIN tutors t ON d.department_id = t.department_id
        LEFT JOIN students s ON d.department_id = s.department_id
        GROUP BY d.department_id, d.department_name, d.code
        ORDER BY enrolled_students DESC
      `),
      // Application status breakdown
      db.query(`
        SELECT 
          status, 
          COUNT(*) AS total_count,
          ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM applications), 2) AS percentage
        FROM applications
        GROUP BY status
      `),
      // Course-wise applications and acceptance rate
      db.query(`
        SELECT 
          c.course_id,
          c.course_name,
          c.intake_capacity,
          d.department_name,
          COUNT(a.application_id) AS total_applicants,
          COUNT(CASE WHEN UPPER(a.status) = 'APPROVED' THEN 1 END) AS approved_count,
          COUNT(CASE WHEN UPPER(a.status) = 'REJECTED' THEN 1 END) AS rejected_count,
          COUNT(CASE WHEN UPPER(a.status) IN ('PENDING', 'SUBMITTED', 'UNDER_REVIEW') THEN 1 END) AS pending_count,
          ROUND(COUNT(CASE WHEN UPPER(a.status) = 'APPROVED' THEN 1 END) * 100.0 / NULLIF(COUNT(a.application_id), 0), 2) AS acceptance_rate_pct
        FROM courses c
        JOIN departments d ON c.department_id = d.department_id
        LEFT JOIN applications a ON c.course_id = a.course_id
        GROUP BY c.course_id, c.course_name, c.intake_capacity, d.department_name
        ORDER BY total_applicants DESC
      `),
      // Hostel Occupancy
      db.query(`
        SELECT 
          h.hostel_id,
          h.name AS hostel_name,
          h.type,
          h.number_of_seats AS total_capacity,
          COUNT(ha.allocation_id) AS occupied_seats,
          (h.number_of_seats - COUNT(ha.allocation_id)) AS available_seats,
          ROUND(COUNT(ha.allocation_id) * 100.0 / h.number_of_seats, 2) AS occupancy_rate_pct
        FROM hostels h
        LEFT JOIN hostel_allocations ha ON h.hostel_id = ha.hostel_id AND ha.status = 'Active'
        GROUP BY h.hostel_id, h.name, h.type, h.number_of_seats
        ORDER BY occupancy_rate_pct DESC
      `),
      // Bus Occupancy
      db.query(`
        SELECT 
          b.bus_id,
          b.bus_number,
          b.route,
          b.destination,
          b.capacity AS total_capacity,
          COUNT(ba.allocation_id) AS occupied_seats,
          (b.capacity - COUNT(ba.allocation_id)) AS available_seats,
          ROUND(COUNT(ba.allocation_id) * 100.0 / b.capacity, 2) AS occupancy_rate_pct
        FROM buses b
        LEFT JOIN bus_allocations ba ON b.bus_id = ba.bus_id AND ba.status = 'Active'
        GROUP BY b.bus_id, b.bus_number, b.route, b.destination, b.capacity
        ORDER BY occupancy_rate_pct DESC
      `),
      // Merit summary
      db.query(`
        SELECT 
          COUNT(student_id) AS total_students_scored,
          ROUND(AVG(marks), 2) AS overall_avg_marks,
          ROUND(MAX(marks), 2) AS highest_marks,
          ROUND(MIN(marks), 2) AS lowest_marks,
          ROUND(AVG(tenth_marks), 2) AS avg_tenth_marks,
          ROUND(AVG(twelfth_marks), 2) AS avg_twelfth_marks
        FROM students
      `)
    ]);

    res.status(200).json({
      success: true,
      data: {
        departmentStats: deptStats,
        applicationStatusStats: appStatusStats,
        courseStats: courseStats,
        hostelStats: hostelStats,
        busStats: busStats,
        meritSummary: meritSummary[0] || {}
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Helper to escape CSV field value safely
 */
function escapeCsv(val) {
  if (val === null || val === undefined) return '""';
  const value = String(val);
  const safe = typeof val === 'string' && /^[\s]*[=+@-]/.test(value) ? `\'${value}` : value;
  const str = safe.replace(/"/g, '""');
  return `"${str}"`;
}

/**
 * Export datasets to CSV
 */
async function exportCsv(req, res, next) {
  const { type } = req.params;

  try {
    let rows = [];
    let filename = `report_${type}_${Date.now()}.csv`;

    if (type === 'students') {
      rows = await db.query(`
        SELECT 
          s.student_id AS 'Student ID',
          s.name AS 'Name',
          s.gender AS 'Gender',
          s.age AS 'Age',
          s.email AS 'Email',
          s.phone AS 'Phone',
          s.rank AS 'Rank',
          s.marks AS 'Entrance Marks',
          s.tenth_marks AS '10th Marks',
          s.twelfth_marks AS '12th Marks',
          COALESCE(d.department_name, 'Unassigned') AS 'Department',
          DATE_FORMAT(s.created_at, '%Y-%m-%d') AS 'Registered On'
        FROM students s
        LEFT JOIN departments d ON s.department_id = d.department_id
        ORDER BY s.student_id ASC
      `);
      filename = 'students_export.csv';
    } else if (type === 'applications') {
      rows = await db.query(`
        SELECT 
          a.application_id AS 'Application ID',
          s.student_id AS 'Student ID',
          s.name AS 'Student Name',
          s.email AS 'Email',
          c.course_name AS 'Course Name',
          d.department_name AS 'Department',
          DATE_FORMAT(a.application_date, '%Y-%m-%d') AS 'Application Date',
          a.status AS 'Status',
          COALESCE(a.remarks, '') AS 'Remarks'
        FROM applications a
        JOIN students s ON a.student_id = s.student_id
        JOIN courses c ON a.course_id = c.course_id
        JOIN departments d ON c.department_id = d.department_id
        ORDER BY a.application_id ASC
      `);
      filename = 'applications_export.csv';
    } else if (type === 'courses') {
      rows = await db.query(`
        SELECT 
          c.course_id AS 'Course ID',
          c.course_name AS 'Course Name',
          COALESCE(c.course_code, '') AS 'Course Code',
          d.department_name AS 'Department',
          c.duration_years AS 'Duration (Years)',
          c.intake_capacity AS 'Capacity',
          COUNT(a.application_id) AS 'Total Applications',
          COUNT(CASE WHEN UPPER(a.status) = 'APPROVED' THEN 1 END) AS 'Approved'
        FROM courses c
        JOIN departments d ON c.department_id = d.department_id
        LEFT JOIN applications a ON c.course_id = a.course_id
        GROUP BY c.course_id, c.course_name, c.course_code, d.department_name, c.duration_years, c.intake_capacity
        ORDER BY c.course_id ASC
      `);
      filename = 'courses_export.csv';
    } else if (type === 'hostel-allocations') {
      rows = await db.query(`
        SELECT 
          ha.allocation_id AS 'Allocation ID',
          s.student_id AS 'Student ID',
          s.name AS 'Student Name',
          h.name AS 'Hostel Name',
          h.type AS 'Hostel Type',
          COALESCE(ha.room_number, 'N/A') AS 'Room Number',
          DATE_FORMAT(ha.allocation_date, '%Y-%m-%d') AS 'Date',
          ha.status AS 'Status'
        FROM hostel_allocations ha
        JOIN students s ON ha.student_id = s.student_id
        JOIN hostels h ON ha.hostel_id = h.hostel_id
        ORDER BY ha.allocation_id ASC
      `);
      filename = 'hostel_allocations.csv';
    } else if (type === 'bus-allocations') {
      rows = await db.query(`
        SELECT 
          ba.allocation_id AS 'Allocation ID',
          s.student_id AS 'Student ID',
          s.name AS 'Student Name',
          b.bus_number AS 'Bus Number',
          b.route AS 'Route',
          b.destination AS 'Destination',
          DATE_FORMAT(ba.allocation_date, '%Y-%m-%d') AS 'Date',
          ba.status AS 'Status'
        FROM bus_allocations ba
        JOIN students s ON ba.student_id = s.student_id
        JOIN buses b ON ba.bus_id = b.bus_id
        ORDER BY ba.allocation_id ASC
      `);
      filename = 'bus_allocations.csv';
    } else if (type === 'payments') {
      rows = await db.query(`
        SELECT 
          p.payment_id AS 'Payment ID',
          p.application_id AS 'Application ID',
          a.application_number AS 'Application Number',
          s.name AS 'Student Name',
          c.course_name AS 'Course Name',
          p.amount AS 'Amount (INR)',
          p.currency AS 'Currency',
          p.transaction_reference AS 'Transaction Reference',
          p.status AS 'Status',
          DATE_FORMAT(p.paid_at, '%Y-%m-%d %H:%i') AS 'Paid At'
        FROM payments p
        JOIN applications a ON p.application_id = a.application_id
        JOIN students s ON a.student_id = s.student_id
        JOIN courses c ON a.course_id = c.course_id
        ORDER BY p.payment_id ASC
      `);
      filename = 'payments_ledger.csv';
    } else {
      return res.status(400).json({
        success: false,
        message: `Unsupported export type "${type}". Allowed types: students, applications, courses, hostel-allocations, bus-allocations, payments.`
      });
    }

    if (rows.length === 0) {
      return res.status(200).send('No data available to export.');
    }

    const headers = Object.keys(rows[0]);
    const csvLines = [headers.map(escapeCsv).join(',')];

    for (const row of rows) {
      const line = headers.map(h => escapeCsv(row[h])).join(',');
      csvLines.push(line);
    }

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.status(200).send(csvLines.join('\n'));
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getSummaryReport,
  exportCsv
};
