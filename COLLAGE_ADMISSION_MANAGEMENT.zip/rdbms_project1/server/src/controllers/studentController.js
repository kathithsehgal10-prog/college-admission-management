const db = require('../config/db');

async function getAllStudents(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.max(1, Math.min(100, parseInt(req.query.limit, 10) || 10));
    const offset = (page - 1) * limit;

    const search = req.query.search ? req.query.search.trim() : '';
    const departmentId = req.query.department_id ? parseInt(req.query.department_id, 10) : null;
    const gender = req.query.gender ? req.query.gender.trim() : '';

    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push('(s.name LIKE ? OR s.email LIKE ? OR s.phone LIKE ? OR CAST(s.student_id AS CHAR) = ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, search);
    }

    if (departmentId) {
      whereClauses.push('s.department_id = ?');
      params.push(departmentId);
    }

    if (gender && ['Male', 'Female', 'Other'].includes(gender)) {
      whereClauses.push('s.gender = ?');
      params.push(gender);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    // Count query
    const countQuery = `SELECT COUNT(*) AS total FROM students s ${whereSql}`;
    const [countResult] = await db.query(countQuery, params);
    const total = Number(countResult.total);

    // Data query with department join
    const dataQuery = `
      SELECT 
        s.student_id,
        s.name,
        s.gender,
        s.age,
        s.address,
        s.phone,
        s.email,
        s.rank,
        s.marks,
        s.tenth_marks,
        s.twelfth_marks,
        s.department_id,
        d.department_name,
        d.code AS department_code,
        s.created_at,
        s.updated_at
      FROM students s
      LEFT JOIN departments d ON s.department_id = d.department_id
      ${whereSql}
      ORDER BY s.student_id DESC
      LIMIT ? OFFSET ?
    `;

    const dataParams = [...params, limit, offset];
    const students = await db.query(dataQuery, dataParams);

    res.status(200).json({
      success: true,
      data: students,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
}

async function getStudentById(req, res, next) {
  const { id } = req.params;

  try {
    const students = await db.query(
      `
      SELECT 
        s.*,
        d.department_name,
        d.code AS department_code
      FROM students s
      LEFT JOIN departments d ON s.department_id = d.department_id
      WHERE s.student_id = ?
      LIMIT 1
      `,
      [id]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Student with ID ${id} not found.`
      });
    }

    const student = students[0];

    // Fetch related applications
    const applications = await db.query(
      `
      SELECT 
        a.application_id,
        a.application_date,
        a.status,
        a.remarks,
        c.course_id,
        c.course_name,
        d.department_name
      FROM applications a
      JOIN courses c ON a.course_id = c.course_id
      LEFT JOIN departments d ON c.department_id = d.department_id
      WHERE a.student_id = ?
      ORDER BY a.application_date DESC
      `,
      [id]
    );

    // Fetch active hostel allocation
    const hostelAllocations = await db.query(
      `
      SELECT 
        ha.allocation_id,
        ha.room_number,
        ha.allocation_date,
        ha.status,
        h.hostel_id,
        h.name AS hostel_name,
        h.type AS hostel_type
      FROM hostel_allocations ha
      JOIN hostels h ON ha.hostel_id = h.hostel_id
      WHERE ha.student_id = ? AND ha.status = 'Active'
      LIMIT 1
      `,
      [id]
    );

    // Fetch active bus allocation
    const busAllocations = await db.query(
      `
      SELECT 
        ba.allocation_id,
        ba.allocation_date,
        ba.status,
        b.bus_id,
        b.bus_number,
        b.route,
        b.destination
      FROM bus_allocations ba
      JOIN buses b ON ba.bus_id = b.bus_id
      WHERE ba.student_id = ? AND ba.status = 'Active'
      LIMIT 1
      `,
      [id]
    );

    res.status(200).json({
      success: true,
      data: {
        ...student,
        applications,
        activeHostel: hostelAllocations[0] || null,
        activeBus: busAllocations[0] || null
      }
    });
  } catch (error) {
    next(error);
  }
}

async function createStudent(req, res, next) {
  const {
    name,
    gender,
    age,
    address,
    phone,
    email,
    rank,
    marks,
    tenth_marks,
    twelfth_marks,
    department_id
  } = req.body;

  try {
    const result = await db.query(
      `
      INSERT INTO students 
        (name, gender, age, address, phone, email, \`rank\`, marks, tenth_marks, twelfth_marks, department_id)
      VALUES 
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        name,
        gender,
        age,
        address,
        phone,
        email,
        rank || null,
        marks,
        tenth_marks,
        twelfth_marks,
        department_id || null
      ]
    );

    const newStudentId = result.insertId;

    res.status(201).json({
      success: true,
      message: 'Student registered successfully.',
      data: {
        student_id: newStudentId,
        ...req.body
      }
    });
  } catch (error) {
    next(error);
  }
}

async function updateStudent(req, res, next) {
  const { id } = req.params;

  try {
    const existing = await db.query('SELECT student_id FROM students WHERE student_id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Student with ID ${id} not found.`
      });
    }

    const updates = [];
    const params = [];

    const allowedFields = [
      'name', 'gender', 'age', 'address', 'phone', 'email',
      'rank', 'marks', 'tenth_marks', 'twelfth_marks', 'department_id'
    ];

    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        if (field === 'rank') {
          updates.push('`rank` = ?');
        } else {
          updates.push(`${field} = ?`);
        }
        params.push(req.body[field]);
      }
    }

    if (updates.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No updatable fields provided.'
      });
    }

    params.push(id);
    await db.query(`UPDATE students SET ${updates.join(', ')} WHERE student_id = ?`, params);

    const [updated] = await db.query(
      `
      SELECT s.*, d.department_name 
      FROM students s 
      LEFT JOIN departments d ON s.department_id = d.department_id 
      WHERE s.student_id = ?
      `,
      [id]
    );

    res.status(200).json({
      success: true,
      message: 'Student record updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteStudent(req, res, next) {
  const { id } = req.params;

  try {
    const existing = await db.query('SELECT student_id, name FROM students WHERE student_id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: `Student with ID ${id} not found.`
      });
    }

    await db.query('DELETE FROM students WHERE student_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Student "${existing[0].name}" (ID: ${id}) deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent
};
