const db = require('../config/db');

async function getAllHostels(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';

    let sql = `
      SELECT 
        h.hostel_id,
        h.name,
        h.type,
        h.address,
        h.number_of_seats AS total_capacity,
        COUNT(ha.allocation_id) AS occupied_seats,
        (h.number_of_seats - COUNT(ha.allocation_id)) AS available_seats,
        h.created_at,
        h.updated_at
      FROM hostels h
      LEFT JOIN hostel_allocations ha 
        ON h.hostel_id = ha.hostel_id AND ha.status = 'Active'
    `;
    const params = [];

    if (search) {
      sql += ' WHERE (h.name LIKE ? OR h.address LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' GROUP BY h.hostel_id, h.name, h.type, h.address, h.number_of_seats ORDER BY h.hostel_id ASC';

    const hostels = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: hostels.map(h => ({
        ...h,
        total_capacity: Number(h.total_capacity),
        occupied_seats: Number(h.occupied_seats),
        available_seats: Number(h.available_seats)
      }))
    });
  } catch (error) {
    next(error);
  }
}

async function getHostelById(req, res, next) {
  const { id } = req.params;

  try {
    const [hostel] = await db.query(
      `
      SELECT 
        h.hostel_id,
        h.name,
        h.type,
        h.address,
        h.number_of_seats AS total_capacity,
        COUNT(ha.allocation_id) AS occupied_seats,
        (h.number_of_seats - COUNT(ha.allocation_id)) AS available_seats
      FROM hostels h
      LEFT JOIN hostel_allocations ha 
        ON h.hostel_id = ha.hostel_id AND ha.status = 'Active'
      WHERE h.hostel_id = ?
      GROUP BY h.hostel_id
      LIMIT 1
      `,
      [id]
    );

    if (!hostel) {
      return res.status(404).json({
        success: false,
        message: `Hostel with ID ${id} not found.`
      });
    }

    // Active residents
    const residents = await db.query(
      `
      SELECT 
        ha.allocation_id,
        ha.room_number,
        ha.allocation_date,
        s.student_id,
        s.name AS student_name,
        s.gender,
        s.phone,
        s.email
      FROM hostel_allocations ha
      JOIN students s ON ha.student_id = s.student_id
      WHERE ha.hostel_id = ? AND ha.status = 'Active'
      ORDER BY ha.allocation_date DESC
      `,
      [id]
    );

    res.status(200).json({
      success: true,
      data: {
        ...hostel,
        total_capacity: Number(hostel.total_capacity),
        occupied_seats: Number(hostel.occupied_seats),
        available_seats: Number(hostel.available_seats),
        residents
      }
    });
  } catch (error) {
    next(error);
  }
}

async function createHostel(req, res, next) {
  const { name, type, address, number_of_seats } = req.body;

  try {
    const result = await db.query(
      'INSERT INTO hostels (name, type, address, number_of_seats) VALUES (?, ?, ?, ?)',
      [name, type || 'Co-ed', address, number_of_seats]
    );

    res.status(201).json({
      success: true,
      message: 'Hostel registered successfully.',
      data: {
        hostel_id: result.insertId,
        ...req.body
      }
    });
  } catch (error) {
    next(error);
  }
}

async function updateHostel(req, res, next) {
  const { id } = req.params;
  const { name, type, address, number_of_seats } = req.body;

  try {
    const updated = await db.withTransaction(async connection => {
    const txQuery = async (sql, params) => (await connection.query(sql, params.map(p => p === undefined ? null : p)))[0];
    const [existing] = await txQuery('SELECT hostel_id, number_of_seats FROM hostels WHERE hostel_id = ? FOR UPDATE', [id]);
    if (!existing) {
      throw Object.assign(new Error(`Hostel with ID ${id} not found.`), { statusCode: 404 });
    }

    // If capacity is being reduced, verify it doesn't fall below current occupancy
    if (number_of_seats !== undefined) {
      const [occ] = await txQuery(
        "SELECT COUNT(*) AS count FROM hostel_allocations WHERE hostel_id = ? AND status = 'Active'",
        [id]
      );
      const activeCount = Number(occ.count);
      if (number_of_seats < activeCount) {
        throw Object.assign(new Error(`Cannot reduce hostel capacity to ${number_of_seats} because there are currently ${activeCount} active resident allocations.`), { statusCode: 400 });
      }
    }

    await txQuery(
      `
      UPDATE hostels 
      SET name = COALESCE(?, name),
          type = COALESCE(?, type),
          address = COALESCE(?, address),
          number_of_seats = COALESCE(?, number_of_seats)
      WHERE hostel_id = ?
      `,
      [name, type, address, number_of_seats, id]
    );

    const [updated] = await txQuery('SELECT * FROM hostels WHERE hostel_id = ? FOR UPDATE', [id]);

    return updated;
    });

    res.status(200).json({
      success: true,
      message: 'Hostel updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteHostel(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT hostel_id, name FROM hostels WHERE hostel_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Hostel with ID ${id} not found.`
      });
    }

    const [allocations] = await db.query('SELECT COUNT(*) AS count FROM hostel_allocations WHERE hostel_id = ?', [id]);
    const allocCount = Number(allocations.count);

    if (allocCount > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete hostel "${existing.name}" because ${allocCount} historical or active student allocations are linked to it.`,
        code: 'FOREIGN_KEY_CONFLICT'
      });
    }

    await db.query('DELETE FROM hostels WHERE hostel_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Hostel "${existing.name}" (ID: ${id}) deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllHostels,
  getHostelById,
  createHostel,
  updateHostel,
  deleteHostel
};
