const db = require('../config/db');

const VIVA_QUERIES = [
  {
    id: 'join-4-table',
    category: 'Relational Joins',
    title: '4-Table INNER JOIN (Admissions Merit List)',
    description: 'Links Applications, Students, Courses, and Departments to list approved candidates with entrance scores and merit rank.',
    sql: `SELECT 
    s.student_id,
    s.name AS student_name,
    s.gender,
    s.marks AS entrance_score,
    s.rank AS merit_rank,
    c.course_name,
    d.department_name,
    a.application_date,
    a.status AS admission_status
FROM applications a
INNER JOIN students s ON a.student_id = s.student_id
INNER JOIN courses c ON a.course_id = c.course_id
INNER JOIN departments d ON c.department_id = d.department_id
WHERE a.status = 'APPROVED'
ORDER BY s.marks DESC;`
  },
  {
    id: 'join-left-aggregation',
    category: 'Relational Joins',
    title: 'LEFT JOIN with Multi-Table Aggregation',
    description: 'Computes total courses, faculty mentors, and enrolled students per department, handling nulls with COALESCE.',
    sql: `SELECT 
    d.department_id,
    d.department_name,
    COUNT(DISTINCT c.course_id) AS total_courses,
    COUNT(DISTINCT t.tutor_id) AS total_mentors,
    COUNT(DISTINCT s.student_id) AS enrolled_students,
    COALESCE(ROUND(AVG(s.marks), 2), 0.00) AS avg_marks
FROM departments d
LEFT JOIN courses c ON d.department_id = c.department_id
LEFT JOIN tutors t ON d.department_id = t.department_id
LEFT JOIN students s ON d.department_id = s.department_id
GROUP BY d.department_id, d.department_name
ORDER BY enrolled_students DESC;`
  },
  {
    id: 'subquery-not-in',
    category: 'Subqueries',
    title: 'Subquery with NOT IN (Unenrolled Applicants)',
    description: 'Finds all registered student dossiers that have not yet submitted any degree application.',
    sql: `SELECT 
    student_id, 
    name, 
    email, 
    phone, 
    marks, 
    \`rank\`
FROM students
WHERE student_id NOT IN (
    SELECT DISTINCT student_id 
    FROM applications
);`
  },
  {
    id: 'subquery-correlated-exists',
    category: 'Subqueries',
    title: 'Correlated Subquery with EXISTS (Pending Approvals)',
    description: 'Identifies degree courses that have at least one application awaiting administrative verification.',
    sql: `SELECT 
    c.course_id,
    c.course_name,
    c.course_code,
    c.intake_capacity
FROM courses c
WHERE EXISTS (
    SELECT 1 
    FROM applications a 
    WHERE a.course_id = c.course_id AND a.status = 'Pending'
);`
  },
  {
    id: 'subquery-capacity',
    category: 'Subqueries',
    title: 'Correlated Capacity Calculation (Available Beds)',
    description: 'Dynamically computes available hostel capacity by subtracting active allocations from total seats.',
    sql: `SELECT 
    h.hostel_id,
    h.name AS hostel_name,
    h.type,
    h.number_of_seats AS total_capacity,
    (
        SELECT COUNT(*) 
        FROM hostel_allocations ha 
        WHERE ha.hostel_id = h.hostel_id AND ha.status = 'Active'
    ) AS occupied_seats,
    (
        h.number_of_seats - (
            SELECT COUNT(*) 
            FROM hostel_allocations ha 
            WHERE ha.hostel_id = h.hostel_id AND ha.status = 'Active'
        )
    ) AS available_beds
FROM hostels h;`
  },
  {
    id: 'group-by-having',
    category: 'Aggregations',
    title: 'GROUP BY with HAVING Clause (Top Performing Depts)',
    description: 'Filters faculties where the average entrance examination score of enrolled students exceeds 85.00.',
    sql: `SELECT 
    d.department_name,
    COUNT(s.student_id) AS total_students,
    ROUND(AVG(s.marks), 2) AS avg_marks,
    MAX(s.marks) AS top_score,
    MIN(s.marks) AS lowest_score
FROM departments d
JOIN students s ON d.department_id = s.department_id
GROUP BY d.department_id, d.department_name
HAVING AVG(s.marks) > 85.00
ORDER BY avg_marks DESC;`
  },
  {
    id: 'set-union',
    category: 'Set Operations',
    title: 'Set Operation: UNION (Campus Contact Directory)',
    description: 'Consolidates applicants, faculty tutors, and system admins into a single unified directory.',
    sql: `SELECT student_id AS id, name AS contact_name, email, 'Student' AS contact_role FROM students
UNION
SELECT tutor_id AS id, tutor_name AS contact_name, email, 'Faculty Tutor' AS contact_role FROM tutors
UNION
SELECT admin_id AS id, admin_name AS contact_name, email, 'System Admin' AS contact_role FROM admins
ORDER BY contact_role, contact_name;`
  },
  {
    id: 'views-department-stats',
    category: 'Database Views',
    title: 'View: view_department_stats',
    description: 'Queries the relational database view compiling live departmental statistics.',
    sql: `SELECT * FROM view_department_stats ORDER BY total_students DESC;`
  },
  {
    id: 'views-hostel-occupancy',
    category: 'Database Views',
    title: 'View: view_hostel_occupancy',
    description: 'Queries the real-time residential bed capacity and occupancy calculation view.',
    sql: `SELECT * FROM view_hostel_occupancy;`
  },
  {
    id: 'views-bus-occupancy',
    category: 'Database Views',
    title: 'View: view_bus_occupancy',
    description: 'Queries the real-time transportation seat capacity and pass allocation view.',
    sql: `SELECT * FROM view_bus_occupancy;`
  },
  {
    id: 'function-merit-formula',
    category: 'Functions & Formulae',
    title: 'Merit Score Function fn_calculate_merit_score',
    description: 'Evaluates composite merit formula: 50% Entrance + 25% 10th Board + 25% 12th Board.',
    sql: `SELECT 
    student_id,
    name,
    marks AS entrance,
    tenth_marks AS board_10th,
    twelfth_marks AS board_12th,
    fn_calculate_merit_score(marks, tenth_marks, twelfth_marks) AS composite_merit
FROM students
ORDER BY composite_merit DESC;`
  },
  {
    id: 'audit-logs-view',
    category: 'Auditing & Security',
    title: 'Audit Logs Table (System State Transition History)',
    description: 'Inspects relational audit logs recording updates to student dossiers and application decisions.',
    sql: `SELECT * FROM audit_logs ORDER BY log_id DESC;`
  }
];

async function getVivaQueries(req, res) {
  res.status(200).json({
    success: true,
    data: VIVA_QUERIES
  });
}

async function executeVivaQuery(req, res, next) {
  try {
    const { queryId, sql: customSql } = req.body;

    let targetSql = '';
    if (queryId) {
      const match = VIVA_QUERIES.find(q => q.id === queryId);
      if (!match) {
        return res.status(404).json({ success: false, message: `Query with ID "${queryId}" not found.` });
      }
      targetSql = match.sql;
    } else if (customSql && typeof customSql === 'string') {
      const statement = customSql.trim().replace(/;$/, '');
      if (!/^(SELECT\b|WITH\b|EXPLAIN\s+SELECT\b)/i.test(statement) ||
          /;|--|#|\/\*|\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE|REPLACE|GRANT|REVOKE|CALL|SET|PRAGMA|INTO|SLEEP|BENCHMARK|LOAD_FILE|GET_LOCK|RELEASE_LOCK)\b/i.test(statement)) {
        return res.status(400).json({ success: false,
          message: 'Use one read-only SELECT, WITH, or EXPLAIN SELECT statement without comments or side effects.' });
      }
      targetSql = customSql.trim();
    } else {
      return res.status(400).json({ success: false, message: 'Please provide either queryId or sql.' });
    }

    const start = process.hrtime.bigint();
    const rows = await db.readOnlyQuery(targetSql);
    const end = process.hrtime.bigint();
    const executionTimeMs = Number((end - start) / 1000000n);

    const rowList = Array.isArray(rows) ? rows : [rows];
    const columns = rowList.length > 0 && rowList[0] ? Object.keys(rowList[0]) : [];

    res.status(200).json({
      success: true,
      data: {
        sql: targetSql,
        columns,
        rows: rowList,
        rowCount: rowList.length,
        executionTimeMs
      }
    });
  } catch (error) {
    next(error);
  }
}

async function getSchemaMetadata(req, res, next) {
  try {
    const tables = [
      { name: 'users', primaryKey: 'user_id', rowCountQuery: 'SELECT COUNT(*) AS c FROM users' },
      { name: 'admission_cycles', primaryKey: 'cycle_id', rowCountQuery: 'SELECT COUNT(*) AS c FROM admission_cycles' },
      { name: 'application_status_history', primaryKey: 'history_id', rowCountQuery: 'SELECT COUNT(*) AS c FROM application_status_history' },
      { name: 'announcements', primaryKey: 'announcement_id', rowCountQuery: 'SELECT COUNT(*) AS c FROM announcements' },
      { name: 'payments', primaryKey: 'payment_id', rowCountQuery: 'SELECT COUNT(*) AS c FROM payments' },
      { name: 'departments', description: 'Academic faculties (3NF/BCNF)', primaryKey: 'department_id', rowCountQuery: 'SELECT COUNT(*) as c FROM departments' },
      { name: 'courses', description: 'Degree programs with intake capacities', primaryKey: 'course_id', foreignKey: 'department_id -> departments', rowCountQuery: 'SELECT COUNT(*) as c FROM courses' },
      { name: 'tutors', description: 'Faculty mentorship counselors', primaryKey: 'tutor_id', foreignKey: 'department_id -> departments', rowCountQuery: 'SELECT COUNT(*) as c FROM tutors' },
      { name: 'students', description: 'Applicant dossiers with merit scores', primaryKey: 'student_id', foreignKey: 'department_id -> departments (SET NULL)', rowCountQuery: 'SELECT COUNT(*) as c FROM students' },
      { name: 'admins', description: 'Admin authentication (JWT + Bcrypt)', primaryKey: 'admin_id', rowCountQuery: 'SELECT COUNT(*) as c FROM admins' },
      { name: 'hostels', description: 'Residential living facilities', primaryKey: 'hostel_id', rowCountQuery: 'SELECT COUNT(*) as c FROM hostels' },
      { name: 'buses', description: 'Transit vehicle routes and fleets', primaryKey: 'bus_id', rowCountQuery: 'SELECT COUNT(*) as c FROM buses' },
      { name: 'applications', description: 'Many-to-Many bridge (Students <-> Courses)', primaryKey: 'application_id', foreignKey: 'student_id -> students, course_id -> courses', rowCountQuery: 'SELECT COUNT(*) as c FROM applications' },
      { name: 'hostel_allocations', description: 'Bed assignment pass tracking', primaryKey: 'allocation_id', foreignKey: 'student_id -> students, hostel_id -> hostels', rowCountQuery: 'SELECT COUNT(*) as c FROM hostel_allocations' },
      { name: 'bus_allocations', description: 'Transit pass assignment tracking', primaryKey: 'allocation_id', foreignKey: 'student_id -> students, bus_id -> buses', rowCountQuery: 'SELECT COUNT(*) as c FROM bus_allocations' },
      { name: 'audit_logs', description: 'Relational state transition audit history', primaryKey: 'log_id', rowCountQuery: 'SELECT COUNT(*) as c FROM audit_logs' }
    ];

    const counts = await Promise.all(tables.map(async t => {
      const rows = await db.query(t.rowCountQuery);
      return Number(rows[0].c);
    }));
    const [viewRows, routineRows, triggerRows] = await Promise.all([
      db.query('SELECT TABLE_NAME AS name FROM information_schema.VIEWS WHERE TABLE_SCHEMA = DATABASE()'),
      db.query('SELECT ROUTINE_NAME AS name, ROUTINE_TYPE AS type FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = DATABASE()'),
      db.query('SELECT TRIGGER_NAME AS name FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE()')
    ]);

    const schemaWithCounts = tables.map((t, i) => ({
      ...t,
      rowCount: counts[i]
    }));

    res.status(200).json({
      success: true,
      data: {
        databaseEngine: 'MySQL (InnoDB)',
        tables: schemaWithCounts,
        views: viewRows.map(row => row.name),
        storedProcedures: routineRows.filter(row => row.type === 'PROCEDURE').map(row => row.name),
        storedFunctions: routineRows.filter(row => row.type === 'FUNCTION').map(row => row.name),
        triggers: triggerRows.map(row => row.name)
      }
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getVivaQueries,
  executeVivaQuery,
  getSchemaMetadata
};
