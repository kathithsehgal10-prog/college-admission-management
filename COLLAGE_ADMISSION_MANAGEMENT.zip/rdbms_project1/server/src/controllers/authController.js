const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const config = require('../config/env');

async function login(req, res, next) {
  const { email, password } = req.body;

  try {
    let rows = await db.query(
      'SELECT admin_id, admin_name, email, password_hash, role FROM admins WHERE email = ? LIMIT 1',
      [email]
    );

    if (rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password credentials.'
      });
    }

    const admin = rows[0];
    const isMatch = await bcrypt.compare(password, admin.password_hash);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password credentials.'
      });
    }

    await db.query('UPDATE admins SET last_login = NOW() WHERE admin_id = ?', [admin.admin_id]);

    const token = jwt.sign(
      {
        admin_id: admin.admin_id,
        admin_name: admin.admin_name,
        email: admin.email,
        role: admin.role
      },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    res.status(200).json({
      success: true,
      message: 'Authentication successful.',
      data: {
        token,
        admin: {
          admin_id: admin.admin_id,
          admin_name: admin.admin_name,
          email: admin.email,
          role: admin.role
        }
      }
    });
  } catch (error) {
    next(error);
  }
}

async function logout(req, res) {
  res.status(200).json({
    success: true,
    message: 'Logged out successfully.'
  });
}

async function getProfile(req, res, next) {
  try {
    let rows = await db.query(
      'SELECT admin_id, admin_name, email, role, last_login, created_at FROM admins WHERE admin_id = ? LIMIT 1',
      [req.user.admin_id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Administrator account profile not found.'
      });
    }

    res.status(200).json({
      success: true,
      data: rows[0]
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  login,
  logout,
  getProfile,
  getMe: getProfile
};
