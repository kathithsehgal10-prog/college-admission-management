const db = require('../config/db');
const { randomUUID } = require('node:crypto');
const { fail, checkAdmission, syncDepartment } = require('./businessRules');

async function getAllApplications(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.max(1, Math.min(100, parseInt(req.query.limit, 10) || 10));
    const offset = (page - 1) * limit;

    const search = req.query.search ? req.query.search.trim() : '';
    const status = req.query.status ? req.query.status.trim() : '';
    const courseId = req.query.course_id ? parseInt(req.query.course_id, 10) : null;
    const departmentId = req.query.department_id ? parseInt(req.query.department_id, 10) : null;
    const cycleId = req.query.cycle_id ? parseInt(req.query.cycle_id, 10) : null;

    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push('(s.name LIKE ? OR s.email LIKE ? OR a.application_number LIKE ? OR CAST(a.application_id AS CHAR) = ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, search);
    }

    if (status) {
      whereClauses.push('a.status = ?');
      params.push(status);
    }

    if (courseId) {
      whereClauses.push('a.course_id = ?');
      params.push(courseId);
    }

    if (departmentId) {
      whereClauses.push('c.department_id = ?');
      params.push(departmentId);
    }

    if (cycleId) {
      whereClauses.push('a.cycle_id = ?');
      params.push(cycleId);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    // Total count
    const [countResult] = await db.query(
      `
      SELECT COUNT(*) AS total
      FROM applications a
      JOIN students s ON a.student_id = s.student_id
      JOIN courses c ON a.course_id = c.course_id
      ${whereSql}
      `,
      params
    );
    const total = Number(countResult.total);

    // Data query
    const dataSql = `
      SELECT 
        a.application_id,
        a.application_number,
        a.student_id,
        s.name AS student_name,
        s.email AS student_email,
        s.phone AS student_phone,
        s.marks AS student_marks,
        s.rank AS student_rank,
        a.course_id,
        c.course_name,
        c.course_code,
        d.department_id,
        d.department_name,
        a.cycle_id,
        ac.cycle_name,
        a.application_date,
        a.status,
        a.marks_obtained,
        a.maximum_marks,
        a.remarks,
        a.admin_remarks,
        a.created_at,
        a.updated_at
      FROM applications a
      JOIN students s ON a.student_id = s.student_id
      JOIN courses c ON a.course_id = c.course_id
      JOIN departments d ON c.department_id = d.department_id
      LEFT JOIN admission_cycles ac ON a.cycle_id = ac.cycle_id
      ${whereSql}
      ORDER BY a.application_id DESC
      LIMIT ? OFFSET ?
    `;

    const dataParams = [...params, limit, offset];
    const applications = await db.query(dataSql, dataParams);

    res.status(200).json({
      success: true,
      data: applications,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
}

async function getApplicationById(req, res, next) {
  const { id } = req.params;

  try {
    const [application] = await db.query(
      `
      SELECT 
        a.application_id,
        a.application_number,
        a.student_id,
        s.name AS student_name,
        s.email AS student_email,
        s.phone AS student_phone,
        s.gender AS student_gender,
        s.age AS student_age,
        s.address AS student_address,
        s.marks AS entrance_marks,
        s.tenth_marks,
        s.twelfth_marks,
        s.rank AS student_rank,
        a.course_id,
        c.course_name,
        c.course_code,
        c.duration_years,
        c.annual_fee,
        d.department_id,
        d.department_name,
        a.cycle_id,
        ac.cycle_name,
        a.application_date,
        a.status,
        a.marks_obtained,
        a.maximum_marks,
        a.remarks,
        a.admin_remarks,
        a.reviewed_by,
        a.reviewed_at,
        a.created_at,
        a.updated_at
      FROM applications a
      JOIN students s ON a.student_id = s.student_id
      JOIN courses c ON a.course_id = c.course_id
      JOIN departments d ON c.department_id = d.department_id
      LEFT JOIN admission_cycles ac ON a.cycle_id = ac.cycle_id
      WHERE a.application_id = ?
      LIMIT 1
      `,
      [id]
    );

    if (!application) {
      return res.status(404).json({
        success: false,
        message: `Application with ID ${id} not found.`
      });
    }

    // Also fetch status history timeline
    const history = await db.query(
      `SELECT history_id, old_status, new_status, changed_by, remarks, changed_at 
       FROM application_status_history 
       WHERE application_id = ? 
       ORDER BY changed_at DESC`,
      [id]
    );

    // Also fetch payment ledger records
    const payments = await db.query(
      `SELECT payment_id, amount, currency, transaction_reference, status, paid_at 
       FROM payments 
       WHERE application_id = ? 
       ORDER BY paid_at DESC`,
      [id]
    );

    res.status(200).json({
      success: true,
      data: {
        ...application,
        history,
        payments
      }
    });
  } catch (error) {
    next(error);
  }
}

async function getApplicationHistory(req, res, next) {
  const { id } = req.params;
  try {
    const history = await db.query(
      `SELECT history_id, old_status, new_status, changed_by, remarks, changed_at 
       FROM application_status_history 
       WHERE application_id = ? 
       ORDER BY changed_at DESC`,
      [id]
    );
    res.status(200).json({
      success: true,
      data: history
    });
  } catch (error) {
    next(error);
  }
}

async function createApplication(req, res, next) {
  const { student_id, course_id, application_date, status = 'SUBMITTED', remarks, cycle_id, marks_obtained, maximum_marks, admin_remarks } = req.body;
  try {
    const result = await db.withTransaction(async connection => {
      const [students] = await connection.query('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE', [student_id]);
      if (!students.length) fail(404, 'Student not found.');
      const [courses] = await connection.query('SELECT course_id FROM courses WHERE course_id = ?', [course_id]);
      if (!courses.length) fail(404, 'Course not found.');
      if (status.toUpperCase() === 'APPROVED') await checkAdmission(connection, student_id, course_id);
      const [duplicate] = await connection.query('SELECT application_id FROM applications WHERE student_id = ? AND course_id = ? AND COALESCE(cycle_id, 0) = COALESCE(?, 0)', [student_id, course_id, cycle_id ?? null]);
      if (duplicate.length) fail(409, 'Student already applied to this course in the selected admission cycle.');
      if (cycle_id) {
        const [cycles] = await connection.query('SELECT cycle_id FROM admission_cycles WHERE cycle_id = ?', [cycle_id]);
        if (!cycles.length) fail(404, 'Admission cycle not found.');
      }
      const appNumber = `APP-${new Date().getFullYear()}-${randomUUID().slice(0, 8).toUpperCase()}`;
      const [insert] = await connection.query(`INSERT INTO applications
        (application_number, student_id, course_id, cycle_id, application_date, status, marks_obtained, maximum_marks, remarks, admin_remarks)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [appNumber, student_id, course_id, cycle_id ?? null, application_date || new Date().toISOString().slice(0, 10), status,
          marks_obtained ?? null, maximum_marks ?? 100, remarks ?? null, admin_remarks ?? null]);
      await connection.query('INSERT INTO application_status_history (application_id, old_status, new_status, changed_by, remarks) VALUES (?, ?, ?, ?, ?)',
        [insert.insertId, null, status, req.user?.email || 'admin', remarks ?? 'Initial application creation.']);
      if (status.toUpperCase() === 'APPROVED') await syncDepartment(connection, student_id);
      insert.application_number = appNumber;
      return insert;
    });
    res.status(201).json({ success: true, message: 'Admission application submitted successfully.', data: { ...req.body, application_id: result.insertId, application_number: result.application_number } });
  } catch (error) { next(error); }
}
async function updateApplicationStatus(req, res, next) {
  const { id } = req.params;
  const { status, remarks, admin_remarks } = req.body;
  try {
    await db.withTransaction(async connection => {
      const [lookup] = await connection.query('SELECT student_id FROM applications WHERE application_id = ?', [id]);
      if (!lookup.length) fail(404, 'Application not found.');
      await connection.query('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE', [lookup[0].student_id]);
      const [apps] = await connection.query('SELECT application_id, student_id, course_id, status FROM applications WHERE application_id = ? FOR UPDATE', [id]);
      if (!apps.length) fail(404, 'Application not found.');
      const app = apps[0];
      if (status.toUpperCase() === 'APPROVED') await checkAdmission(connection, app.student_id, app.course_id, id);
      await connection.query('UPDATE applications SET status = ?, remarks = COALESCE(?, remarks), admin_remarks = COALESCE(?, admin_remarks), reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE application_id = ?', [status, remarks ?? null, admin_remarks ?? null, req.user?.admin_id ?? null, id]);
      if (app.status !== status) await connection.query('INSERT INTO application_status_history (application_id, old_status, new_status, changed_by, remarks) VALUES (?, ?, ?, ?, ?)', [id, app.status, status, req.user?.email || 'admin', admin_remarks ?? remarks ?? 'Status updated']);
      if (status.toUpperCase() === 'APPROVED' || app.status.toUpperCase() === 'APPROVED') await syncDepartment(connection, app.student_id);
    });
    res.status(200).json({ success: true, message: `Application status changed to "${status}".`, data: { application_id: Number(id), status, remarks } });
  } catch (error) { next(error); }
}
async function deleteApplication(req, res, next) {
  const { id } = req.params;
  try {
    await db.withTransaction(async connection => {
      const [lookup] = await connection.query('SELECT student_id FROM applications WHERE application_id = ?', [id]);
      if (!lookup.length) fail(404, 'Application not found.');
      await connection.query('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE', [lookup[0].student_id]);
      const [apps] = await connection.query('SELECT student_id, status FROM applications WHERE application_id = ? FOR UPDATE', [id]);
      if (!apps.length) fail(404, 'Application not found.');
      await connection.query('DELETE FROM applications WHERE application_id = ?', [id]);
      if (apps[0].status.toUpperCase() === 'APPROVED') await syncDepartment(connection, apps[0].student_id);
    });
    res.status(200).json({ success: true, message: `Application ID ${id} deleted successfully.` });
  } catch (error) { next(error); }
}

module.exports = {
  getAllApplications,
  getApplicationById,
  getApplicationHistory,
  createApplication,
  updateApplicationStatus,
  deleteApplication
};
