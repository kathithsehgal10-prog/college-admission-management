const db = require('../config/db');
const { fail } = require('./businessRules');
module.exports = function allocationActions(kind) {
  const hostel = kind === 'hostel';
  const table = hostel ? 'hostel_allocations' : 'bus_allocations';
  const resources = hostel ? 'hostels' : 'buses';
  const key = hostel ? 'hostel_id' : 'bus_id';
  const capacity = hostel ? 'number_of_seats' : 'capacity';
  async function check(connection, studentId, resourceId, excludeId = 0) {
    const [resource] = await connection.query(`SELECT ${key}, ${capacity} FROM ${resources} WHERE ${key} = ? FOR UPDATE`, [resourceId]);
    if (!resource.length) fail(404, `${kind} not found.`);
    const [other] = await connection.query(`SELECT allocation_id FROM ${table} WHERE student_id = ? AND status = 'Active' AND allocation_id <> ?`, [studentId, excludeId]);
    if (other.length) fail(409, `Student already has an active ${kind} allocation.`);
    const [count] = await connection.query(`SELECT COUNT(*) AS total FROM ${table} WHERE ${key} = ? AND status = 'Active' AND allocation_id <> ?`, [resourceId, excludeId]);
    if (Number(count[0].total) >= resource[0][capacity]) fail(409, `${kind} capacity is full.`);
  }
  async function createAllocation(req, res, next) {
    const { student_id, status = 'Active', allocation_date, room_number } = req.body;
    try {
      const result = await db.withTransaction(async connection => {
        const [students] = await connection.query('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE', [student_id]);
        if (!students.length) fail(404, 'Student not found.');
        if (status === 'Active') await check(connection, student_id, req.body[key]);
        const fields = hostel ? ', room_number' : '';
        const values = [student_id, req.body[key], allocation_date || new Date().toISOString().slice(0, 10), status];
        if (hostel) values.push(room_number ?? null);
        const [insert] = await connection.query(`INSERT INTO ${table} (student_id, ${key}, allocation_date, status${fields}) VALUES (${values.map(() => '?').join(', ')})`, values);
        return insert;
      });
      res.status(201).json({ success: true, message: `${kind} allocation created successfully.`, data: { ...req.body, allocation_id: result.insertId } });
    } catch (error) { next(error); }
  }
  async function updateAllocation(req, res, next) {
    const { id } = req.params;
    try {
      await db.withTransaction(async connection => {
        const [lookup] = await connection.query(`SELECT student_id FROM ${table} WHERE allocation_id = ?`, [id]);
        if (!lookup.length) fail(404, 'Allocation not found.');
        await connection.query('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE', [lookup[0].student_id]);
        const [rows] = await connection.query(`SELECT * FROM ${table} WHERE allocation_id = ? FOR UPDATE`, [id]);
        if (!rows.length) fail(404, 'Allocation not found.');
        const row = rows[0];
        const status = req.body.status ?? row.status;
        if (status === 'Active') await check(connection, row.student_id, row[key], id);
        const fields = hostel ? ', room_number = COALESCE(?, room_number)' : '';
        const values = [status];
        if (hostel) values.push(req.body.room_number ?? null);
        values.push(id);
        await connection.query(`UPDATE ${table} SET status = ?${fields} WHERE allocation_id = ?`, values);
      });
      res.status(200).json({ success: true, message: `${kind} allocation updated successfully.` });
    } catch (error) { next(error); }
  }
  return { createAllocation, updateAllocation };
};
