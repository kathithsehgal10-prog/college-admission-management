const db = require('../config/db');
async function getHealth(req, res, next) {
  try {
    const state = await db.testConnection();
    res.status(200).json({
      success: true, status: state.connected ? 'healthy' : 'degraded',
      timestamp: new Date().toISOString(), service: 'College Admission Management System API',
      database: { connected: state.connected, dialect: state.dialect, mode: state.mode, version: state.serverVersion,
        message: state.message, name: state.databaseName, host: state.host,
        port: state.port, lastChecked: state.lastChecked }
    });
  } catch (error) { next(error); }
}
module.exports = { getHealth };
