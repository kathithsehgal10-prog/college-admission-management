const db = require('../config/db');

async function getAllAllocations(req, res, next) {
  try {
    const hostelId = req.query.hostel_id ? parseInt(req.query.hostel_id, 10) : null;
    const status = req.query.status ? req.query.status.trim() : '';
    const search = req.query.search ? req.query.search.trim() : '';

    let sql = `
      SELECT 
        ha.allocation_id,
        ha.student_id,
        s.name AS student_name,
        s.email AS student_email,
        s.phone AS student_phone,
        s.gender AS student_gender,
        ha.hostel_id,
        h.name AS hostel_name,
        h.type AS hostel_type,
        ha.room_number,
        ha.allocation_date,
        ha.status,
        ha.created_at,
        ha.updated_at
      FROM hostel_allocations ha
      JOIN students s ON ha.student_id = s.student_id
      JOIN hostels h ON ha.hostel_id = h.hostel_id
    `;
    const params = [];
    const where = [];

    if (hostelId) {
      where.push('ha.hostel_id = ?');
      params.push(hostelId);
    }

    if (status && ['Active', 'Vacated'].includes(status)) {
      where.push('ha.status = ?');
      params.push(status);
    }

    if (search) {
      where.push('(s.name LIKE ? OR s.email LIKE ? OR ha.room_number LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (where.length > 0) {
      sql += ` WHERE ${where.join(' AND ')}`;
    }

    sql += ' ORDER BY ha.allocation_id DESC';

    const allocations = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: allocations
    });
  } catch (error) {
    next(error);
  }
}

const { createAllocation, updateAllocation } = require('./allocationActions')('hostel');

async function deleteAllocation(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT allocation_id FROM hostel_allocations WHERE allocation_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Hostel allocation with ID ${id} not found.`
      });
    }

    await db.query('DELETE FROM hostel_allocations WHERE allocation_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Hostel allocation ID ${id} removed successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllAllocations,
  createAllocation,
  updateAllocation,
  deleteAllocation
};
