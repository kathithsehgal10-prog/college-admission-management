const db = require('../config/db');
const { z } = require('zod');
const paymentSchema = z.object({
  application_id: z.coerce.number().int().positive(),
  amount: z.coerce.number().positive().max(99999999.99),
  transaction_reference: z.string().trim().min(1).max(100)
});

async function getAllPayments(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';

    const whereClauses = [];
    const params = [];

    if (search) {
      whereClauses.push('(p.transaction_reference LIKE ? OR s.name LIKE ? OR s.email LIKE ? OR a.application_number LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    const sql = `
      SELECT 
        p.payment_id,
        p.application_id,
        a.application_number,
        s.name AS student_name,
        s.email AS student_email,
        c.course_name,
        p.amount,
        p.currency,
        p.transaction_reference,
        p.status,
        p.paid_at,
        p.created_at
      FROM payments p
      JOIN applications a ON p.application_id = a.application_id
      JOIN students s ON a.student_id = s.student_id
      JOIN courses c ON a.course_id = c.course_id
      ${whereSql}
      ORDER BY p.paid_at DESC
    `;

    const payments = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: payments
    });
  } catch (error) {
    next(error);
  }
}

async function recordPayment(req, res, next) {
  try {
    const validation = paymentSchema.safeParse(req.body);
    if (!validation.success) return res.status(400).json({ success: false, message: 'Provide a valid application ID, positive payment amount, and transaction reference.' });
    const { application_id, amount, transaction_reference } = validation.data;

    if (!application_id || !amount || !transaction_reference) {
      return res.status(400).json({ success: false, message: 'application_id, amount, and transaction_reference are required.' });
    }

    const [app] = await db.query('SELECT application_id FROM applications WHERE application_id = ?', [application_id]);
    if (!app) {
      return res.status(404).json({ success: false, message: `Application #${application_id} not found.` });
    }

    const existingRef = await db.query('SELECT payment_id FROM payments WHERE transaction_reference = ?', [transaction_reference]);
    if (existingRef.length > 0) {
      return res.status(409).json({ success: false, message: 'Transaction reference already recorded.' });
    }

    const result = await db.query(
      'INSERT INTO payments (application_id, amount, currency, transaction_reference, status) VALUES (?, ?, ?, ?, ?)',
      [application_id, amount, 'INR', transaction_reference, 'SUCCESS']
    );

    const [newPayment] = await db.query('SELECT * FROM payments WHERE payment_id = ?', [result.insertId]);

    res.status(201).json({
      success: true,
      message: 'Payment fee record created successfully (Administrative ledger).',
      data: newPayment
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllPayments,
  recordPayment
};
