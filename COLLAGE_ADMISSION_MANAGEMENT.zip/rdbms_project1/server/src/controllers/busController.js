const db = require('../config/db');

async function getAllBuses(req, res, next) {
  try {
    const search = req.query.search ? req.query.search.trim() : '';

    let sql = `
      SELECT 
        b.bus_id,
        b.bus_number,
        b.route,
        b.destination,
        b.capacity AS total_capacity,
        COUNT(ba.allocation_id) AS occupied_seats,
        (b.capacity - COUNT(ba.allocation_id)) AS available_seats,
        b.created_at,
        b.updated_at
      FROM buses b
      LEFT JOIN bus_allocations ba 
        ON b.bus_id = ba.bus_id AND ba.status = 'Active'
    `;
    const params = [];

    if (search) {
      sql += ' WHERE (b.bus_number LIKE ? OR b.route LIKE ? OR b.destination LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    sql += ' GROUP BY b.bus_id, b.bus_number, b.route, b.destination, b.capacity ORDER BY b.bus_id ASC';

    const buses = await db.query(sql, params);

    res.status(200).json({
      success: true,
      data: buses.map(b => ({
        ...b,
        total_capacity: Number(b.total_capacity),
        occupied_seats: Number(b.occupied_seats),
        available_seats: Number(b.available_seats)
      }))
    });
  } catch (error) {
    next(error);
  }
}

async function getBusById(req, res, next) {
  const { id } = req.params;

  try {
    const [bus] = await db.query(
      `
      SELECT 
        b.bus_id,
        b.bus_number,
        b.route,
        b.destination,
        b.capacity AS total_capacity,
        COUNT(ba.allocation_id) AS occupied_seats,
        (b.capacity - COUNT(ba.allocation_id)) AS available_seats
      FROM buses b
      LEFT JOIN bus_allocations ba 
        ON b.bus_id = ba.bus_id AND ba.status = 'Active'
      WHERE b.bus_id = ?
      GROUP BY b.bus_id
      LIMIT 1
      `,
      [id]
    );

    if (!bus) {
      return res.status(404).json({
        success: false,
        message: `Bus with ID ${id} not found.`
      });
    }

    // Active commuters
    const passengers = await db.query(
      `
      SELECT 
        ba.allocation_id,
        ba.allocation_date,
        s.student_id,
        s.name AS student_name,
        s.phone,
        s.email
      FROM bus_allocations ba
      JOIN students s ON ba.student_id = s.student_id
      WHERE ba.bus_id = ? AND ba.status = 'Active'
      ORDER BY ba.allocation_date DESC
      `,
      [id]
    );

    res.status(200).json({
      success: true,
      data: {
        ...bus,
        total_capacity: Number(bus.total_capacity),
        occupied_seats: Number(bus.occupied_seats),
        available_seats: Number(bus.available_seats),
        passengers
      }
    });
  } catch (error) {
    next(error);
  }
}

async function createBus(req, res, next) {
  const { bus_number, route, destination, capacity } = req.body;

  try {
    const result = await db.query(
      'INSERT INTO buses (bus_number, route, destination, capacity) VALUES (?, ?, ?, ?)',
      [bus_number, route, destination, capacity]
    );

    res.status(201).json({
      success: true,
      message: 'Bus route registered successfully.',
      data: {
        bus_id: result.insertId,
        ...req.body
      }
    });
  } catch (error) {
    next(error);
  }
}

async function updateBus(req, res, next) {
  const { id } = req.params;
  const { bus_number, route, destination, capacity } = req.body;

  try {
    const updated = await db.withTransaction(async connection => {
    const txQuery = async (sql, params) => (await connection.query(sql, params.map(p => p === undefined ? null : p)))[0];
    const [existing] = await txQuery('SELECT bus_id, capacity FROM buses WHERE bus_id = ? FOR UPDATE', [id]);
    if (!existing) {
      throw Object.assign(new Error(`Bus with ID ${id} not found.`), { statusCode: 404 });
    }

    if (capacity !== undefined) {
      const [occ] = await txQuery(
        "SELECT COUNT(*) AS count FROM bus_allocations WHERE bus_id = ? AND status = 'Active'",
        [id]
      );
      const activeCount = Number(occ.count);
      if (capacity < activeCount) {
        throw Object.assign(new Error(`Cannot reduce bus capacity to ${capacity} because there are currently ${activeCount} active assigned commuters.`), { statusCode: 400 });
      }
    }

    await txQuery(
      `
      UPDATE buses 
      SET bus_number = COALESCE(?, bus_number),
          route = COALESCE(?, route),
          destination = COALESCE(?, destination),
          capacity = COALESCE(?, capacity)
      WHERE bus_id = ?
      `,
      [bus_number, route, destination, capacity, id]
    );

    const [updated] = await txQuery('SELECT * FROM buses WHERE bus_id = ? FOR UPDATE', [id]);

    return updated;
    });

    res.status(200).json({
      success: true,
      message: 'Bus details updated successfully.',
      data: updated
    });
  } catch (error) {
    next(error);
  }
}

async function deleteBus(req, res, next) {
  const { id } = req.params;

  try {
    const [existing] = await db.query('SELECT bus_id, bus_number FROM buses WHERE bus_id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: `Bus with ID ${id} not found.`
      });
    }

    const [allocations] = await db.query('SELECT COUNT(*) AS count FROM bus_allocations WHERE bus_id = ?', [id]);
    const allocCount = Number(allocations.count);

    if (allocCount > 0) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete bus "${existing.bus_number}" because ${allocCount} historical or active student transportation assignments are associated with it.`,
        code: 'FOREIGN_KEY_CONFLICT'
      });
    }

    await db.query('DELETE FROM buses WHERE bus_id = ?', [id]);

    res.status(200).json({
      success: true,
      message: `Bus "${existing.bus_number}" (ID: ${id}) deleted successfully.`
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAllBuses,
  getBusById,
  createBus,
  updateBus,
  deleteBus
};
