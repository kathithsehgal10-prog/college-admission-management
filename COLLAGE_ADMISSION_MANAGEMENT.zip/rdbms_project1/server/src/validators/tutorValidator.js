const { z } = require('zod');

const tutorSchema = z.object({
  tutor_name: z.string().trim().min(2, 'Tutor name must be at least 2 characters.').max(100),
  email: z.string().trim().email('Invalid email address format.').max(120),
  phone: z.string().trim().min(7, 'Phone number must be at least 7 digits.').max(20),
  qualification: z.string().trim().max(100).default('M.Tech / Ph.D'),
  department_id: z.coerce.number().int().positive('A valid department ID is required.')
});

const tutorUpdateSchema = tutorSchema.partial();

module.exports = {
  tutorSchema,
  tutorUpdateSchema
};
