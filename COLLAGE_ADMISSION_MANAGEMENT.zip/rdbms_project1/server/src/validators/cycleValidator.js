const { z } = require('zod');
const { dateSchema } = require('./dateValidator');

const cycleSchema = z.object({
  cycle_name: z.string().min(3, 'Cycle name must be at least 3 characters').max(100),
  start_date: dateSchema,
  end_date: dateSchema,
  status: z.enum(['UPCOMING', 'ACTIVE', 'CLOSED']).default('ACTIVE'),
  description: z.string().optional().nullable()
}).refine(data => new Date(data.end_date) >= new Date(data.start_date), {
  message: 'End date must be on or after start date',
  path: ['end_date']
});

module.exports = {
  cycleSchema
};
