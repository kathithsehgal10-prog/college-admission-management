const { z } = require('zod');

const studentSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters.').max(100),
  gender: z.enum(['Male', 'Female', 'Other'], {
    errorMap: () => ({ message: 'Gender must be Male, Female, or Other.' })
  }),
  age: z.coerce.number().int().min(15, 'Age must be at least 15.').max(60, 'Age must be 60 or less.'),
  address: z.string().trim().min(5, 'Address must be at least 5 characters.'),
  phone: z.string().trim().min(7, 'Phone number must be at least 7 digits.').max(20),
  email: z.string().trim().email('Invalid email address format.').max(120),
  rank: z.coerce.number().int().positive('Rank must be a positive integer.').nullable().optional(),
  marks: z.coerce.number().min(0, 'Marks cannot be negative.').max(100, 'Marks cannot exceed 100.'),
  tenth_marks: z.coerce.number().min(0, '10th marks cannot be negative.').max(100, '10th marks cannot exceed 100.'),
  twelfth_marks: z.coerce.number().min(0, '12th marks cannot be negative.').max(100, '12th marks cannot exceed 100.'),
  department_id: z.coerce.number().int().positive().nullable().optional()
});

const studentUpdateSchema = studentSchema.partial();

module.exports = {
  studentSchema,
  studentUpdateSchema
};
