const { z } = require('zod');
const { dateSchema } = require('./dateValidator');

const hostelSchema = z.object({
  name: z.string().trim().min(2, 'Hostel name is required.').max(100),
  type: z.enum(['Boys', 'Girls', 'Co-ed']).default('Co-ed'),
  address: z.string().trim().min(5, 'Hostel address is required.'),
  number_of_seats: z.coerce.number().int().positive('Number of seats must be greater than zero.')
});

const hostelUpdateSchema = hostelSchema.partial();

const hostelAllocationSchema = z.object({
  student_id: z.coerce.number().int().positive('Valid student ID is required.'),
  hostel_id: z.coerce.number().int().positive('Valid hostel ID is required.'),
  room_number: z.string().trim().max(20).optional().nullable(),
  allocation_date: dateSchema.optional(),
  status: z.enum(['Active', 'Vacated']).default('Active')
});

const updateHostelAllocationStatusSchema = z.object({
  status: z.enum(['Active', 'Vacated'], {
    errorMap: () => ({ message: 'Status must be Active or Vacated.' })
  }),
  room_number: z.string().trim().max(20).optional().nullable()
});

module.exports = {
  hostelSchema,
  hostelUpdateSchema,
  hostelAllocationSchema,
  updateHostelAllocationStatusSchema
};
