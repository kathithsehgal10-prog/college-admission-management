const { z } = require('zod');

const announcementSchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters').max(200),
  content: z.string().min(10, 'Content must be at least 10 characters'),
  published_by: z.string().optional().default('Admission Directorate'),
  is_published: z.boolean().optional().default(true)
});

module.exports = {
  announcementSchema
};
