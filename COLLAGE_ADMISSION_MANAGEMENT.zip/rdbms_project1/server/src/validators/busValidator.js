const { z } = require('zod');
const { dateSchema } = require('./dateValidator');

const busSchema = z.object({
  bus_number: z.string().trim().min(2, 'Bus number is required.').max(50),
  route: z.string().trim().min(3, 'Route description is required.').max(150),
  destination: z.string().trim().min(2, 'Destination is required.').max(100),
  capacity: z.coerce.number().int().positive('Bus capacity must be greater than zero.')
});

const busUpdateSchema = busSchema.partial();

const busAllocationSchema = z.object({
  student_id: z.coerce.number().int().positive('Valid student ID is required.'),
  bus_id: z.coerce.number().int().positive('Valid bus ID is required.'),
  allocation_date: dateSchema.optional(),
  status: z.enum(['Active', 'Cancelled']).default('Active')
});

const updateBusAllocationStatusSchema = z.object({
  status: z.enum(['Active', 'Cancelled'], {
    errorMap: () => ({ message: 'Status must be Active or Cancelled.' })
  })
});

module.exports = {
  busSchema,
  busUpdateSchema,
  busAllocationSchema,
  updateBusAllocationStatusSchema
};
