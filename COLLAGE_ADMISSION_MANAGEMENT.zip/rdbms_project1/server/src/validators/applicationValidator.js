const { z } = require('zod');
const { dateSchema } = require('./dateValidator');

const ALLOWED_STATUSES = [
  'DRAFT',
  'SUBMITTED',
  'UNDER_REVIEW',
  'DOCUMENTS_REQUIRED',
  'APPROVED',
  'REJECTED',
  'WAITLISTED',
  'WITHDRAWN',
  // Backward compatibility aliases
  'Pending',
  'Approved',
  'Rejected'
];

function normalizeStatus(status) { return status === 'Pending' ? 'SUBMITTED' : status.toUpperCase(); }

const createApplicationSchema = z.object({
  student_id: z.coerce.number().int().positive('Valid student ID is required.'),
  course_id: z.coerce.number().int().positive('Valid course ID is required.'),
  cycle_id: z.coerce.number().int().positive().optional().nullable(),
  application_date: dateSchema.optional(),
  status: z.enum(ALLOWED_STATUSES).default('SUBMITTED').transform(normalizeStatus),
  marks_obtained: z.coerce.number().min(0).max(100).optional().nullable(),
  maximum_marks: z.coerce.number().positive().max(100).optional().default(100),
  remarks: z.string().trim().optional().nullable(),
  admin_remarks: z.string().trim().optional().nullable()
}).refine(data => data.marks_obtained == null || data.marks_obtained <= data.maximum_marks, { message: 'Marks cannot exceed maximum marks.', path: ['marks_obtained'] });

const updateApplicationStatusSchema = z.object({
  status: z.enum(ALLOWED_STATUSES, {
    errorMap: () => ({ message: 'Invalid application status provided.' })
  }).transform(normalizeStatus),
  remarks: z.string().trim().optional().nullable(),
  admin_remarks: z.string().trim().optional().nullable()
});

module.exports = {
  ALLOWED_STATUSES,
  createApplicationSchema,
  updateApplicationStatusSchema
};
