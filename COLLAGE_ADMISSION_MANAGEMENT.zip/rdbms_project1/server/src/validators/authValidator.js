const { z } = require('zod');

const loginSchema = z.object({
  email: z.string().email('Please provide a valid email address.').max(120),
  password: z.string().min(6, 'Password must be at least 6 characters long.')
});

const createAdminSchema = z.object({
  admin_name: z.string().min(2, 'Admin name must be at least 2 characters.').max(100),
  email: z.string().email('Please provide a valid email address.').max(120),
  password: z.string().min(8, 'Password must be at least 8 characters long.')
});

module.exports = {
  loginSchema,
  createAdminSchema
};
