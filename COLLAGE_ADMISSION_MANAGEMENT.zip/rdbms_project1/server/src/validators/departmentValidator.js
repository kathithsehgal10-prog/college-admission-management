const { z } = require('zod');

const departmentSchema = z.object({
  department_name: z.string().trim().min(2, 'Department name is required.').max(100),
  code: z.string().trim().max(10).optional().nullable(),
  description: z.string().trim().optional().nullable()
});

const departmentUpdateSchema = departmentSchema.partial();

module.exports = {
  departmentSchema,
  departmentUpdateSchema
};
