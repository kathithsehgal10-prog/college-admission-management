const { z } = require('zod');

const courseSchema = z.object({
  course_name: z.string().trim().min(2, 'Course name must be at least 2 characters.').max(120),
  course_code: z.string().trim().max(20).optional().nullable(),
  duration_years: z.coerce.number().int().min(1, 'Duration must be at least 1 year.').max(6).default(4),
  department_id: z.coerce.number().int().positive('A valid department ID is required.'),
  intake_capacity: z.coerce.number().int().positive('Intake capacity must be positive.').default(60)
});

const courseUpdateSchema = courseSchema.partial();

module.exports = {
  courseSchema,
  courseUpdateSchema
};
