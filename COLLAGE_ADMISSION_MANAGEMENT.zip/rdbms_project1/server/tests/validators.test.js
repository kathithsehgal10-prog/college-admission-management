const test = require('node:test');
const assert = require('node:assert/strict');
const { studentSchema } = require('../src/validators/studentValidator');
const { departmentSchema } = require('../src/validators/departmentValidator');
const { courseSchema } = require('../src/validators/courseValidator');
const { loginSchema } = require('../src/validators/authValidator');
const { hostelSchema, hostelAllocationSchema } = require('../src/validators/hostelValidator');
const { busSchema } = require('../src/validators/busValidator');

test('Validator Suite - Student Validation', async (t) => {
  await t.test('accepts valid student payload', () => {
    const validData = {
      name: 'Test Student',
      gender: 'Male',
      age: 19,
      address: '123 Campus Avenue',
      phone: '+91 9876543210',
      email: 'student@example.com',
      marks: 92.5,
      tenth_marks: 88.0,
      twelfth_marks: 91.5,
      department_id: 1
    };
    const result = studentSchema.safeParse(validData);
    assert.equal(result.success, true);
  });

  await t.test('rejects negative marks or marks > 100', () => {
    const invalidData = {
      name: 'Invalid Student',
      gender: 'Female',
      age: 18,
      address: '123 Test Road',
      phone: '9876543210',
      email: 'invalid@example.com',
      marks: 105.0, // > 100
      tenth_marks: -5, // < 0
      twelfth_marks: 80
    };
    const result = studentSchema.safeParse(invalidData);
    assert.equal(result.success, false);
    assert.ok(result.error.issues.length >= 2);
  });

  await t.test('rejects age below 15', () => {
    const result = studentSchema.safeParse({
      name: 'Child',
      gender: 'Male',
      age: 12,
      address: 'Test Address',
      phone: '1234567890',
      email: 'child@example.com',
      marks: 70,
      tenth_marks: 70,
      twelfth_marks: 70
    });
    assert.equal(result.success, false);
  });
});

test('Validator Suite - Department & Course Validation', async (t) => {
  await t.test('accepts valid department', () => {
    const result = departmentSchema.safeParse({
      department_name: 'Aerospace Engineering',
      code: 'AERO',
      description: 'Aeronautics'
    });
    assert.equal(result.success, true);
  });

  await t.test('rejects empty department name', () => {
    const result = departmentSchema.safeParse({ department_name: '' });
    assert.equal(result.success, false);
  });

  await t.test('accepts valid course with duration', () => {
    const result = courseSchema.safeParse({
      course_name: 'B.Tech Aerospace',
      duration_years: 4,
      department_id: 1,
      intake_capacity: 60
    });
    assert.equal(result.success, true);
  });
});

test('Validator Suite - Hostel & Bus Validation', async (t) => {
  await t.test('rejects non-positive hostel capacity', () => {
    const result = hostelSchema.safeParse({
      name: 'Hostel 1',
      address: 'Campus',
      number_of_seats: 0
    });
    assert.equal(result.success, false);
  });

  await t.test('accepts valid bus with positive capacity', () => {
    const result = busSchema.safeParse({
      bus_number: 'BUS-99',
      route: 'North Route',
      destination: 'Campus Gate',
      capacity: 40
    });
    assert.equal(result.success, true);
  });
});

test('Validator Suite - Auth Validation', async (t) => {
  await t.test('validates email format in login', () => {
    const invalid = loginSchema.safeParse({ email: 'not-an-email', password: 'password123' });
    assert.equal(invalid.success, false);

    const valid = loginSchema.safeParse({ email: 'admin@college.edu', password: 'password123' });
    assert.equal(valid.success, true);
  });
});
