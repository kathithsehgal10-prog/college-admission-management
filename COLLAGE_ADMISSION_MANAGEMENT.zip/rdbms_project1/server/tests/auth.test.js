const test = require('node:test');
const assert = require('node:assert/strict');
const jwt = require('jsonwebtoken');
const config = require('../src/config/env');
const { verifyToken } = require('../src/middleware/auth');

test('Auth Middleware Suite', async (t) => {
  await t.test('blocks requests with missing authorization header', () => {
    let statusCode = null;
    let jsonResponse = null;

    const req = { headers: {} };
    const res = {
      status(code) {
        statusCode = code;
        return this;
      },
      json(data) {
        jsonResponse = data;
        return this;
      }
    };
    const next = () => {
      assert.fail('next() should not be called when token is missing');
    };

    verifyToken(req, res, next);
    assert.equal(statusCode, 401);
    assert.equal(jsonResponse.success, false);
  });

  await t.test('passes valid JWT and populates req.user', () => {
    const payload = { admin_id: 1, email: 'admin@college.edu', role: 'admin' };
    const token = jwt.sign(payload, config.jwtSecret, { expiresIn: '1h' });

    const req = {
      headers: {
        authorization: `Bearer ${token}`
      }
    };
    let nextCalled = false;
    const res = {};
    const next = () => {
      nextCalled = true;
    };

    verifyToken(req, res, next);
    assert.equal(nextCalled, true);
    assert.equal(req.user.admin_id, 1);
    assert.equal(req.user.email, 'admin@college.edu');
  });

  await t.test('rejects expired JWT with clear message', () => {
    const payload = { admin_id: 1, email: 'admin@college.edu' };
    const token = jwt.sign(payload, config.jwtSecret, { expiresIn: '0s' });

    let statusCode = null;
    let jsonResponse = null;

    const req = {
      headers: {
        authorization: `Bearer ${token}`
      }
    };
    const res = {
      status(code) {
        statusCode = code;
        return this;
      },
      json(data) {
        jsonResponse = data;
        return this;
      }
    };
    const next = () => {
      assert.fail('next() should not be called for expired token');
    };

    verifyToken(req, res, next);
    assert.equal(statusCode, 401);
    assert.ok(jsonResponse.message.toLowerCase().includes('expired'));
  });
});
