const { test } = require('node:test');
const assert = require('node:assert/strict');
const db = require('../src/config/db');
const controller = require('../src/controllers/vivaController');
function response() {
  return { code: 200, status(code) { this.code = code; return this; }, json(body) { this.body = body; return this; } };
}
test('viva lists curated joins and executes through a read-only connection', async t => {
  const list = response();
  await controller.getVivaQueries({}, list);
  assert.ok(list.body.data.length >= 10);
  let sql;
  t.mock.method(db, 'readOnlyQuery', async query => { sql = query; return [{ student_name: 'Test' }]; });
  const res = response();
  await controller.executeVivaQuery({ body: { queryId: 'join-4-table' } }, res, error => { throw error; });
  assert.match(sql, /INNER JOIN/);
  assert.deepEqual(res.body.data.columns, ['student_name']);
});
test('viva rejects writes, PRAGMA, multiple statements, comments and file exports', async t => {
  const query = t.mock.method(db, 'readOnlyQuery', async () => { throw Error('Must not execute'); });
  for (const sql of ['DELETE FROM students', 'PRAGMA foreign_keys=OFF', 'SELECT 1; SELECT 2', "SELECT * FROM students INTO OUTFILE '/tmp/students'", 'SELECT SLEEP(50)', 'WITH x AS (SELECT 1) DELETE FROM students', 'SELECT 1 /* comment */']) {
    const res = response();
    await controller.executeVivaQuery({ body: { sql } }, res, error => { throw error; });
    assert.equal(res.code, 400, sql);
  }
  assert.equal(query.mock.callCount(), 0);
});
test('viva metadata reports objects actually installed rather than invented names', async t => {
  t.mock.method(db, 'query', async sql => {
    if (sql.includes('information_schema.VIEWS')) return [{ name: 'view_department_stats' }];
    if (sql.includes('information_schema.ROUTINES')) return [];
    if (sql.includes('information_schema.TRIGGERS')) return [];
    return [{ c: 3 }];
  });
  const res = response();
  await controller.getSchemaMetadata({}, res, error => { throw error; });
  assert.equal(res.body.data.tables.length, 16);
  assert.deepEqual(res.body.data.views, ['view_department_stats']);
  assert.deepEqual(res.body.data.triggers, []);
  assert.deepEqual(res.body.data.storedProcedures, []);
});
test('viva metadata propagates database outages', async t => {
  t.mock.method(db, 'query', async () => { throw Object.assign(new Error('offline'), { statusCode: 503 }); });
  let error;
  await controller.getSchemaMetadata({}, response(), e => { error = e; });
  assert.equal(error.statusCode, 503);
});
