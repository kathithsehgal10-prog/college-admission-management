const { test } = require('node:test');
const assert = require('node:assert/strict');
const db = require('../src/config/db');
const applications = require('../src/controllers/applicationController');
const { dateSchema } = require('../src/validators/dateValidator');
const { checkAdmission } = require('../src/controllers/businessRules');
function response() { return { code: 200, status(code) { this.code = code; return this; }, json(body) { this.body = body; return this; } }; }
test('transaction acquisition failures reach Express error handler', async t => {
  t.mock.method(db, 'withTransaction', async () => { throw Object.assign(new Error('MySQL offline'), { statusCode: 503 }); });
  for (const handler of [applications.createApplication, applications.updateApplicationStatus, applications.deleteApplication,
    require('../src/controllers/hostelAllocationController').createAllocation,
    require('../src/controllers/busAllocationController').updateAllocation]) {
    let error;
    await handler({ body: {}, params: { id: 1 } }, response(), e => { error = e; });
    assert.equal(error.statusCode, 503);
  }
});
test('course full and second approved admission are blocked', async () => {
  for (const [other, count, message] of [[[], 1, /capacity/], [[{ application_id: 8 }], 0, /already/]]) {
    const connection = { async query(sql) {
      if (sql.includes('FROM courses')) return [[{ intake_capacity: 1, department_id: 1 }]];
      if (sql.includes('COUNT')) return [[{ total: count }]];
      return [other];
    } };
    await assert.rejects(checkAdmission(connection, 1, 2), message);
  }
});
test('approval revocation clears department and absent remarks are bound as null', async t => {
  const calls = [];
  t.mock.method(db, 'withTransaction', async work => work({ async query(sql, params) {
    calls.push([sql, params]);
    if (sql.startsWith('SELECT student_id FROM applications')) return [[{ student_id: 4 }]];
    if (sql.startsWith('SELECT application_id')) return [[{ student_id: 4, course_id: 2, status: 'Approved' }]];
    return [[]];
  } }));
  const res = response();
  await applications.updateApplicationStatus({ params: { id: 3 }, body: { status: 'Rejected' } }, res, error => { throw error; });
  assert.equal(res.code, 200);
  assert.ok(calls.some(([sql, params]) => sql.startsWith('UPDATE students') && params[0] === null));
  assert.ok(calls.some(([sql, params]) => sql.startsWith('UPDATE applications') && params[1] === null));
});
for (const kind of ['hostel', 'bus']) {
  for (const reason of ['full', 'duplicate']) {
    test(`${kind} reactivation rejects ${reason} allocation`, async t => {
      t.mock.method(db, 'withTransaction', async work => work({ async query(sql) {
        if (sql.startsWith('SELECT student_id FROM')) return [[{ student_id: 1 }]];
        if (sql.startsWith('SELECT *')) return [[{ student_id: 1, hostel_id: 2, bus_id: 2, status: 'Vacated' }]];
        if (sql.includes('FROM hostels') || sql.includes('FROM buses')) return [[{ number_of_seats: 1, capacity: 1 }]];
        if (sql.includes('COUNT')) return [[{ total: 1 }]];
        if (sql.startsWith('SELECT allocation_id')) return [reason === 'duplicate' ? [{ allocation_id: 9 }] : []];
        throw Error('Write must not occur');
      } }));
      let error;
      await require(`../src/controllers/${kind}AllocationController`).updateAllocation({ params: { id: 3 }, body: { status: 'Active' } }, response(), e => { error = e; });
      assert.equal(error.statusCode, 409);
    });
  }
}
test('dates reject impossible calendar days while allowing leap day', () => {
  for (const value of ['2026-02-30', '2025-02-29', '2026-13-01']) assert.equal(dateSchema.safeParse(value).success, false);
  assert.equal(dateSchema.safeParse('2024-02-29').success, true);
});
test('failed transactions roll back and release connections', async t => {
  const calls = [];
  t.mock.method(db.pool, 'getConnection', async () => ({
    async query() {}, async beginTransaction() { calls.push('begin'); },
    async commit() { calls.push('commit'); }, async rollback() { calls.push('rollback'); },
    release() { calls.push('release'); }
  }));
  await assert.rejects(db.withTransaction(async () => { throw Error('Invalid allocation'); }), /Invalid allocation/);
  assert.deepEqual(calls, ['begin', 'rollback', 'release']);
});
test('MySQL failure does not fall back to SQLite', async t => {
  t.mock.method(db.pool, 'getConnection', async () => { throw Object.assign(new Error('offline'), { code: 'ECONNREFUSED' }); });
  const health = await db.testConnection();
  assert.equal(health.connected, false);
  assert.equal(health.dialect, 'mysql');
});
