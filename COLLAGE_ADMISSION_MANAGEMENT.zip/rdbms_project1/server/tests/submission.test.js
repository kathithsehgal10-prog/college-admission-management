const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { statements } = require('../src/scripts/setupDatabase');
const { createApplicationSchema } = require('../src/validators/applicationValidator');
const db = require('../src/config/db');
const paymentController = require('../src/controllers/paymentController');
test('SQL importer handles function bodies using DELIMITER', () => {
  const parsed = statements('SELECT 1;\nDELIMITER $$\nCREATE FUNCTION f() RETURNS INT DETERMINISTIC\nBEGIN\nRETURN 1;\nEND$$\nDELIMITER ;\nSELECT 2;');
  assert.equal(parsed.length, 3);
  assert.match(parsed[1], /RETURN 1;/);
});
test('application marks respect maximum and legacy statuses normalize', () => {
  assert.equal(createApplicationSchema.safeParse({ student_id: 1, course_id: 1, marks_obtained: 80, maximum_marks: 50 }).success, false);
  assert.equal(createApplicationSchema.parse({ student_id: 1, course_id: 1, status: 'Approved' }).status, 'APPROVED');
});
test('negative payment values are rejected before touching the database', async t => {
  const query = t.mock.method(db, 'query', async () => { throw Error('Must not query'); });
  let code;
  await paymentController.recordPayment({ body: { application_id: 1, amount: -200, transaction_reference: 'test' } }, { status(value) { code = value; return this; }, json() {} }, error => { throw error; });
  assert.equal(code, 400);
  assert.equal(query.mock.callCount(), 0);
});
