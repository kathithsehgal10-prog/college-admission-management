const test = require('node:test');
const assert = require('node:assert/strict');
const { cycleSchema } = require('../src/validators/cycleValidator');
const { announcementSchema } = require('../src/validators/announcementValidator');
const cycleController = require('../src/controllers/cycleController');
const announcementController = require('../src/controllers/announcementController');
const paymentController = require('../src/controllers/paymentController');
const db = require('../src/config/db');

test('Cycles and Announcements Validator Suite', async (t) => {
  await t.test('cycleSchema accepts valid cycle definition', () => {
    const valid = {
      cycle_name: 'Academic Intake 2026-2027',
      start_date: '2026-06-01',
      end_date: '2026-08-31',
      status: 'ACTIVE',
      description: 'Fall undergraduate admissions'
    };
    const result = cycleSchema.safeParse(valid);
    assert.equal(result.success, true);
  });

  await t.test('cycleSchema rejects end_date earlier than start_date', () => {
    const invalid = {
      cycle_name: 'Invalid Intake',
      start_date: '2026-08-31',
      end_date: '2026-06-01',
      status: 'ACTIVE'
    };
    const result = cycleSchema.safeParse(invalid);
    assert.equal(result.success, false);
    assert.ok(result.error.issues.some(i => i.message.includes('End date must be on or after start date')));
  });

  await t.test('cycleSchema rejects invalid status values', () => {
    const invalid = {
      cycle_name: 'Spring Intake',
      start_date: '2026-01-01',
      end_date: '2026-03-31',
      status: 'PENDING_REVIEW' // Not in enum
    };
    const result = cycleSchema.safeParse(invalid);
    assert.equal(result.success, false);
  });

  await t.test('announcementSchema validates required title and content lengths', () => {
    const tooShort = {
      title: 'Hi',
      content: 'Short'
    };
    const result = announcementSchema.safeParse(tooShort);
    assert.equal(result.success, false);
    assert.equal(result.error.issues.length, 2);

    const valid = {
      title: 'Counseling Schedule Released',
      content: 'Phase 1 merit counseling will commence on July 15th at the Main Auditorium.',
      published_by: 'Dean of Admissions',
      is_published: true
    };
    const validResult = announcementSchema.safeParse(valid);
    assert.equal(validResult.success, true);
  });
});

test('Cycles and Announcements Controller Read Suite', async (t) => {
  t.mock.method(db, 'query', async sql => sql.includes('FROM applications WHERE application_id') ? [] : [{ cycle_id: 1 }]);
  await t.test('cycleController.getAllCycles returns active cycles list', async () => {
    let responseData = null;
    const req = { query: {} };
    const res = {
      status(code) {
        assert.equal(code, 200);
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    await cycleController.getAllCycles(req, res, (err) => {
      if (err) assert.fail(err.message);
    });

    assert.equal(responseData.success, true);
    assert.ok(Array.isArray(responseData.data));
    assert.ok(responseData.data.length >= 1);
  });

  await t.test('announcementController.getAllAnnouncements returns list', async () => {
    let responseData = null;
    const req = { query: {} };
    const res = {
      status(code) {
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    await announcementController.getAllAnnouncements(req, res, (err) => {
      if (err) assert.fail(err.message);
    });

    assert.equal(responseData.success, true);
    assert.ok(Array.isArray(responseData.data));
  });

  await t.test('paymentController.getAllPayments returns seeded ledger records', async () => {
    let responseData = null;
    const req = { query: {} };
    const res = {
      status(code) {
        assert.equal(code, 200);
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    await paymentController.getAllPayments(req, res, (err) => {
      if (err) assert.fail(err.message);
    });

    assert.equal(responseData.success, true);
    assert.ok(Array.isArray(responseData.data));
  });

  await t.test('paymentController.recordPayment rejects missing required fields', async () => {
    let statusCode = null;
    let responseData = null;
    const req = { body: { application_id: 1 } };
    const res = {
      status(code) {
        statusCode = code;
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    await paymentController.recordPayment(req, res, () => {});
    assert.equal(statusCode, 400);
    assert.equal(responseData.success, false);
  });

  await t.test('paymentController.recordPayment rejects non-existent application', async () => {
    let statusCode = null;
    let responseData = null;
    const req = {
      body: {
        application_id: 99999,
        amount: 50000,
        transaction_reference: `TXN-TEST-${Date.now()}`
      }
    };
    const res = {
      status(code) {
        statusCode = code;
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    await paymentController.recordPayment(req, res, () => {});
    assert.equal(statusCode, 404);
    assert.equal(responseData.success, false);
  });
});

test('Application Dossier & Reports Controller Suite', async (t) => {
  t.mock.method(db, 'query', async sql => {
    if (sql.includes("AS 'Payment ID'")) return [{ 'Payment ID': 1, 'Transaction Reference': 'TEST' }];
    if (sql.includes('FROM application_status_history') || sql.includes('FROM payments')) return [];
    return [{ application_id: 1 }];
  });
  const applicationController = require('../src/controllers/applicationController');
  const reportController = require('../src/controllers/reportController');

  await t.test('applicationController.getApplicationById includes history and payments', async () => {
    let responseData = null;
    const req = { params: { id: 1 } };
    const res = {
      status(code) {
        assert.equal(code, 200);
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    await applicationController.getApplicationById(req, res, (err) => {
      if (err) assert.fail(err.message);
    });

    assert.equal(responseData.success, true);
    assert.equal(responseData.data.application_id, 1);
    assert.ok(Array.isArray(responseData.data.history));
    assert.ok(Array.isArray(responseData.data.payments));
  });

  await t.test('reportController.exportCsv generates payments CSV headers', async () => {
    let outputCsv = '';
    const headers = {};
    const req = { params: { type: 'payments' } };
    const res = {
      setHeader(name, val) {
        headers[name] = val;
      },
      status(code) {
        assert.equal(code, 200);
        return this;
      },
      send(data) {
        outputCsv = data;
        return this;
      }
    };

    await reportController.exportCsv(req, res, (err) => {
      if (err) assert.fail(err.message);
    });

    assert.equal(headers['Content-Type'], 'text/csv');
    assert.ok(outputCsv.includes('Payment ID'));
    assert.ok(outputCsv.includes('Transaction Reference'));
  });
});
