# MySQL setup

This submission uses MySQL 8.0.16+ with InnoDB. Configure `server/.env` with a real MySQL account, then use:

```bash
npm run db:setup
npm run create-admin
npm run db:check
```

The setup command imports the schema, seed records and routines/triggers into the configured DB_NAME only when the database has no tables. It refuses to overwrite an existing project database.

For manual setup in Workbench: import `schema.sql`, then `seed.sql`, then `procedures_and_triggers.sql`. These raw scripts target college_admission and recreate tables. Use them only for a fresh demonstration database. The routines import may require the administrator account if binary logging restricts CREATE FUNCTION.

Create an application account limited to the project database. The app needs SELECT, INSERT, UPDATE and DELETE; routines may need EXECUTE. Use an administrative account only for setup and schema changes. The Workbench connection and the backend must point to the same database.

Verification:

```sql
SELECT VERSION(), DATABASE();
SHOW FULL TABLES;
SELECT * FROM view_department_stats;
SELECT * FROM view_hostel_occupancy;
SELECT * FROM view_bus_occupancy;
```

The fresh schema includes 16 base tables, 3 views, 3 stored procedures, 3 stored functions and the imported triggers. `db:check` records the objects actually installed.
